import {spawnSync} from 'node:child_process';
import {mkdirSync,mkdtempSync,readdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
const root=resolve('artifacts/capture-outbox-tests');mkdirSync(root,{recursive:true});
const out=mkdtempSync(join(root,'run-')),classes=join(out,'classes');mkdirSync(classes);
const tools=resolve('artifacts/android-tools/jdk');
const jdk=join(tools,readdirSync(tools).find(n=>n.startsWith('jdk-')),'bin');
function run(exe,args){const r=spawnSync(join(jdk,exe+'.exe'),args,{encoding:'utf8',windowsHide:true,timeout:60000});if(r.status!==0||r.error)throw Error(r.stderr||r.stdout||String(r.error));process.stdout.write(r.stdout);}
const src=resolve('android-collector/src/kr/household/hanacollector');
run('javac',['-encoding','UTF-8','--release','8','-d',classes,...['CaptureOutbox','EncryptedOutboxStore'].map(n=>join(src,n+'.java')),resolve('android-collector/test/CaptureOutboxTest.java')]);
run('java',['-classpath',classes,'CaptureOutboxTest',join(out,'synthetic')]);
console.log('Production outbox core tested on host; no device keys, live DB or public release changed by this test.');
