import { existsSync, readdirSync } from 'node:fs';
import { join, resolve } from 'node:path';

// Use the project toolchain when present. A fresh checkout can use its installed JDK.
export function javaTool(name) {
  const executable = process.platform === 'win32' ? name + '.exe' : name;
  const bundled = resolve('artifacts/android-tools/jdk');
  if (existsSync(bundled)) {
    for (const entry of readdirSync(bundled).sort().reverse()) {
      const candidate = join(bundled, entry, 'bin', executable);
      if (entry.startsWith('jdk-') && existsSync(candidate)) return candidate;
    }
  }
  if (process.env.JAVA_HOME) {
    const candidate = join(process.env.JAVA_HOME, 'bin', executable);
    if (existsSync(candidate)) return candidate;
  }
  return executable;
}
