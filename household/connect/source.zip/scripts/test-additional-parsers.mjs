import {spawnSync} from 'node:child_process';
import {mkdirSync,mkdtempSync,readdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
const root=resolve('artifacts/additional-parser-tests');mkdirSync(root,{recursive:true});const out=mkdtempSync(join(root,'run-'));
const tools=resolve('artifacts/android-tools/jdk'),jdk=join(tools,readdirSync(tools).find(n=>n.startsWith('jdk-')),'bin');
function run(exe,args){const r=spawnSync(join(jdk,exe+'.exe'),args,{encoding:'utf8',windowsHide:true,timeout:60000});if(r.status!==0||r.error)throw Error(r.stderr||r.stdout||String(r.error));process.stdout.write(r.stdout);}
run('javac',['-encoding','UTF-8','--release','8','-d',out,resolve('android-collector/src/kr/household/hanacollector/AdditionalPushParser.java'),resolve('android-collector/test/AdditionalPushParserTest.java')]);
run('java',['-classpath',out,'AdditionalPushParserTest']);
