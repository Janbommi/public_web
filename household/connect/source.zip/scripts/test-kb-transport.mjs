import {spawnSync} from 'node:child_process';
import {mkdirSync,mkdtempSync,readdirSync,writeFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
const root=resolve('artifacts/kb-transport-tests');mkdirSync(root,{recursive:true});const out=mkdtempSync(join(root,'run-'));
const tools=resolve('artifacts/android-tools/jdk'),jdk=join(tools,readdirSync(tools).find(n=>n.startsWith('jdk-')),'bin');
const src=resolve('android-collector/src/kr/household/hanacollector');
function run(exe,args){const r=spawnSync(join(jdk,exe+'.exe'),args,{encoding:'utf8',windowsHide:true,timeout:60000});if(r.status!==0||r.error)throw Error(r.stderr||r.stdout||String(r.error));return r.stdout;}
run('javac',['-encoding','UTF-8','--release','8','-d',out,...['CaptureOutbox','KbTransport','KbPushParser'].map(n=>join(src,n+'.java')),resolve('android-collector/test/KbTransportTest.java')]);
const result=run('java',['-cp',out,'KbTransportTest']);writeFileSync(join(root,'wire-fixture.json'),result.split(/\r?\n/)[0]);console.log(result.split(/\r?\n/)[1]);
