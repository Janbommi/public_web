import {spawnSync} from 'node:child_process';
import {existsSync,mkdirSync,readdirSync,readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {resolve,join,delimiter} from 'node:path';
import {homedir} from 'node:os';
import {createHash} from 'node:crypto';
import {javaTool} from './java-tool.mjs';
const root=resolve('artifacts/android-tools');
const installedSdk=[process.env.ANDROID_HOME,process.env.ANDROID_SDK_ROOT,
  join(homedir(),'AppData/Local/Android/Sdk'),join(homedir(),'Library/Android/sdk'),join(homedir(),'Android/Sdk')]
  .filter(Boolean).find(dir=>existsSync(join(dir,'platforms/android-36/android.jar')));
const sdk=existsSync(join(root,'platform/android-36/android.jar'))?join(root,'platform/android-36/android.jar'):installedSdk&&join(installedSdk,'platforms/android-36/android.jar');
const build=existsSync(join(root,'build-tools/android-16'))?join(root,'build-tools/android-16'):installedSdk&&join(installedSdk,'build-tools/36.0.0');
if(!sdk||!build||!existsSync(join(build,'lib/d8.jar')))throw Error('Android SDK platform 36 and build-tools 36.0.0 are required (ANDROID_HOME).');
const buildTool=name=>join(build,name+(process.platform==='win32'?'.exe':''));
const unsigned=process.argv.includes('--unsigned');
const out=resolve(process.env.HOUSEHOLD_BUILD_OUT??(unsigned?'artifacts/android-unsigned':'artifacts/hana-android'));mkdirSync(out,{recursive:true});
const signing=resolve('data/android-signing'),password=join(signing,'password'),keystore=join(signing,'household.p12');
if(!unsigned&&(!existsSync(password)||!existsSync(keystore)))throw Error('The existing release signing key and password file are required. For local compilation use --unsigned.');
const privateWelcome=process.env.HOUSEHOLD_PRIVATE_WELCOME==='1';
if(privateWelcome&&!process.env.HOUSEHOLD_BUILD_OUT)throw Error('Private family builds require a separate HOUSEHOLD_BUILD_OUT directory');
const welcomeBundle=join(out,privateWelcome?'private-bundle':'public-bundle');
const welcomeAssets=join(welcomeBundle,'assets');
{
  const dest=join(welcomeAssets,'welcome');mkdirSync(dest,{recursive:true});
  for(const name of ['index.html','welcome.css','welcome.js'])copyFileSync(resolve('mobile-shared/welcome',name),join(dest,name));
  if(privateWelcome)for(const name of ['family-first.jpg','family-second.jpg'])copyFileSync(resolve('data/private-branding',name),join(dest,name));
}
if(!privateWelcome&&readdirSync(join(welcomeAssets,'welcome')).some(n=>!['index.html','welcome.css','welcome.js'].includes(n)))throw Error('Unexpected public welcome asset');
const manifestSource=readFileSync('android-collector/AndroidManifest.xml','utf8');
const version=manifestSource.match(/android:versionName="([^"]+)"/)[1];
const versionCode=Number(manifestSource.match(/android:versionCode="([0-9]+)"/)[1]);
const classes=join(out,'classes');mkdirSync(classes,{recursive:true});
const run=(file,args)=>{const r=spawnSync(file,args,{encoding:'utf8',windowsHide:true,timeout:120000});
  if(r.status!==0||r.error)throw Error((r.stderr||r.stdout||r.error?.message||'build failed').slice(0,5000));return r.stdout;};
const source=resolve('android-collector/src/kr/household/hanacollector');
const sources=readdirSync(source).filter(n=>n.endsWith('.java')).map(n=>join(source,n));
run(javaTool('javac'),['-encoding','UTF-8','--release','8','-classpath',sdk,'-d',classes,...sources]);
const tests=join(out,'tests');mkdirSync(tests,{recursive:true});
for(const name of ['CapturePolicyTest','WelcomeRouteTest','CardUiStateTest']){
  run(javaTool('javac'),['-encoding','UTF-8','-classpath',classes,'-d',tests,resolve('android-collector/test',name+'.java')]);
  const testClass=name==='CapturePolicyTest'?name:'kr.household.hanacollector.'+name;
  process.stdout.write(run(javaTool('java'),['-Dfile.encoding=UTF-8','-classpath',[classes,tests].join(delimiter),testClass]));
}
run(javaTool('jar'),['--create','--file',join(out,'classes.jar'),'-C',classes,'.']);
run(javaTool('java'),['-cp',join(build,'lib/d8.jar'),'com.android.tools.r8.D8','--release','--min-api','31','--lib',sdk,'--output',out,join(out,'classes.jar')]);
run(buildTool('aapt2'),['compile','--dir',resolve('android-collector/res'),'-o',join(out,'resources.zip')]);
// Windows aapt2 -A produced backslashes in ZIP entry names; Android AssetManager
// needs literal forward-slash paths. The JDK jar writer normalizes archive names.
run(buildTool('aapt2'),['link','-I',sdk,'--manifest',resolve('android-collector/AndroidManifest.xml'),join(out,'resources.zip'),'-o',join(out,'unsigned.apk')]);
run(javaTool('jar'),['--update','--file',join(out,'unsigned.apk'),'-C',out,'classes.dex','-C',welcomeBundle,'assets']);
const aligned=join(out,unsigned?'household-hana-diagnostic-unsigned.apk':'aligned.apk');
run(buildTool('zipalign'),['-f','-p','4',join(out,'unsigned.apk'),aligned]);
const apk=unsigned?aligned:join(out,'household-hana-diagnostic.apk');
let verification='Unsigned local build';
if(!unsigned){
  run(javaTool('java'),['-jar',join(build,'lib/apksigner.jar'),'sign','--ks',keystore,'--ks-key-alias','household','--ks-pass','file:'+password,'--out',apk,aligned]);
  verification=run(javaTool('java'),['-jar',join(build,'lib/apksigner.jar'),'verify','--verbose','--print-certs',apk]);
  if(!verification.includes('certificate SHA-256 digest: 8974f47b23d74ecfee190b204d1e0f8b51e8d00107b029659800b8bbff2f45a8'))throw Error('APK signer differs from the installed release.');
}
const entries=run(javaTool('jar'),['--list','--file',apk]).split(/\r?\n/).filter(Boolean);
const wanted=['index.html','welcome.css','welcome.js',...(privateWelcome?['family-first.jpg','family-second.jpg']:[])].map(n=>'assets/welcome/'+n).sort();
const actual=entries.filter(n=>n.startsWith('assets/')&&!n.endsWith('/')).sort();
if(entries.some(n=>n.includes('\\'))||new Set(entries).size!==entries.length||JSON.stringify(actual)!==JSON.stringify(wanted))throw Error('Invalid raw APK resource paths');
const permissions=run(buildTool('aapt2'),['dump','permissions',apk]);
const manifest=run(buildTool('aapt2'),['dump','xmltree','--file','AndroidManifest.xml',apk]);
const badging=run(buildTool('aapt2'),['dump','badging',apk]);
if(!badging.includes("application-label:'째미즈 asset'")||!manifest.includes('ic_launcher')&&!badging.includes('application-icon'))throw Error('App branding missing');
const sha256=createHash('sha256').update(readFileSync(apk)).digest('hex');
writeFileSync(join(out,'verification.txt'),verification+'\n'+permissions+'\n'+manifest+'\n'+badging+'\nSHA256 '+sha256+'\n');
writeFileSync(join(out,'build-info.json'),JSON.stringify({appName:'째미즈 asset',version,versionCode,sha256,bytes:readFileSync(apk).length,signed:!unsigned,distribution:unsigned?'unsigned-candidate':privateWelcome?'private-family-preview':'public',containsPrivateFamilyPhotos:privateWelcome,network:'fixed authenticated enrollment, invitation approval and monthly collection; no merchant or notification body',diagnostics:'encrypted local queue; Hana latest 32 content-free callbacks for 7 days; NH encrypted 31-day/1024-delivery journal and local ACK daily totals; bounded retries',deviceTested:false},null,2)+'\n');
console.log(permissions.trim());console.log('APK verified, SHA256 '+sha256);
