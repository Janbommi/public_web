import {spawnSync} from 'node:child_process';
import {mkdirSync,mkdtempSync,readdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
const parent=resolve('artifacts/kb-parser-tests');mkdirSync(parent,{recursive:true});const out=mkdtempSync(join(parent,'run-'));
const root=resolve('artifacts/android-tools/jdk'),jdk=join(root,readdirSync(root).find(n=>n.startsWith('jdk-')),'bin');
function run(exe,args){const r=spawnSync(join(jdk,exe+'.exe'),args,{encoding:'utf8',windowsHide:true,timeout:60000});if(r.status!==0||r.error)throw Error(r.stderr||r.stdout||String(r.error));process.stdout.write(r.stdout);}
const src=resolve('android-collector/src/kr/household/hanacollector');
run('javac',['-encoding','UTF-8','--release','11','-d',out,join(src,'KbPushParser.java'),join(src,'CaptureOutbox.java'),resolve('android-collector/test/KbPushParserTest.java')]);
run('java',['-classpath',out,'KbPushParserTest']);
