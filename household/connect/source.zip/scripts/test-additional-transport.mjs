import {spawnSync} from 'node:child_process';
import {mkdirSync,mkdtempSync,readdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
const dir=resolve('artifacts/additional-transport-tests');mkdirSync(dir,{recursive:true});const out=mkdtempSync(join(dir,'run-'));
const jdk=resolve('artifacts/android-tools/jdk',readdirSync('artifacts/android-tools/jdk').find(n=>n.startsWith('jdk-')),'bin');
const run=(name,args)=>{const r=spawnSync(join(jdk,name+'.exe'),args,{encoding:'utf8',windowsHide:true,timeout:60000});if(r.status!==0)throw Error(r.stderr||r.stdout);console.log(r.stdout.trim());};
run('javac',['-encoding','UTF-8','--release','8','-d',out,...['CaptureOutbox','KbTransport','NhTransport','ShinhanTransport'].map(n=>'android-collector/src/kr/household/hanacollector/'+n+'.java'),'android-collector/test/AdditionalTransportTest.java']);
run('java',['-cp',out,'AdditionalTransportTest']);
