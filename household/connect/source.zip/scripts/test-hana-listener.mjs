import {spawnSync} from 'node:child_process';
import {mkdirSync,mkdtempSync,readdirSync} from 'node:fs';
import {join,resolve} from 'node:path';

// Run actual listener/store sources against narrow host-side Android API doubles.
// Does not build/sign/publish an APK or touch a real device, token, server or DB.
const parent=resolve('artifacts/hana-listener-tests');mkdirSync(parent,{recursive:true});
const out=mkdtempSync(join(parent,'run-')),classes=join(out,'classes'),prefs=join(out,'preferences');
mkdirSync(classes);mkdirSync(prefs);
const jdkRoot=resolve('artifacts/android-tools/jdk');
const jdk=join(jdkRoot,readdirSync(jdkRoot).find(name=>name.startsWith('jdk-')),'bin');
function files(dir){return readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(join(dir,e.name)):e.name.endsWith('.java')?[join(dir,e.name)]:[]);}
function run(exe,args){const r=spawnSync(join(jdk,exe+'.exe'),args,{encoding:'utf8',windowsHide:true,timeout:60000});if(r.status!==0||r.error)throw Error(r.stderr||r.stdout||String(r.error));process.stdout.write(r.stdout);}
const src=resolve('android-collector/src/kr/household/hanacollector');
run('javac',['-encoding','UTF-8','--release','8','-d',classes,...files(resolve('android-collector/test/listener-stubs')),...['CapturePolicy','CaptureOutbox','KbTransport','KbPushParser','HanaPushParser','DiagnosticHistory','DiagnosticStore','HanaListener'].map(n=>join(src,n+'.java'))]);
for(const phase of ['capture','restore'])run('java',['-Dtest.preferences='+prefs,'-classpath',classes,'kr.household.hanacollector.ListenerFlowTest',phase]);
console.log('Two separate JVM runs passed. This does not emulate Android permission delivery, battery policy or asynchronous disk durability.');
