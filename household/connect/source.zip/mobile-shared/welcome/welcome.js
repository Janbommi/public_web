(() => {
  'use strict';
  const params=new URLSearchParams(location.search),preview=params.get('preview')==='1';
  if(params.get('reduceMotion')==='1')document.documentElement.classList.add('reduce-motion');
  let finished=false,timer;
  function finish(){if(finished)return;finished=true;clearTimeout(timer);
    if(preview){location.reload();return;}
    document.querySelector('.welcome').classList.add('leaving');
    setTimeout(()=>{location.href='asset-app://continue';},220);
  }
  document.querySelector('#continue').addEventListener('click',finish);
  document.querySelectorAll('img').forEach(img=>img.addEventListener('error',()=>img.closest('figure').classList.add('missing-photo')));
  // Native host owns the fail-open timeout. Screen-reader mode waits for the button.
  if(!preview&&params.get('stay')!=='1'){
    const images=[...document.images].map(img=>img.complete?Promise.resolve():new Promise(resolve=>{img.addEventListener('load',resolve,{once:true});img.addEventListener('error',resolve,{once:true});}));
    Promise.all(images).then(()=>{if(!finished)timer=setTimeout(finish,3000);});
  }
  if(preview)document.querySelector('#continue').firstChild.textContent='다시 보기 ';
})();
