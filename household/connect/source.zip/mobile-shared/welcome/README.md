# 가족 시작 화면

Android WebView와 iOS WKWebView가 공유하는 시작 화면 코드. 사진 두 장의 순차 페이드인과 앱 이름, 시작하기 버튼만 표시한다. 2026-10-28 사용자 지시에 따라 명언·사진 설명·영문 장식·하단 문구와 교대 로직을 제거했다.

사진 원본은 `data/private-branding`에 보관하고 이 코드 디렉터리에는 넣지 않는다. Android 공개 APK는 HTML/CSS/JS만 포함한다. 네이티브가 기존 카드 키로 서버에서 인증된 사진을 받아 Android Keystore AES-GCM으로 백업 제외 영역에 저장한다. 캐시 최대 24시간 이후에는 다시 서버 인증이 필요하며 WebView에는 키를 전달하지 않는다.

미리보기: `node scripts/preview-welcome.mjs` → `http://127.0.0.1:4386/?preview=1`. 사진은 원본 그대로 사용한다. `&reduceMotion=1`은 동작 줄이기, `&stay=1`은 자동 종료 방지다. 일반 실행은 사진 요청 완료 후 3초 뒤 종료하며 Android 호스트는 최대 15초 뒤 홈으로 진행한다. 화면 읽기 모드는 버튼으로 종료한다.

비공개 시험 빌드만 `HOUSEHOLD_PRIVATE_WELCOME=1`과 별도 `HOUSEHOLD_BUILD_OUT`을 지정해 사진을 번들에 넣을 수 있다. 해당 결과는 public_web·공개 릴리스·소스 압축에 복사하지 않는다.

iOS는 `node scripts/prepare-private-welcome.mjs`와 `ios-app/FamilyWelcomeView.swift`로 비공개 시험 리소스를 준비한다. 공개용 인증 캐시·앱 프로젝트·서명·실기기 검증은 후속 작업이다. 시스템 LaunchScreen은 같은 배경색의 정적 화면이다.

HTML은 외부 자원과 네트워크를 차단한다. `asset-app://continue`는 호스트가 처리하는 종료 신호이며 계정·키·알림 브리지가 없다. 앱 현황판 통합·기기 초대·자동 카드 연결은 별도 작업이다.
