package kr.household.hanacollector;

public final class CardUiStateTest {
    private static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    public static void main(String[] args){
        check(!CardUiState.missing().canConfirm&&CardUiState.missing().done==-1,"missing is not zero or confirmed");
        check(!CardUiState.unreadable().title.equals(CardUiState.missing().title),"read failure distinct from missing key");
        int[] counts={3,2,1,1};
        CardUiState pending=CardUiState.of(false,false,false,counts,0,"");
        check(!pending.canConfirm&&pending.title.equals("새 알림 대기"),"waiting has no false confirmation action");
        check(CardUiState.of(false,false,true,counts,0,"").canConfirm,"fresh candidate enables explicit consent");
        CardUiState paused=CardUiState.of(true,false,true,counts,5,"");
        check(!paused.canConfirm&&paused.title.equals("일시중지")&&paused.detail.contains("전송 확인 필요")&&paused.pending==2,"paused remains visible alongside pending/retry");
        check(CardUiState.of(true,true,false,counts,0,"").title.equals("자동 집계 켜짐"),"enabled does not imply complete collection");
        long now=CaptureOutbox.MAX_AGE+10000;
        check(CardUiState.fresh(now-1,now),"recent candidate");
        check(!CardUiState.fresh(now-CaptureOutbox.MAX_AGE,now)&&!CardUiState.fresh(now+1,now)&&!CardUiState.fresh(0,now),"expired future and absent candidates rejected");
        System.out.println("Card UI states: missing, unreadable, pending, confirmation, enabled, paused, retry and expiry passed");
    }
}
