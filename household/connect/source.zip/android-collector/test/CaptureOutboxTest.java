import kr.household.hanacollector.CaptureOutbox;
import kr.household.hanacollector.EncryptedOutboxStore;
import static kr.household.hanacollector.CaptureOutbox.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import javax.crypto.*;

public final class CaptureOutboxTest {
    static final long NOW=1792378800000L;
    static void check(boolean value){if(!value)throw new AssertionError();}
    static String key(int n){return String.format("%064x",n);}
    static final class Memory implements Store {
        byte[] data;boolean fail;
        public byte[] read(){return data==null?null:data.clone();}
        public void commit(byte[] bytes)throws IOException{if(fail)throw new IOException("test disk full");data=bytes.clone();}
    }
    static Item add(CaptureOutbox q,Card c,int receipt,int evidence,long amount)throws IOException{return q.observe(c,key(receipt),key(evidence),amount,NOW,NOW);}
    public static void main(String[] args)throws Exception {
        Memory store=new Memory();CaptureOutbox q=new CaptureOutbox(store);
        Item a=add(q,Card.HANA_MOVING,1,11,12000);
        check(a.state==State.WAITING_VERIFICATION&&q.begin(NOW)==null);
        q.verify(Card.HANA_MOVING);Item sent=q.begin(NOW);check(sent.id.equals(a.id)&&sent.attempts==1);
        check(q.begin(NOW)==null); // Only one request in flight.
        q=new CaptureOutbox(store);check(q.begin(NOW+60000)==null); // Restoring data never grants upload authority.
        q.verify(Card.HANA_MOVING);sent=q.begin(NOW+60000);check(sent.id.equals(a.id));
        q.complete(sent.id,1,Outcome.UNAUTHORIZED,NOW+60000);check(q.snapshot().get(0).state==State.SENDING); // Late previous attempt cannot mutate this attempt.
        q.complete(sent.id,sent.attempts,Outcome.DUPLICATE,NOW+60000);check(q.snapshot().get(0).state==State.ACKNOWLEDGED);
        check(add(q,Card.HANA_MOVING,1,11,12000).id.equals(a.id)&&q.snapshot().size()==1);
        Item ambiguous=add(q,Card.HANA_MOVING,2,11,12000);check(ambiguous.state==State.REVIEW&&!ambiguous.id.equals(a.id)&&ambiguous.possibleDuplicateOf.equals(a.id));
        check(add(q,Card.HANA_MOVING,1,12,13000).state==State.REVIEW); // Changed payload never overwrites a sent event.
        Item sameMinute=add(q,Card.HANA_MOVING,3,13,12000);check(sameMinute.state==State.REVIEW&&!sameMinute.id.equals(a.id)); // Preserve, but do not auto-count ambiguous repeats.
        Item distinct=q.observe(Card.HANA_MOVING,key(4),key(14),12000,NOW+60000,NOW+60000);check(distinct.state==State.READY&&!distinct.id.equals(a.id));
        Item other=add(q,Card.NH_ZGM,1,11,12000);check(other.state==State.WAITING_VERIFICATION); // Card isolation.
        int size=q.snapshot().size();store.fail=true;
        try{add(q,Card.HANA_MOVING,5,15,14000);throw new AssertionError();}catch(IOException expected){}
        check(q.snapshot().size()==size);store.fail=false;
        for(int i=0;i<MAX_ATTEMPTS;i++){Item current=q.begin(NOW+1000000L*(i+1));check(current.id.equals(distinct.id));q.complete(current.id,current.attempts,Outcome.RETRYABLE,NOW+1000000L*(i+1));}
        check(q.begin(NOW+10000000)==null); // No infinite retry.
        q.verify(Card.NH_ZGM);sent=q.begin(NOW+10000000);check(sent.id.equals(other.id));q.complete(sent.id,sent.attempts,Outcome.UNAUTHORIZED,NOW+10000000);
        check(q.begin(NOW+20000000)==null&&q.snapshot().get(5).state==State.BLOCKED);
        for(Card c:Card.values()){Memory m=new Memory();CaptureOutbox one=new CaptureOutbox(m);one.verify(c);check(add(one,c,1,1,100).state==State.READY);}
        Memory failing=new Memory();CaptureOutbox blocked=new CaptureOutbox(failing);blocked.verify(Card.KB_COUPANG);add(blocked,Card.KB_COUPANG,1,1,100);failing.fail=true;
        try{blocked.begin(NOW);throw new AssertionError();}catch(IOException expected){}check(blocked.snapshot().get(0).state==State.READY);
        Memory corrupt=new Memory();corrupt.data=new byte[]{0,1,2};try{new CaptureOutbox(corrupt);throw new AssertionError();}catch(IOException expected){}
        Path directory=Paths.get(args[0]);Files.createDirectories(directory);Path file=directory.resolve("synthetic-outbox.bin");
        KeyGenerator generator=KeyGenerator.getInstance("AES");generator.init(256);SecretKey secret=generator.generateKey();
        EncryptedOutboxStore encrypted=new EncryptedOutboxStore(file,secret);CaptureOutbox disk=new CaptureOutbox(encrypted);
        Item saved=add(disk,Card.SHINHAN_KPASS,99,98,98765);byte[] first=Files.readAllBytes(file);
        check(!new String(first,java.nio.charset.StandardCharsets.ISO_8859_1).contains(saved.id));
        check(new CaptureOutbox(encrypted).snapshot().get(0).id.equals(saved.id));
        byte[] plain=encrypted.read();encrypted.commit(plain);check(!Arrays.equals(first,Files.readAllBytes(file))); // Fresh nonce for every write.
        byte[] damaged=Files.readAllBytes(file);damaged[damaged.length-1]^=1;Files.write(file,damaged);
        try{new CaptureOutbox(encrypted);throw new AssertionError();}catch(IOException expected){}
        check(Arrays.equals(damaged,Files.readAllBytes(file))); // Corruption never silently erases pending purchases.
        System.out.println("Common outbox: authorization, card isolation, durable IDs, ambiguous duplicates, retries, atomic failures and encrypted storage passed.");
    }
}
