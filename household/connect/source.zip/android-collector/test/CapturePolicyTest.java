import kr.household.hanacollector.CapturePolicy;
import kr.household.hanacollector.HanaPushParser;
import kr.household.hanacollector.DiagnosticHistory;
import kr.household.hanacollector.DiagnosticSyncState;
public class CapturePolicyTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    public static void main(String[] args){
        check(CapturePolicy.accepts("com.hanaskcard.paycla",false,false));
        check(!CapturePolicy.accepts("com.kakao.talk",false,false));
        check(!CapturePolicy.accepts("com.hanaskcard.paycla.fake",false,false));
        check(!CapturePolicy.accepts("com.hanaskcard.paycla",true,false));
        check(!CapturePolicy.accepts("com.hanaskcard.paycla",false,true));
        check(!CapturePolicy.tokenValid("invalid"));check(CapturePolicy.tokenValid("a".repeat(64)));
        String diagnostic=CapturePolicy.safeReport("가상 이름 9999","승인 12,345원 10/18 가상상점");
        for(String secret:new String[]{"가상 이름","9999","12,345","10/18","가상상점"})check(!diagnostic.contains(secret));
        check(CapturePolicy.PROBE_BODY.equals("{\"type\":\"probe\"}"));
        check(CapturePolicy.ENDPOINT.startsWith("https://xcchskngoactqsiiutsp.supabase.co/"));
        long posted=java.time.Instant.parse("2026-10-18T03:35:00Z").toEpochMilli();
        String body="가상 상점 / 신용(일시불,1*2*) / 10.18 12:34 / 누적이용금액 987,654원";
        HanaPushParser.Result parsed=HanaPushParser.parse("(결제) 12,345원",body,posted);
        check(parsed!=null&&parsed.amount==12345&&parsed.maskedCard.equals("1*2*"));
        check(!parsed.localDisplay().contains("987,654")&&!parsed.localDisplay().contains("가상 상점"));
        check(HanaPushParser.parse("(취소) 12,345원",body,posted)==null);
        check(HanaPushParser.parse("(결제) 12,345원",body.replace("일시불","할부"),posted)==null);
        check(HanaPushParser.parse("(결제) 12,345원",body.replace("12:34","24:34"),posted)==null);
        check(HanaPushParser.parse("(결제) 12,345원",body.replace("10.18","02.30"),posted)==null);
        check(HanaPushParser.parse("(결제) 12,345USD",body,posted)==null);
        check(HanaPushParser.parse("(결제) 1,23원",body,posted)==null);
        check(HanaPushParser.parse("(결제) 12,345원",body.replace("1*2*","****"),posted)==null);
        long newYear=java.time.Instant.parse("2026-12-31T15:01:00Z").toEpochMilli();
        check(HanaPushParser.parse("(결제) 12,345원",body.replace("10.18 12:34","12.31 23:59"),newYear)!=null);
        // Recreate the journal from its persisted representation, as after process restart.
        DiagnosticHistory history=new DiagnosticHistory();
        history.capture("(결제) 12,345원",body,true,posted);
        history.capture("가상 알림", "본문이 가려졌습니다", false,posted+1000);
        String saved=history.encode();
        DiagnosticHistory nextDay=DiagnosticHistory.decode(saved,posted+24*60*60*1000L);
        check(nextDay.size()==2&&nextDay.parsedCount()==1);
        check(DiagnosticHistory.decode(saved,posted+16*60*1000L).size()==2);
        check(nextDay.report().contains("결제 건수 아님"));
        for(String secret:new String[]{"12,345","987,654","가상 상점","1*2*","10.18 12:34","본문이 가려졌습니다"}){
            check(!saved.contains(secret));check(!nextDay.report().contains(secret));
        }
        check(saved.matches("1(?:;[0-9]+,[0-9]+,[0-9]+)*"));
        // The limit is callbacks, not deduplicated purchases. Old entries expire individually.
        check(DiagnosticHistory.decode(saved,posted+DiagnosticHistory.RETENTION_MS).size()==1);
        check(DiagnosticHistory.decode(saved,posted+DiagnosticHistory.RETENTION_MS+1000).size()==0);
        check(DiagnosticHistory.decode(saved,posted-1).size()==0);
        DiagnosticHistory capped=new DiagnosticHistory();
        for(int i=0;i<40;i++)capped.capture("", "",i>=8,posted+i);
        check(capped.size()==32&&capped.parsedCount()==32);
        check(DiagnosticHistory.decode(capped.encode(),posted+100).size()==32);
        for(String corrupt:new String[]{"raw notification", "2;1,1,1", "1;bad,1,1", "1;1,-1,1", "1;1,20001,1", "1;1,1,128", "1;1,1", "1;0,1,1", "x".repeat(5000)})
            check(DiagnosticHistory.decode(corrupt,posted).size()==0);
        check(DiagnosticHistory.decode(null,posted).size()==0);
        String upload=nextDay.uploadJson(posted+24*60*60*1000L,true);
        check(upload.contains("\"observations\":2")&&upload.contains("\"parsedCount\":1"));
        check(upload.contains("\"listenerConnected\":true")&&upload.length()<1024);
        for(String secret:new String[]{"12,345","987,654","가상 상점","1*2*","10.18 12:34"})check(!upload.contains(secret));
        check(new DiagnosticHistory().uploadJson(posted,true).contains("\"lastObservedAt\":null"));
        DiagnosticSyncState sync=new DiagnosticSyncState();check(!sync.canRun());sync.changed(false);check(sync.canRun());
        long sent=sync.generation;sync.attempts++;sync.changed(false);sync.completed(sent,0,200,posted);
        check(sync.canRun()&&sync.acknowledged==sent); // A new receipt during upload remains pending.
        for(int i=0;i<5;i++){check(sync.canRun());sync.attempts++;sync.completed(sync.generation,0,503,posted);}
        check(!sync.canRun());sync.changed(false);check(sync.canRun());
        sync.completed(sync.generation,0,401,posted);check(!sync.canRun());sync.changed(false);check(!sync.canRun());
        sync.keyChanged();check(sync.canRun());sync.completed(sync.generation,0,401,posted);check(sync.canRun()); // Old key response cannot block new key.
        sync.enabled=false;check(!sync.canRun());sync.enabled=true;
        sync.completed(sync.generation,sync.keyEpoch,200,posted);check(!sync.canRun()&&sync.lastSuccess==posted);
        boolean rejected=false;try{history.capture("x".repeat(20001),"",false,posted);}catch(IllegalArgumentException expected){rejected=true;}check(rejected);
        System.out.println("Capture policy assertions passed");
    }
}
