import kr.household.hanacollector.KbPushParser;
import kr.household.hanacollector.CaptureOutbox;
import java.time.Instant;
import java.util.Arrays;

/** Entirely fictional input, including date/card/merchant/name/amount. */
public final class KbPushParserTest {
    private static int checks;
    static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static final String TEXT="KB국민카드1234승인 테*트님 12,345원 일시불 06/15 12:34\n가상상점 누적98,765원";
    static final long POSTED=Instant.parse("2026-06-15T03:35:00Z").toEpochMilli();
    static void reject(String body,String why){check(KbPushParser.parse(body,POSTED)==null,why);}
    public static void main(String[] args)throws Exception {
        KbPushParser.Result r=KbPushParser.parse(TEXT,POSTED);
        check(r!=null,"supported body");check(r.amount==12345,"purchase only, not cumulative");
        check(r.cumulative==98765,"cumulative is separate local evidence");check(r.cardDisplay.equals("1234"),"card discriminator");
        check(r.occurredAt==Instant.parse("2026-06-15T03:34:00Z").toEpochMilli(),"KST occurrence");
        check(KbPushParser.parse(TEXT.replace("\n","   "),POSTED)!=null,"line wrap independent");
        check(KbPushParser.parse(TEXT.replace("12,345","12345"),POSTED)!=null,"unformatted integer");
        check(KbPushParser.parse(TEXT.replace("1234승인","1*3* 승인"),POSTED)!=null,"partial card discriminator");
        for(String unsupported:Arrays.asList(
            TEXT.replace("승인","승인취소"),TEXT.replace("승인","취소"),TEXT.replace("승인","거절"),
            TEXT.replace("일시불","03개월"),TEXT.replace("일시불","할부"),TEXT.replace("12,345원","12.34USD"),
            TEXT.replace("KB국민카드","KB체크카드"),TEXT.replace("1234승인","****승인"),
            TEXT.replace("12,345원","1,23원"),TEXT.replace("12,345원","0원"),TEXT.replace("12,345원","-12345원"),
            TEXT.replace("12,345원","1,000,000,001원"),TEXT.replace("98,765원","12,344원"),
            TEXT.replace("98,765원","100,000,000,001원"),TEXT.replace("98,765원","9,87원"),
            TEXT.replace("06/15","02/30"),TEXT.replace("06/15","06/12"),TEXT.replace("12:34","24:34"),
            TEXT.replace("12:34","12:41"),TEXT.replace("누적98,765원",""),TEXT.replace("가상상점 ",""),
            TEXT+" 추가 안내",TEXT+"\n"+TEXT,TEXT.replace("가상상점","다른 결제 5,000원"),
            "일부 내용 가림", "[광고] "+TEXT, "KB국민카드1234승인..."))reject(unsupported,"unsupported shape");
        reject(null,"null");reject("x".repeat(2001),"bounded input");
        check(KbPushParser.parse(TEXT,0)==null,"missing post time");
        check(KbPushParser.parse(TEXT,Instant.parse("2026-06-15T03:29:00Z").toEpochMilli())!=null,"five-minute skew boundary");
        check(KbPushParser.parse(TEXT,Instant.parse("2026-06-17T03:34:00Z").toEpochMilli())!=null,"48-hour boundary");
        check(KbPushParser.parse(TEXT,Instant.parse("2026-06-17T03:34:00.001Z").toEpochMilli())==null,"older than 48 hours");
        KbPushParser.Result year=KbPushParser.parse(TEXT.replace("06/15 12:34","12/31 23:59"),Instant.parse("2026-12-31T15:01:00Z").toEpochMilli());
        check(year!=null&&year.occurredAt==Instant.parse("2026-12-31T14:59:00Z").toEpochMilli(),"new year");
        check(KbPushParser.parse(TEXT.replace("06/15 12:34","02/29 12:34"),Instant.parse("2028-02-29T03:35:00Z").toEpochMilli())!=null,"leap year");
        for(java.lang.reflect.Field f:KbPushParser.Result.class.getDeclaredFields())check(Arrays.asList("amount","occurredAt","cumulative","cardDisplay").contains(f.getName()),"no raw text/name/merchant fields");
        final byte[][] saved={null};CaptureOutbox.Store store=new CaptureOutbox.Store(){public byte[] read(){return saved[0];}public void commit(byte[] b){saved[0]=b;}};
        CaptureOutbox outbox=new CaptureOutbox(store);
        CaptureOutbox.Item kb=outbox.observe(CaptureOutbox.Card.KB_COUPANG,"a".repeat(64),"b".repeat(64),r.amount,r.occurredAt,POSTED);
        check(outbox.begin(POSTED)==null,"KB must await explicit verification");
        outbox.verify(CaptureOutbox.Card.HANA_MOVING);check(outbox.begin(POSTED)==null,"Hana verification cannot unlock KB");
        outbox.verify(CaptureOutbox.Card.KB_COUPANG);CaptureOutbox.Item send=outbox.begin(POSTED);
        check(send.card==CaptureOutbox.Card.KB_COUPANG&&send.amount==12345,"normalized card and purchase amount preserved");
        outbox.complete(send.id,send.attempts,CaptureOutbox.Outcome.ACCEPTED,POSTED);
        check(outbox.observe(CaptureOutbox.Card.KB_COUPANG,"a".repeat(64),"b".repeat(64),r.amount,r.occurredAt,POSTED).id.equals(kb.id),"exact replay remains one event");
        check(outbox.observe(CaptureOutbox.Card.KB_COUPANG,"c".repeat(64),"b".repeat(64),r.amount,r.occurredAt,POSTED).state==CaptureOutbox.State.REVIEW,"ambiguous delivery not double counted");
        check(new CaptureOutbox(store).begin(POSTED)==null,"restart does not persist verification authorization");
        System.out.println("PASS: "+checks+" KB parser, calendar, privacy and card-isolation assertions (synthetic only).");
    }
}
