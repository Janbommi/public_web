package kr.household.hanacollector;

public final class WelcomeRouteTest {
    private static void check(boolean value){if(!value)throw new AssertionError();}
    public static void main(String[] args){
        String base=WelcomeRoute.BASE;
        for(String name:new String[]{"index.html","welcome.css","welcome.js","family-first.jpg","family-second.jpg"})check(name.equals(WelcomeRoute.resource(base+name)));
        check("index.html".equals(WelcomeRoute.resource(base+"index.html?reduceMotion=0&stay=1")));
        for(String url:new String[]{
            "file:///android_asset/welcome/family-first.jpg", "https://example.com/welcome/family-first.jpg",
            "https://appassets.androidplatform.net.evil.invalid/welcome/index.html",
            "https://user@appassets.androidplatform.net/welcome/index.html",
            "http://appassets.androidplatform.net/welcome/index.html",base+"../index.html",base+"%2e%2e/index.html",
            base+"family-first.jpg?token=anything",base+"unknown.jpg",base+"index.html#fragment",base+"index.html?anything=1"
        })check(WelcomeRoute.resource(url)==null);
        // A listener may keep the process alive after the Activity has been closed.
        check(WelcomeRoute.shouldShow(false,true));
        check(WelcomeRoute.shouldShow(false,false));
        // Process recreation with saved Activity state is a fresh app entry, not a rotation.
        check(WelcomeRoute.shouldShow(true,false));
        check(!WelcomeRoute.shouldShow(true,true));
        System.out.println("Welcome routes: local resources, private image route, denied origins, task recreation passed");
    }
}
