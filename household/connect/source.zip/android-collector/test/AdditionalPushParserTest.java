import kr.household.hanacollector.AdditionalPushParser;
import static kr.household.hanacollector.AdditionalPushParser.Issuer.*;
import java.time.Instant;

/** Fictional values only; no screenshot contents copied into fixtures. */
public final class AdditionalPushParserTest {
    static int count;static void check(boolean value){count++;if(!value)throw new AssertionError("case "+count);}
    static String nh="NH카드1*3*승인\n가*상\n12,300원 일시불\n10/23 11:12\n가상상점\n총누적456,700원";
    static String sh="[신한카드(2468)승인] 가*상\n- 승인금액: 12,300원(일시불)\n- 승인일시: 10/23 11:12\n- 가맹점명: 가상상점\n- 누적금액: 456,700원\n\n[신한카드 0000-0000]";
    public static void main(String[] args){
        long at=Instant.parse("2026-10-23T02:13:00Z").toEpochMilli();
        for(AdditionalPushParser.Issuer issuer:AdditionalPushParser.Issuer.values()){
            String body=issuer==NH?nh:sh;
            AdditionalPushParser.Result r=AdditionalPushParser.parse(issuer,body,at);
            check(r!=null&&r.issuer==issuer&&r.amount==12300&&r.cumulative==456700);
            check(r.occurredAt==Instant.parse("2026-10-23T02:12:00Z").toEpochMilli());
            check(AdditionalPushParser.parse(issuer==NH?SHINHAN:NH,body,at)==null);
            for(String invalid:new String[]{body.replace("승인","취소"),body.replace("일시불","3개월"),body.replace("12,300원","12,300USD"),body.replace("12,300","1,23"),body.replace("12,300","0"),body.replace("11:12","24:12"),body.replace("10/23","02/30"),body+" "+body,body.replace("가상상점","승인 55,000원"),body.replace("456,700","100,000,000,001")})check(AdditionalPushParser.parse(issuer,invalid,at)==null);
            check(AdditionalPushParser.parse(issuer,body,at+3*86400000L)==null);
            check(AdditionalPushParser.parse(issuer,body,at-600000L)==null);
            check(AdditionalPushParser.parse(issuer,body.replace("456,700","0"),at)!=null); // unknown issuer basis is not guessed from amount ordering
            check(AdditionalPushParser.fromExtras(issuer,"축약…",body,at)!=null);
            check(AdditionalPushParser.fromExtras(issuer,body,body.replace("456,700","456,800"),at)==null);
            check(AdditionalPushParser.fromExtras(issuer,body,"내용 비공개",at)==null);
            check(AdditionalPushParser.fromExtras(issuer,body,null,at)!=null);
            long newYear=Instant.parse("2026-12-31T15:01:00Z").toEpochMilli();
            check(AdditionalPushParser.parse(issuer,body.replace("10/23 11:12","12/31 23:59"),newYear)!=null);
            check(AdditionalPushParser.parse(issuer,body.replace("10/23","02/29"),Instant.parse("2028-02-29T02:13:00Z").toEpochMilli())!=null);
            check(AdditionalPushParser.parse(issuer,null,at)==null);
            for(java.lang.reflect.Field f:r.getClass().getFields())check(!f.getName().matches(".*(?i:name|merchant|body|raw).*"));
        }
        check(AdditionalPushParser.parse(NH,nh.replace("1*3*","****"),at)==null);
        check(AdditionalPushParser.parse(SHINHAN,sh.replace("2468","****"),at)==null);
        System.out.println("PASS: "+count+" NH/Shinhan shape, privacy, calendar and extras assertions (synthetic only).");
    }
}
