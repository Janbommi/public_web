import kr.household.hanacollector.*;
import java.util.*;
public final class AdditionalTransportTest {
    static class Store implements CaptureOutbox.Store {byte[] b;public byte[] read(){return b;}public void commit(byte[] v){b=v;}}
    static void check(boolean b){if(!b)throw new AssertionError();}
    static String hash(int i){return String.format("%064x",i);}
    public static void main(String[] args)throws Exception {
        long now=java.time.Instant.parse("2026-11-01T00:00:00Z").toEpochMilli();
        Store st=new Store();CaptureOutbox q=new CaptureOutbox(st);
        CaptureOutbox.Item nh=q.observeNh(hash(1),hash(2),3400,now,now,45600,now);
        CaptureOutbox.Item sh=q.observeShinhan(hash(1),hash(2),3400,now,now,45600,now);
        check(nh.state==CaptureOutbox.State.WAITING_VERIFICATION&&sh.state==CaptureOutbox.State.WAITING_VERIFICATION);
        check(!nh.id.equals(sh.id));check(q.begin(now)==null);
        String a=NhTransport.purchase(nh),b=ShinhanTransport.purchase(sh);
        check(a.contains("nh-pay-krw-onetime-v1")&&b.contains("shinhan-pay-krw-onetime-v1"));
        for(String forbidden:new String[]{"cardDisplay","receipt","evidence","merchant","mask","token"})check(!a.contains(forbidden)&&!b.contains(forbidden));
        try{NhTransport.purchase(sh);throw new AssertionError();}catch(IllegalArgumentException expected){}
        try{ShinhanTransport.purchase(nh);throw new AssertionError();}catch(IllegalArgumentException expected){}
        try{KbTransport.purchase(nh);throw new AssertionError();}catch(IllegalArgumentException expected){}
        check(q.observeNh(hash(1),hash(2),3400,now,now,45600,now+1).id.equals(nh.id));
        check(q.observeNh(hash(1),hash(2),3400,now,now,45700,now+1).state==CaptureOutbox.State.REVIEW);
        q.verify(CaptureOutbox.Card.NH_ZGM);check(q.begin(now).id.equals(nh.id));
        q=new CaptureOutbox(st);q.verify(CaptureOutbox.Card.NH_ZGM);
        CaptureOutbox.Item retry=q.begin(now+120000);check(retry.id.equals(nh.id)&&NhTransport.purchase(retry).equals(a));
        q.complete(retry.id,retry.attempts,CaptureOutbox.Outcome.ACCEPTED,now+120000);check(q.begin(now+120000)==null);
        q.verify(CaptureOutbox.Card.SHINHAN_KPASS);check(ShinhanTransport.purchase(q.begin(now+120000)).equals(b));
        check(NhTransport.ACTIVATE.contains("\"appVersion\":9")&&ShinhanTransport.ACTIVATE.contains("\"appVersion\":9"));
        System.out.println("NH/Shinhan transport: consent gate, card isolation, durable retry, ambiguity and privacy passed.");
    }
}
