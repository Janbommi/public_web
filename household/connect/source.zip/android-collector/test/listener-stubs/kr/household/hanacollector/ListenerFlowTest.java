package kr.household.hanacollector;

import android.app.Notification;
import android.os.Bundle;
import android.os.SystemClock;
import android.content.Context;
import android.service.notification.StatusBarNotification;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

/** Runs real listener/parser/store code against narrow Android API test doubles. */
public final class ListenerFlowTest {
    private static final long POSTED=java.time.Instant.parse("2026-10-18T03:35:00Z").toEpochMilli();
    private static final String BODY="가상 상점 / 신용(일시불,1*2*) / 10.18 12:34 / 누적이용금액 987,654원";
    private static void check(boolean condition,String why){if(!condition)throw new AssertionError(why);}
    private static StatusBarNotification notification(String pkg,boolean summary,boolean ongoing,boolean big){
        Notification n=new Notification();n.flags=summary?Notification.FLAG_GROUP_SUMMARY:0;
        n.extras.putCharSequence(Notification.EXTRA_TITLE,"(결제) 12,345원");
        n.extras.putCharSequence(big?Notification.EXTRA_BIG_TEXT:Notification.EXTRA_TEXT,BODY);
        return new StatusBarNotification(pkg,n,ongoing,POSTED);
    }
    private static int count(Context c){return DiagnosticHistory.decode(c.getSharedPreferences("hana_diagnostics",0).getString("history_v1",null),System.currentTimeMillis()).size();}
    public static void main(String[] args)throws Exception {
        HanaListener service=new HanaListener();
        if(args[0].equals("restore")){
            check(!HanaListener.connected,"new JVM starts without a live service connection");
            check(count(service)==3,"diagnostics restore after process restart");
            String report=DiagnosticStore.report(service);
            check(report.contains("국내 일시불 형식 확인: 3"),"parsed outcomes persist");
            DiagnosticStore.clear(service);
            check(count(service)==0,"explicit diagnostic clear");
            check("synthetic-vault-sentinel".equals(service.getSharedPreferences("vault",0).getString("token",null)),"diagnostic clear must preserve independent key storage");
            System.out.println("PASS: restart restores diagnostics; clearing leaves key storage intact (host test doubles).");return;
        }
        check(count(service)==0,"isolated initial store");
        service.onListenerConnected();check(HanaListener.connected,"service connected");
        // Any content read on disallowed packages or grouped/ongoing alerts must fail the test.
        Bundle forbidden=new Bundle(){@Override public CharSequence getCharSequence(String k){throw new AssertionError("Forbidden content inspected");}};
        for(String pkg:new String[]{"com.kakao.talk","com.hanaskcard.paycla.fake","com.example.other"}){
            Notification n=new Notification();n.extras=forbidden;service.onNotificationPosted(new StatusBarNotification(pkg,n,false,POSTED));
        }
        Notification group=new Notification();group.flags=Notification.FLAG_GROUP_SUMMARY;group.extras=forbidden;
        service.onNotificationPosted(new StatusBarNotification(CapturePolicy.HANA_PACKAGE,group,false,POSTED));
        Notification ongoing=new Notification();ongoing.extras=forbidden;
        service.onNotificationPosted(new StatusBarNotification(CapturePolicy.HANA_PACKAGE,ongoing,true,POSTED));
        service.onNotificationPosted(null);
        Notification extra=new Notification();extra.extras=forbidden;
        service.onNotificationPosted(new StatusBarNotification(NhTransport.PACKAGE,extra,false,POSTED));
        service.onNotificationPosted(new StatusBarNotification(ShinhanTransport.PACKAGE,extra,false,POSTED));
        NhCaptureRuntime.key=true;ShinhanCaptureRuntime.key=true;
        for(String pkg:new String[]{NhTransport.PACKAGE,ShinhanTransport.PACKAGE}){
            service.onNotificationPosted(new StatusBarNotification(pkg,group,false,POSTED));
            service.onNotificationPosted(new StatusBarNotification(pkg,ongoing,true,POSTED));
            service.onNotificationPosted(new StatusBarNotification(pkg+".fake",extra,false,POSTED));
        }
        String nh="NH카드1*2*승인 가*상 3,400원 일시불 10/18 12:34 가상매장 총누적45,600원";
        String shinhan="[신한카드(3*4*)승인] 가*상 - 승인금액: 5,600원(일시불) - 승인일시: 10/18 12:34 - 가맹점명: 가상상점 - 누적금액: 78,900원 [신한카드 0000-0000]";
        Notification nnh=new Notification();nnh.extras.putCharSequence(Notification.EXTRA_TEXT,nh);
        service.onNotificationPosted(new StatusBarNotification(NhTransport.PACKAGE,nnh,false,POSTED));
        Notification ns=new Notification();ns.extras.putCharSequence(Notification.EXTRA_BIG_TEXT,shinhan);
        service.onNotificationPosted(new StatusBarNotification(ShinhanTransport.PACKAGE,ns,false,POSTED));
        check(NhCaptureRuntime.observations==1&&ShinhanCaptureRuntime.observations==1&&CaptureRuntime.observations==0,"issuer routing");
        service.onNotificationPosted(new StatusBarNotification(NhTransport.PACKAGE,ns,false,POSTED));
        service.onNotificationPosted(new StatusBarNotification(ShinhanTransport.PACKAGE,nnh,false,POSTED));
        nnh.extras.putCharSequence(Notification.EXTRA_BIG_TEXT,nh.replace("3,400","3,500"));
        service.onNotificationPosted(new StatusBarNotification(NhTransport.PACKAGE,nnh,false,POSTED));
        ns.extras.putCharSequence(Notification.EXTRA_TEXT,shinhan.replace("5,600","5,700"));
        service.onNotificationPosted(new StatusBarNotification(ShinhanTransport.PACKAGE,ns,false,POSTED));
        check(NhCaptureRuntime.observations==1&&ShinhanCaptureRuntime.observations==1&&NhCaptureRuntime.unsupported==2&&ShinhanCaptureRuntime.unsupported==2,"wrong issuer and conflicting extras rejected");
        Notification kbBlocked=new Notification();kbBlocked.extras=forbidden;
        service.onNotificationPosted(new StatusBarNotification(KbTransport.PACKAGE,kbBlocked,false,POSTED));
        KbCaptureRuntime.key=true;
        service.onNotificationPosted(new StatusBarNotification(KbTransport.PACKAGE,group,false,POSTED));
        service.onNotificationPosted(new StatusBarNotification(KbTransport.PACKAGE,ongoing,true,POSTED));
        Notification kb=new Notification();kb.extras.putCharSequence(Notification.EXTRA_TEXT,"KB국민카드1*2*승인 가*상님 12,000원 일시불 10/18 12:34 가상상점 누적80,000원");
        service.onNotificationPosted(new StatusBarNotification(KbTransport.PACKAGE,kb,false,POSTED));
        check(KbCaptureRuntime.observations==1&&CaptureRuntime.observations==0,"KB uses only its runtime");
        kb.extras.putCharSequence(Notification.EXTRA_BIG_TEXT,"KB국민카드1*2*승인 가*상님 13,000원 일시불 10/18 12:34 가상상점 누적81,000원");
        service.onNotificationPosted(new StatusBarNotification(KbTransport.PACKAGE,kb,false,POSTED));
        check(KbCaptureRuntime.observations==1&&KbCaptureRuntime.unsupported==1,"conflicting text fields rejected");
        service.onNotificationPosted(new StatusBarNotification(CapturePolicy.HANA_PACKAGE,null,false,POSTED));
        check(count(service)==0,"excluded inputs never create records");
        StatusBarNotification first=notification(CapturePolicy.HANA_PACKAGE,false,false,true);
        service.onNotificationPosted(first);check(count(service)==1,"first callback persisted automatically");
        check(HanaListener.view().contains("12345원"),"supported values shown locally");
        service.onNotificationRemoved(first);check(count(service)==1,"OS dismissal does not delete journal");
        SystemClock.advance(16*60*1000);check(!HanaListener.view().contains("12345원"),"local detail expires");
        check(count(service)==1,"detail expiry does not delete journal");
        // Identical callback may be an update; this must not be claimed as a new purchase.
        service.onNotificationPosted(first);check(count(service)==2,"callback update is a diagnostic observation");
        check(DiagnosticStore.report(service).contains("결제 건수 아님"),"counts are explicitly not purchases");
        service.onNotificationPosted(notification(CapturePolicy.HANA_PACKAGE,false,false,false));
        check(count(service)==3,"normal text fallback captured");
        Context.failPreferences=true;service.onNotificationPosted(first);Context.failPreferences=false;
        check(HanaListener.diagnosticWriteFailed,"storage failure surfaced without crash");
        check(count(service)==3,"failed store did not invent a record");
        service.onListenerDisconnected();check(!HanaListener.connected&&count(service)==3,"disconnect preserves journal");
        HanaListener.clear();check(count(service)==3,"clear detail does not clear journal");
        String persisted=new String(Files.readAllBytes(Paths.get(System.getProperty("test.preferences"),"hana_diagnostics.properties")),StandardCharsets.UTF_8);
        for(String secret:new String[]{"12,345","987,654","1*2*","10.18 12:34","가상 상점",BODY}){
            check(!persisted.contains(secret),"raw financial fields not persisted");
            check(!DiagnosticStore.report(service).contains(secret),"raw financial fields not copied");
        }
        service.getSharedPreferences("vault",0).edit().putString("token","synthetic-vault-sentinel").apply();
        System.out.println("PASS: package/privacy filter, summary/ongoing exclusion, automatic storage, dismissal, expiry, updates, storage failure and disconnect (host test doubles).");
    }
}
