package kr.household.hanacollector;
import android.content.Context;
final class CaptureRuntime {
    static int observations,requests;
    static void request(Context c,boolean retry){requests++;}
    static void observed(Context context,HanaPushParser.Result parsed,String key,long at){if(parsed==null)throw new AssertionError();observations++;}
}
