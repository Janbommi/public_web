package kr.household.hanacollector;
/** Listener-flow tests never schedule jobs or access a network. */
final class DiagnosticSync {
    static int requests;
    static void request(android.content.Context c,boolean retry){requests++;}
}
