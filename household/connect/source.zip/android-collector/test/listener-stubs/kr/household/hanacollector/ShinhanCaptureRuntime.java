package kr.household.hanacollector;
import android.content.Context;
final class ShinhanCaptureRuntime {
    static boolean key;static int observations,unsupported;
    static boolean hasKey(Context c){return key;}
    static void request(Context c,boolean retry){}
    static void unsupported(){unsupported++;}
    static void observed(Context c,AdditionalPushParser.Result parsed,String id,long at){if(parsed==null)throw new AssertionError();observations++;}
}
