package android.app;
public class Notification {
    public static final int FLAG_GROUP_SUMMARY=512;
    public static final String EXTRA_TITLE="android.title",EXTRA_TEXT="android.text",EXTRA_BIG_TEXT="android.bigText";
    public int flags;
    public android.os.Bundle extras=new android.os.Bundle();
}
