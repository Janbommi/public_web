package android.content;
import java.nio.file.*;
import java.io.*;
import java.util.*;

/** Host test double, NOT an Android implementation. apply is synchronous here;
 * device scheduling, async disk durability and power loss are outside this test. */
public class Context {
    public static final int MODE_PRIVATE=0;
    public static boolean failPreferences=false;
    public Context getApplicationContext(){return this;}
    public SharedPreferences getSharedPreferences(String name,int mode){
        if(failPreferences)throw new IllegalStateException("Simulated storage unavailable");
        if(!name.matches("[a-z_]+"))throw new IllegalArgumentException();
        return new FilePreferences(Paths.get(System.getProperty("test.preferences"),name+".properties"));
    }
    private static final class FilePreferences implements SharedPreferences {
        private final Path path;
        FilePreferences(Path path){this.path=path;}
        private Properties read(){
            Properties values=new Properties();
            if(Files.exists(path))try(InputStream in=Files.newInputStream(path)){values.load(in);}catch(IOException e){throw new IllegalStateException(e);}
            return values;
        }
        public String getString(String key,String fallback){return read().getProperty(key,fallback);}
        public Editor edit(){return new Editor(){
            private final Map<String,String> changed=new HashMap<>();
            public Editor putString(String key,String value){changed.put(key,value);return this;}
            public Editor remove(String key){changed.put(key,null);return this;}
            public void apply(){
                Properties values=read();
                for(Map.Entry<String,String> e:changed.entrySet())if(e.getValue()==null)values.remove(e.getKey());else values.setProperty(e.getKey(),e.getValue());
                try{Files.createDirectories(path.getParent());try(OutputStream out=Files.newOutputStream(path)){values.store(out,"Synthetic diagnostic test only");}}catch(IOException e){throw new IllegalStateException(e);}
            }
        };}
    }
}
