package android.os;
import java.util.HashMap;
public class Bundle {
    private final HashMap<String,CharSequence> values=new HashMap<>();
    public CharSequence getCharSequence(String key){return values.get(key);}
    public void putCharSequence(String key,CharSequence value){values.put(key,value);}
}
