package android.os;
public final class SystemClock {
    private static long value=1000;
    public static long elapsedRealtime(){return value;}
    public static void advance(long millis){value+=millis;}
}
