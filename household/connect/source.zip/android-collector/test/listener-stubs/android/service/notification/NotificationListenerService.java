package android.service.notification;
public class NotificationListenerService extends android.content.Context {
    public void onListenerConnected(){}
    public void onListenerDisconnected(){}
    public void onNotificationPosted(StatusBarNotification n){}
    public void onNotificationRemoved(StatusBarNotification n){}
}
