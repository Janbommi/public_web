package android.service.notification;
import android.app.Notification;
public class StatusBarNotification {
    private final String pkg;private final Notification notification;private final boolean ongoing;private final long at;
    public StatusBarNotification(String pkg,Notification notification,boolean ongoing,long at){this.pkg=pkg;this.notification=notification;this.ongoing=ongoing;this.at=at;}
    public String getPackageName(){return pkg;}
    public Notification getNotification(){return notification;}
    public boolean isOngoing(){return ongoing;}
    public long getPostTime(){return at;}
    public String getKey(){return "synthetic-key";}
}
