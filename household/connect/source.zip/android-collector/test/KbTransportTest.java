import kr.household.hanacollector.*;
import java.io.*;
import java.util.*;
public final class KbTransportTest {
    static final long NOW=1792634460000L;
    static class Store implements CaptureOutbox.Store {byte[] bytes;public byte[] read(){return bytes;}public void commit(byte[] b){bytes=b;}}
    static void check(boolean b){if(!b)throw new AssertionError();}
    static String hash(int n){return String.format("%064x",n);}
    public static void main(String[] args)throws Exception {
        Store s=new Store();CaptureOutbox q=new CaptureOutbox(s);
        CaptureOutbox.Item v=q.observeKb(hash(1),hash(2),12000,NOW,NOW+1000,80000,NOW+1000);
        String payload=KbTransport.purchase(v);check(payload.contains("\"amount\":12000")&&payload.contains("\"cumulative\":80000"));
        check(!payload.contains("receipt")&&!payload.contains("evidence")&&!payload.contains("mask")&&!payload.contains("originalId"));
        check(q.observeKb(hash(1),hash(2),12000,NOW,NOW+1000,80000,NOW+2000).id.equals(v.id));
        check(q.observeKb(hash(1),hash(2),12000,NOW,NOW+1000,90000,NOW+2000).state==CaptureOutbox.State.REVIEW);
        q.verify(CaptureOutbox.Card.KB_COUPANG);q.begin(NOW+2000);q=new CaptureOutbox(s);q.verify(CaptureOutbox.Card.KB_COUPANG);
        CaptureOutbox.Item retried=q.begin(NOW+120000);check(retried.id.equals(v.id));check(KbTransport.purchase(retried).equals(payload));
        // Real v1 byte format migration retains an existing Hana event and its identity.
        Store legacy=new Store();ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(1);out.writeInt(1);out.writeUTF(v.id);out.writeUTF(hash(3));out.writeUTF(hash(4));out.writeUTF("HANA_MOVING");out.writeLong(5000);out.writeLong(NOW);out.writeUTF("SENDING");out.writeInt(1);out.writeLong(NOW);out.writeUTF("");out.close();legacy.bytes=bytes.toByteArray();
        CaptureOutbox old=new CaptureOutbox(legacy);old.verify(CaptureOutbox.Card.HANA_MOVING);CaptureOutbox.Item h=old.begin(NOW+120000);check(h.id.equals(v.id)&&h.amount==5000&&h.cumulative==-1&&h.observedAt==0);
        try{KbTransport.purchase(h);throw new AssertionError();}catch(IllegalArgumentException expected){}
        check(new CaptureOutbox(legacy).snapshot().get(0).id.equals(v.id));
        String body="KB국민카드1*2*승인 가*상님 12,000원 일시불 10/22 10:01 가상상점 누적80,000원";long posted=java.time.Instant.parse("2026-10-22T01:02:00Z").toEpochMilli();
        check(KbPushParser.fromExtras(body,null,posted)!=null);check(KbPushParser.fromExtras("축약...",body,posted)!=null);
        check(KbPushParser.fromExtras(body,body.replace("12,000","13,000"),posted)==null);check(KbPushParser.fromExtras(body,"내용 비공개",posted)==null);
        System.out.println(payload);System.out.println("KB transport: replay, cumulative persistence, v1 Hana migration, cross-card and extras checks passed.");
    }
}
