package kr.household.hanacollector;

import java.io.*;
import java.time.*;
import java.util.*;

/** Minimal local diagnostics. The supplied store MUST be encrypted.
 * No notification text, amounts, merchants, card displays, or content hashes.
 * Receipt is a keyed digest of Android delivery metadata; eventId is an existing
 * opaque outbox ID. This journal never changes or transmits an outbox item.
 */
final class NhCaptureAudit {
    static final int DAYS=31,LIMIT=1024;
    enum Reason { PARSED, FORMAT, REFERENCE, CONFLICT }
    private static final int MAGIC=0x4e484431;
    private static final ZoneId KST=ZoneId.of("Asia/Seoul");
    private final CaptureOutbox.Store store;
    private List<Entry> entries;
    private boolean capped;
    private static final class Entry {
        final String receipt,eventId;final long day;final Reason reason;
        Entry(String receipt,long day,Reason reason,String eventId){this.receipt=receipt;this.day=day;this.reason=reason;this.eventId=eventId;}
    }
    NhCaptureAudit(CaptureOutbox.Store store,long now)throws IOException{
        this.store=Objects.requireNonNull(store);entries=decode(store.read());prune(now);
    }
    private static long day(long at){if(at<=0)throw new IllegalArgumentException("Invalid diagnostic clock");return Instant.ofEpochMilli(at).atZone(KST).toLocalDate().toEpochDay();}
    private void save(List<Entry> next,boolean dropped)throws IOException{store.commit(encode(next,dropped));entries=next;capped=dropped;}
    private void prune(long now)throws IOException{
        long first=day(now)-DAYS+1;List<Entry> next=new ArrayList<>();
        for(Entry entry:entries)if(entry.day>=first)next.add(entry);
        if(next.size()!=entries.size())save(next,capped);
    }
    synchronized void record(String receipt,Reason reason,String eventId,long now)throws IOException{
        if(receipt==null||!receipt.matches("[a-f0-9]{64}")||reason==null)throw new IllegalArgumentException("Invalid diagnostic");
        String linked=eventId==null?"":eventId;
        if(!linked.isEmpty()&&!UUID.fromString(linked).toString().equals(linked))throw new IllegalArgumentException("Invalid outbox link");
        long today=day(now);List<Entry> next=new ArrayList<>();boolean found=false,dropped=capped;
        for(Entry entry:entries){
            if(entry.day<today-DAYS+1)continue;
            if(entry.receipt.equals(receipt)){
                found=true;
                if(entry.reason==Reason.CONFLICT||(!entry.eventId.isEmpty()&&!linked.isEmpty()&&!entry.eventId.equals(linked)))
                    next.add(new Entry(receipt,entry.day,Reason.CONFLICT,entry.eventId));
                else if(!linked.isEmpty())next.add(new Entry(receipt,entry.day,Reason.PARSED,linked));
                else next.add(entry); // A later compact/unsupported callback cannot erase an established link.
            }else next.add(entry);
        }
        if(!found)next.add(new Entry(receipt,today,reason,linked));
        while(next.size()>LIMIT){next.remove(0);dropped=true;}
        boolean changed=dropped!=capped||next.size()!=entries.size();
        if(!changed)for(int i=0;i<next.size();i++){Entry a=entries.get(i),b=next.get(i);if(a.day!=b.day||a.reason!=b.reason||!a.receipt.equals(b.receipt)||!a.eventId.equals(b.eventId)){changed=true;break;}}
        if(!changed)return;
        save(next,dropped);
    }
    synchronized String report(CaptureOutbox queue,long now)throws IOException{
        List<CaptureOutbox.Item> items=queue.snapshot();
        prune(now);long today=day(now);Map<String,CaptureOutbox.Item> byId=new HashMap<>();
        for(CaptureOutbox.Item item:items)if(item.card==CaptureOutbox.Card.NH_ZGM)byId.put(item.id,item);
        Map<Long,int[]> days=new TreeMap<>(Collections.reverseOrder());Set<String> seen=new HashSet<>();
        for(Entry entry:entries){
            if(entry.day>today)continue;
            int[] row=days.computeIfAbsent(entry.day,key->new int[7]);row[0]++;
            if(entry.reason==Reason.FORMAT||entry.reason==Reason.REFERENCE)row[6]++;
            CaptureOutbox.Item item=byId.get(entry.eventId);
            if(entry.reason==Reason.CONFLICT||item==null||item.state==CaptureOutbox.State.REVIEW
                    ||(item.state==CaptureOutbox.State.WAITING_ORIGINAL&&queue.parentFor(item)==null)){row[3]++;continue;}
            if(!seen.add(item.id)){row[5]++;continue;}
            if(item.state==CaptureOutbox.State.ACKNOWLEDGED)row[1]++;
            else if(item.state==CaptureOutbox.State.BLOCKED||item.attempts>=CaptureOutbox.MAX_ATTEMPTS)row[4]++;
            else row[2]++;
        }
        StringBuilder result=new StringBuilder("수신일별 알림 확인 · 한국시간\n최근 31일 · 최대 1,024건 · 이 버전에서 기록한 알림만 표시\n알림 건수는 결제 건수나 월 전체 수집률이 아니에요.");
        if(capped)result.append("\n보관 상한으로 이전 진단 일부가 제외됐어요.");
        if(days.isEmpty())result.append("\n아직 기록한 알림이 없어요. 사용액 0원을 뜻하지 않아요.");
        for(Map.Entry<Long,int[]> row:days.entrySet()){
            int[] n=row.getValue();result.append('\n').append(LocalDate.ofEpochDay(row.getKey())).append(" · 포착 ").append(n[0])
              .append(" / 서버 확인 ").append(n[1]).append(" / 대기 ").append(n[2]).append(" / 확인 필요 ").append(n[3]);
            if(n[6]>0)result.append("(형식 확인 ").append(n[6]).append(')');
            if(n[4]>0)result.append(" / 재시도 ").append(n[4]);if(n[5]>0)result.append(" / 중복 연결 ").append(n[5]);
        }
        return result.toString();
    }
    static String confirmedAmounts(List<CaptureOutbox.Item> items,long now){
        long today=day(now),first=today-DAYS+1;Map<Long,long[]> days=new TreeMap<>(Collections.reverseOrder());
        for(CaptureOutbox.Item item:items){
            if(item.card!=CaptureOutbox.Card.NH_ZGM||item.state!=CaptureOutbox.State.ACKNOWLEDGED)continue;
            long at=item.occurredAt;
            if(item.refund){
                CaptureOutbox.Item parent=null;
                for(CaptureOutbox.Item other:items)if(!other.refund&&other.card==item.card&&other.state==CaptureOutbox.State.ACKNOWLEDGED
                        &&other.purchaseReference.equals(item.purchaseReference)){if(parent!=null){parent=null;break;}parent=other;}
                if(parent==null)continue;at=parent.occurredAt;
            }
            long date=day(at);if(date<first||date>today)continue;
            long[] row=days.computeIfAbsent(date,key->new long[2]);row[item.refund?1:0]+=item.amount;
        }
        StringBuilder result=new StringBuilder("원승인일별 반영 확인액 · 최근 31일\n이 폰의 전송 완료 기록만 계산해요. 월 전체 합계가 아니며, 직접 보완·할부는 포함하지 않아요. 취소는 연결된 원승인일에서 빼요.");
        if(days.isEmpty())result.append("\n확인된 반영 내역이 없어요. 사용액 0원을 뜻하지 않아요.");
        for(Map.Entry<Long,long[]> row:days.entrySet()){
            long[] n=row.getValue();result.append('\n').append(LocalDate.ofEpochDay(row.getKey())).append(" · 승인 ").append(money(n[0]))
                .append(" − 취소 ").append(money(n[1])).append(" = ").append(money(n[0]-n[1]));
        }
        return result.toString();
    }
    private static String money(long value){return String.format(Locale.KOREA,"%,d원",value);}
    private byte[] encode(List<Entry> rows,boolean dropped)throws IOException{
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(MAGIC);out.writeBoolean(dropped);out.writeInt(rows.size());
        for(Entry row:rows){out.writeUTF(row.receipt);out.writeLong(row.day);out.writeByte(row.reason.ordinal());out.writeUTF(row.eventId);}
        out.close();return bytes.toByteArray();
    }
    private List<Entry> decode(byte[] bytes)throws IOException{
        List<Entry> rows=new ArrayList<>();if(bytes==null)return rows;
        if(bytes.length>200000)throw new IOException("Invalid diagnostic size");
        try(DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes))){
            if(in.readInt()!=MAGIC)throw new IOException("Invalid diagnostic format");capped=in.readBoolean();int count=in.readInt();
            if(count<0||count>LIMIT)throw new IOException("Invalid diagnostic count");Set<String> ids=new HashSet<>();
            for(int i=0;i<count;i++){
                String receipt=in.readUTF();long date=in.readLong();int reason=in.readUnsignedByte();String event=in.readUTF();
                if(!receipt.matches("[a-f0-9]{64}")||!ids.add(receipt)||date<0||date>100000||reason>=Reason.values().length
                        ||(!event.isEmpty()&&!UUID.fromString(event).toString().equals(event)))throw new IOException("Invalid diagnostic record");
                rows.add(new Entry(receipt,date,Reason.values()[reason],event));
            }
            if(in.available()!=0)throw new IOException("Trailing diagnostic data");
        }catch(IllegalArgumentException e){throw new IOException("Invalid diagnostic record");}
        return rows;
    }
}
