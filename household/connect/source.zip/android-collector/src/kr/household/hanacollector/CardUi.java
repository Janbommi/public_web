package kr.household.hanacollector;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;

/** Shared native hierarchy and interaction styling for all four peer cards. */
final class CardUi {
    static int dp(Context c,int n){return (int)(n*c.getResources().getDisplayMetrics().density+.5f);}
    static GradientDrawable surface(Context c,int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,16));return d;}
    static void changed(TextView v,String text){if(!text.contentEquals(v.getText()))v.setText(text);}
    static TextView text(LinearLayout parent,String value,int size){Context c=parent.getContext();TextView v=new TextView(c);v.setText(value);v.setTextSize(size);v.setTextColor(0xff17333b);v.setPadding(0,dp(c,7),0,dp(c,7));v.setLineSpacing(dp(c,2),1);parent.addView(v);return v;}
    static LinearLayout card(LinearLayout parent){Context c=parent.getContext();LinearLayout b=new LinearLayout(c);b.setOrientation(1);b.setPadding(dp(c,18),dp(c,12),dp(c,18),dp(c,14));b.setBackground(surface(c,Color.WHITE));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(c,12),0,dp(c,8));parent.addView(b,p);return b;}
    static Button button(LinearLayout parent,String value,View.OnClickListener action){Context c=parent.getContext();Button b=new Button(c);b.setText(value);b.setAllCaps(false);b.setTextSize(16);b.setMinHeight(dp(c,52));b.setPadding(dp(c,16),dp(c,12),dp(c,16),dp(c,12));b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setOnClickListener(action);style(b,false,value.contains("삭제"));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(c,5),0,dp(c,5));parent.addView(b,p);return b;}
    static void style(Button b,boolean primary,boolean danger){Context c=b.getContext();b.setTextColor(new ColorStateList(new int[][]{new int[]{-android.R.attr.state_enabled},new int[]{}},new int[]{0xff65756f,primary?Color.WHITE:danger?0xffa22c28:0xff17333b}));b.setBackgroundTintList(null);GradientDrawable base=surface(c,primary?0xff087e80:Color.WHITE);base.setStroke(dp(c,1),primary?0xff087e80:0xffd4dfd9);StateListDrawable states=new StateListDrawable();states.addState(new int[]{-android.R.attr.state_enabled},surface(c,0xffe3e8e5));GradientDrawable focused=surface(c,primary?0xff076b6d:0xffe8f2ed);focused.setStroke(dp(c,2),0xff087e80);states.addState(new int[]{android.R.attr.state_focused},focused);states.addState(new int[]{},base);b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33087e80),states,null));}
    static LinearLayout fold(LinearLayout parent,String name,boolean open){LinearLayout content=new LinearLayout(parent.getContext());content.setOrientation(1);Button toggle=button(parent,name,v->{});parent.addView(content);Runnable render=()->{boolean expanded=content.getVisibility()==View.VISIBLE;toggle.setText(name+(expanded?"  −":"  ＋"));toggle.setStateDescription(expanded?"펼쳐짐":"접힘");};content.setVisibility(open?View.VISIBLE:View.GONE);render.run();toggle.setOnClickListener(v->{content.setVisibility(content.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);render.run();});return content;}
    static TextView heading(LinearLayout parent,String value,int size){TextView v=text(parent,value,size);v.setTypeface(null,android.graphics.Typeface.BOLD);v.setAccessibilityHeading(true);return v;}
    static final class Summary {
        final LinearLayout actions;private final Button permissions;private final TextView title,next,detail,done,pending;
        Summary(LinearLayout parent){
            actions=card(parent);title=heading(actions,"상태 확인 중…",22);next=text(actions,"",14);detail=text(actions,"",14);permissions=button(actions,"알림 접근 설정 확인",v->openNotificationSettings(actions.getContext()));
            LinearLayout records=card(parent);heading(records,"이 폰의 수집 기록",18);
            done=text(records,"서버 반영  —",20);pending=text(records,"전송 대기  —",20);
            text(records,"폰에 남아 있는 기록 건수예요. 월 사용금액·전체 이용 건수와 달라요.",14);
        }
        void show(CardUiState s){changed(title,s.title);changed(next,s.next(HanaListener.connected));permissions.setVisibility(HanaListener.connected?View.GONE:View.VISIBLE);changed(detail,s.detail);detail.setVisibility(s.detail.isEmpty()?View.GONE:View.VISIBLE);changed(done,"서버 반영  "+(s.done<0?"—":s.done+"건"));changed(pending,"전송 대기  "+(s.pending<0?"—":s.pending+"건"));}
    }
    static void openNotificationSettings(Context c){try{c.startActivity(new android.content.Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));}catch(Exception e){Toast.makeText(c,"휴대폰 설정에서 알림 접근을 확인해 주세요.",Toast.LENGTH_LONG).show();}}
    private CardUi(){}
}
