package kr.household.hanacollector;

import android.content.Context;
import android.content.SharedPreferences;

/** Separate from TokenVault. Encoded data contains only bounded numeric diagnostics. */
final class DiagnosticStore {
    private static final String KEY="history_v1";
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences("hana_diagnostics",Context.MODE_PRIVATE);}
    static synchronized void capture(Context c,String title,String body,boolean parsed){
        SharedPreferences p=prefs(c);long now=System.currentTimeMillis();
        DiagnosticHistory h=DiagnosticHistory.decode(p.getString(KEY,null),now);
        h.capture(title,body,parsed,now);
        // apply atomically replaces the in-memory value and queues a small disk write.
        // Abrupt process/power loss before that write is not a guaranteed delivery path.
        p.edit().putString(KEY,h.encode()).apply();
    }
    static synchronized String report(Context c){
        SharedPreferences p=prefs(c);String original=p.getString(KEY,null);
        DiagnosticHistory h=DiagnosticHistory.decode(original,System.currentTimeMillis());
        if(original!=null&&!original.equals(h.encode()))p.edit().putString(KEY,h.encode()).apply();
        return h.report();
    }
    static synchronized void clear(Context c){prefs(c).edit().remove(KEY).apply();}
    static synchronized String uploadJson(Context c){
        long now=System.currentTimeMillis();
        DiagnosticHistory h=DiagnosticHistory.decode(prefs(c).getString(KEY,null),now);
        return h.uploadJson(now,HanaListener.connected);
    }
    private DiagnosticStore(){}
}
