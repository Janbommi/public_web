package kr.household.hanacollector;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Local-only, explicit-reference contract. The four purchase body shapes were observed
 * previously. Reference lines and cancellation shapes are synthetic until independently
 * verified for each issuer. Package checks belong to the notification listener.
 */
public final class ReferencedPushParser {
    public interface LocalDigest { String apply(String value) throws Exception; }
    public static final class Result {
        public final boolean refund;
        public final String id, originalId, cardDisplay, telecomKind;
        public final long amount, occurredAt, cumulative;

        private Result(boolean refund, String id, String originalId, Core event) {
            this.refund = refund;
            this.id = id;
            this.originalId = originalId;
            this.cardDisplay = event.card;
            this.amount = event.amount;
            this.occurredAt = event.at;
            this.cumulative = event.cumulative;
            this.telecomKind = refund ? "" : event.telecomKind;
        }
    }

    private static final class Core {
        final String card, telecomKind;
        final long amount, at, cumulative;
        Core(String card, long amount, long at, long cumulative) {
            this(card,amount,at,cumulative,"");
        }
        Core(String card, long amount, long at, long cumulative, String telecomKind) {
            this.card = card;
            this.amount = amount;
            this.at = at;
            this.cumulative = cumulative;
            this.telecomKind = telecomKind;
        }
    }

    private static final ZoneId KST = ZoneId.of("Asia/Seoul");
    private static final String MONEY = "([1-9][0-9]{0,2}(?:,[0-9]{3})+|[1-9][0-9]*|0)";
    private static final String CARD = "([0-9*]{4})";
    private static final String DATE = "([0-9]{2})/([0-9]{2})\\s+([0-9]{2}):([0-9]{2})";
    private static final String REF = "((?!00000000)[0-9]{8})";
    private static final Pattern PURCHASE_REF = Pattern.compile("\\n승인번호[ \\t]*[:：][ \\t]*" + REF + "$");
    private static final Pattern REFUND_REFS = Pattern.compile("\\n원승인일자[ \\t]*[:：][ \\t]*(20[0-9]{2}-[0-9]{2}-[0-9]{2})"
            + "\\n원승인번호[ \\t]*[:：][ \\t]*" + REF + "\\n취소승인번호[ \\t]*[:：][ \\t]*" + REF + "$");
    private static final Pattern REFERENCE_LABEL = Pattern.compile("승인\\s*번호|취소\\s*번호|원\\s*승인");
    private static final Pattern CANCEL_MARKER = Pattern.compile("취\\s*소|환\\s*불|환급|매출반송|cancel|refund|reversal", Pattern.CASE_INSENSITIVE);
    private static final Pattern UNSUPPORTED = Pattern.compile(
            "할부|해외|외화|환산|분할|리볼빙|체크|현금서비스|카드론|거절|실패|미승인|미취소|취소되지|미완료|미확정|예정|예고|신청|접수|처리\\s*중|대기|철회|보류|불가|해제|실효|미처리|거부|"
                    + "USD|EUR|JPY|CNY|GBP|HKD|[0-9]\\s*[A-Z]{3}\\b|\\b[A-Z]{3}\\s*[0-9]|달러|유로|[$€£¥￥]|declined|failed|rejected|pending|not\\s+cancel|installment", Pattern.CASE_INSENSITIVE);
    private static final Pattern HANA_TITLE = Pattern.compile("^\\(결제취소\\)\\s*" + MONEY + "원$");
    private static final Pattern HANA_REFUND = Pattern.compile("^(.{1,150}?)\\s*/\\s*신용\\(일시불,\\s*" + CARD + "\\)\\s*/\\s*"
            + DATE.replace("/", "\\.") + "\\s*/\\s*누적이용금액\\s*" + MONEY + "원$");
    private static final String OTHER_REFUND = CARD + "\\s*승인취소\\s+[^\\s]{1,24}%s\\s+" + MONEY
            + "원\\s+일시불\\s+" + DATE + "\\s+(.{1,150}?)\\s+%s\\s*" + MONEY + "원$";
    private static final Pattern KB_REFUND = Pattern.compile("^KB국민카드\\s*" + String.format(OTHER_REFUND, "님", "누적"));
    private static final Pattern NH_REFUND = Pattern.compile("^NH카드\\s*" + String.format(OTHER_REFUND, "", "총누적"));
    private static final Pattern SHINHAN_REFUND = Pattern.compile("^\\[신한카드\\(" + CARD + "\\)승인취소\\]\\s+[^\\s]{1,24}\\s+"
            + "-\\s*취소금액:\\s*" + MONEY + "원\\(일시불\\)\\s+-\\s*취소일시:\\s*" + DATE
            + "\\s+-\\s*가맹점명:\\s*(.{1,150}?)\\s+-\\s*누적금액:\\s*" + MONEY + "원\\s+\\[신한카드\\s+[0-9]{4}-[0-9]{4}\\]$");
    private static final Pattern EXTRA_EVENT = Pattern.compile("(?:^|\\s)(?:승인취소|승인|취소|환불|결제)(?=\\s|$)|누적|KB국민카드|NH카드|신한카드|[0-9][0-9,]*원|[\\r\\n]");

    /** Use before the legacy approval path, including when the new parser rejects a cancellation. */
    public static boolean hasReferenceOrRefundMarker(String title, String text, String bigText) {
        return marked(title) || marked(text) || marked(bigText);
    }

    public static boolean hasReferenceOrRefundMarker(CaptureOutbox.Card issuer, String title, String text, String bigText) {
        return marked(title) || (marked(text) && marked(PushNotice.statusFields(issuer, text)))
                || (marked(bigText) && marked(PushNotice.statusFields(issuer, bigText)));
    }

    private static boolean marked(String value) {
        return value != null && (REFERENCE_LABEL.matcher(value).find() || CANCEL_MARKER.matcher(value).find());
    }

    /** Uses a per-installation/card keyed digest. Only opaque IDs and normalized facts leave this parser. */
    public static Result fromExtras(CaptureOutbox.Card issuer, String title, String text, String bigText,
                                    long postedAt, LocalDigest localDigest) throws Exception {
        if (issuer == null || issuer == CaptureOutbox.Card.SAMSUNG_FAMILY || localDigest == null || postedAt <= 0
                || tooLong(title, 150) || tooLong(text, 2000) || tooLong(bigText, 2000)) return null;
        if (PushNotice.classify(issuer, title, text, bigText) != PushNotice.Kind.TRANSACTION) return null;
        String shortBody = clean(text), expanded = clean(bigText);
        if (!expanded.isEmpty() && !shortBody.isEmpty() && !expanded.equals(shortBody)) {
            // Android may show the beginning of the same expanded body in compact mode.
            String prefix = shortBody.replaceFirst("(?:…|\\.\\.\\.)$", "").trim();
            if (prefix.isEmpty() || !expanded.startsWith(prefix)) return null;
        }
        String body = expanded.isEmpty() ? shortBody : expanded;
        String header = clean(title);
        if (!marked(body) || UNSUPPORTED.matcher(header).find()
                || UNSUPPORTED.matcher(PushNotice.statusFields(issuer, body)).find()) return null;
        Matcher refs = REFUND_REFS.matcher(body);
        if (refs.find()) {
            String coreBody = body.substring(0, refs.start());
            if (REFERENCE_LABEL.matcher(coreBody).find() || refs.group(2).equals(refs.group(3))
                    || !titleMatches(issuer, header, true)) return null;
            Core event = refund(issuer, header, coreBody, postedAt);
            if (event == null) return null;
            LocalDate originalDate;
            try { originalDate = LocalDate.parse(refs.group(1)); }
            catch (DateTimeException e) { return null; }
            LocalDate eventDate = localDate(event.at);
            if (originalDate.isAfter(eventDate)) return null;
            String parent = id(localDigest, issuer, event.card, false, originalDate, refs.group(2));
            String cancellation = id(localDigest, issuer, event.card, true, eventDate, refs.group(3));
            return new Result(true, cancellation, parent, event);
        }

        Matcher ref = PURCHASE_REF.matcher(body);
        if (!ref.find()) return null;
        String coreBody = body.substring(0, ref.start());
        if (marked(PushNotice.statusFields(issuer, coreBody)) || marked(header) || !titleMatches(issuer, header, false)) return null;
        Core event = purchase(issuer, header, coreBody, postedAt);
        return event == null ? null : new Result(false,
                id(localDigest, issuer, event.card, false, localDate(event.at), ref.group(1)), null, event);
    }

    private static Core purchase(CaptureOutbox.Card issuer, String title, String body, long postedAt) {
        switch (issuer) {
            case HANA_MOVING:
                HanaPushParser.Result h = HanaPushParser.parse(title, body, postedAt);
                int separator = body.indexOf('/');
                if (h == null || separator < 1 || body.indexOf("신용(") != body.lastIndexOf("신용(")
                        || EXTRA_EVENT.matcher(body.substring(0, separator)).find()) return null;
                return new Core(h.maskedCard, h.amount, h.occurredAt, h.cumulative);
            case KB_COUPANG:
                KbPushParser.Result k = KbPushParser.parse(body, postedAt);
                return k == null ? null : new Core(k.cardDisplay, k.amount, k.occurredAt, k.cumulative);
            case NH_ZGM:
            case SHINHAN_KPASS:
                AdditionalPushParser.Issuer i = issuer == CaptureOutbox.Card.NH_ZGM
                        ? AdditionalPushParser.Issuer.NH : AdditionalPushParser.Issuer.SHINHAN;
                AdditionalPushParser.Result a = AdditionalPushParser.parse(i, body, postedAt);
                return a == null ? null : new Core(a.cardDisplay, a.amount, a.occurredAt, a.cumulative, a.telecomKind);
            default:
                return null;
        }
    }

    private static Core refund(CaptureOutbox.Card issuer, String title, String body, long postedAt) {
        String line = body.trim().replaceAll("\\s+", " ");
        Matcher m;
        String card, amount, merchant;
        if (issuer == CaptureOutbox.Card.HANA_MOVING) {
            Matcher heading = HANA_TITLE.matcher(title);
            m = HANA_REFUND.matcher(line);
            if (!heading.matches() || !m.matches()) return null;
            amount = heading.group(1);
            card = m.group(2);
            merchant = m.group(1);
        } else {
            Pattern shape;
            switch (issuer) {
                case KB_COUPANG: shape = KB_REFUND; break;
                case NH_ZGM: shape = NH_REFUND; break;
                case SHINHAN_KPASS: shape = SHINHAN_REFUND; break;
                default: return null;
            }
            m = shape.matcher(line);
            if (!m.matches()) return null;
            card = m.group(1);
            amount = m.group(2);
            merchant = m.group(7);
        }
        if (card.equals("****") || EXTRA_EVENT.matcher(merchant).find()) return null;
        try {
            long value = Long.parseLong(amount.replace(",", ""));
            int cumulativeGroup = issuer == CaptureOutbox.Card.HANA_MOVING ? 7 : 8;
            long cumulative = Long.parseLong(m.group(cumulativeGroup).replace(",", ""));
            long at = occurrence(m, postedAt);
            if (value < 1 || value > 1_000_000_000L || cumulative > 100_000_000_000L || at == 0) return null;
            return new Core(card, value, at, cumulative);
        } catch (NumberFormatException e) { return null; }
    }

    private static boolean titleMatches(CaptureOutbox.Card issuer, String title, boolean refund) {
        if (issuer == CaptureOutbox.Card.HANA_MOVING || title.isEmpty()) return true;
        String app;
        switch (issuer) {
            case KB_COUPANG: app = "(?:KB Pay|KB국민카드)"; break;
            case NH_ZGM: app = "(?:NH pay|NH카드|NH농협카드)"; break;
            case SHINHAN_KPASS: app = "(?:신한 SOL페이|신한카드)"; break;
            default: return false;
        }
        String status = refund ? "(?:승인취소|결제취소|취소)" : "(?:승인|결제)";
        return title.matches("(?i)(?:" + app + "|(?:" + app + "\\s*)?" + status + ")");
    }

    private static long occurrence(Matcher m, long postedAt) {
        int year = localDate(postedAt).getYear();
        int month = Integer.parseInt(m.group(3)), day = Integer.parseInt(m.group(4));
        int hour = Integer.parseInt(m.group(5)), minute = Integer.parseInt(m.group(6));
        for (int y = year - 1; y <= year + 1; y++) {
            try {
                long candidate = LocalDateTime.of(y, month, day, hour, minute).atZone(KST).toInstant().toEpochMilli();
                if (candidate >= postedAt - 172800000L && candidate <= postedAt + 300000L) return candidate;
            } catch (DateTimeException ignored) { /* e.g. leap day outside the relevant year */ }
        }
        return 0;
    }

    private static LocalDate localDate(long at) { return Instant.ofEpochMilli(at).atZone(KST).toLocalDate(); }
    private static boolean tooLong(String value, int max) { return value != null && value.length() > max; }
    private static String clean(String value) { return value == null ? "" : value.replace("\r\n", "\n").replace('\r', '\n').trim(); }

    private static String id(LocalDigest digest, CaptureOutbox.Card card, String display, boolean refund,
                             LocalDate date, String reference) throws Exception {
        String hash = digest.apply("issuer-ref-v1|" + card.name() + "|" + display + "|"
                + (refund ? "cancel" : "approve") + "|" + date + "|" + reference);
        if (hash == null || !hash.matches("[a-f0-9]{64}")) throw new IllegalArgumentException("Invalid local digest");
        long hi = Long.parseUnsignedLong(hash.substring(0, 16), 16);
        long lo = Long.parseUnsignedLong(hash.substring(16, 32), 16);
        return new UUID((hi & ~0xf000L) | 0x8000L, (lo & 0x3fffffffffffffffL) | Long.MIN_VALUE).toString();
    }

    private ReferencedPushParser() {}
}
