package kr.household.hanacollector;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;

/** Small, native enrollment flow. No credential input, embedded website or monthly-detail UI. */
public final class EnrollmentActivity extends Activity {
    private TextView status;private LinearLayout box;private Button connect,invite,check,share,cancel,revoke,permission;private boolean busy,visible;private int generation;
    private final Handler main=new Handler(Looper.getMainLooper());
    interface Action{String run()throws Exception;}
    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(0xfff7f3eb);box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);int pad=(int)(20*getResources().getDisplayMetrics().density);box.setPadding(pad,pad,pad,pad);scroll.addView(box);setContentView(scroll);
        box.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets b=i.getInsets(WindowInsets.Type.systemBars());v.setPadding(pad,pad+b.top,pad,pad+b.bottom);return i;});
        CardUi.button(box,"← 홈",v->finish());text("기기 연결",24).setAccessibilityHeading(true);
        status=text("연결 상태 확인 중…",16);
        text("지원 카드 알림에서 월 사용액을 합산합니다. 서버에는 월 합계와 중복 방지 정보만 새로 저장합니다. 알림 원문·가맹점은 보내지 않습니다.",14);
        connect=CardUi.button(box,"동의하고 연결",v->run(()->{JSONObject r=DeviceEnrollment.connect(this);if("approval_pending".equals(r.optString("status")))return "기존 기기에서 아래 확인 문자를 확인하고 승인해 주세요.\n"+r.getString("code")+"\n승인 후 ‘연결 확인’을 눌러 주세요.";return "기기 연결 완료 · 알림 접근을 허용한 뒤 다음 평소 결제 알림을 기다려 주세요.";}));CardUi.style(connect,true,false);
        permission=CardUi.button(box,"알림 접근 허용",v->CardUi.openNotificationSettings(this));
        text("처음 감지한 카드만 본인 카드인지 한 번 확인합니다. 기존에 확인한 카드는 유지돼요.",14);
        LinearLayout shared=CardUi.fold(box,"배우자 기기 초대",false);
        invite=CardUi.button(shared,"초대 만들기",v->run(()->{DeviceEnrollment.invitation(this,"invite",null);return "초대를 만들었어요. 15분 안에 링크를 열어 주세요.";}));
        share=CardUi.button(shared,"초대 링크 공유",v->{try{String link=DeviceEnrollment.inviteLink(this);Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"째미즈 asset 앱을 설치한 뒤 이 초대 링크를 열어 주세요.\n"+link);startActivity(Intent.createChooser(send,"배우자에게 초대 링크 공유"));}catch(Exception e){status.setText("먼저 초대를 만들어 주세요.");}});
        check=CardUi.button(shared,"연결 요청 확인",v->run(()->{JSONObject r=DeviceEnrollment.invitation(this,"inviteStatus",null);String state=r.optString("status");if("approval_pending".equals(state)){String code=r.getString("code");main.post(()->{if(visible)new AlertDialog.Builder(this).setTitle("배우자 기기를 연결할까요?").setMessage("새 기기 화면의 확인 문자가 아래와 같은지 확인해 주세요.\n\n"+code).setNegativeButton("취소",null).setPositiveButton("같아요 · 연결 승인",(d,w)->run(()->{DeviceEnrollment.invitation(this,"approve",code);return "승인했어요. 새 기기에서 연결 확인을 눌러 주세요.";})).show();});return "새 기기의 확인 문자를 확인해 주세요.";}return "used".equals(state)?"초대한 기기가 연결됐어요.":"expired".equals(state)||"cancelled".equals(state)?"초대를 사용할 수 없어요. 새 초대를 만들어 주세요.":"새 기기에서 초대 링크를 열기를 기다리고 있어요.";}));
        cancel=CardUi.button(shared,"초대 취소",v->run(()->{DeviceEnrollment.invitation(this,"cancel",null);return "초대를 취소했어요. 이미 연결된 기기는 해제되지 않아요.";}));
        revoke=CardUi.button(box,"이 기기 연결 해제",v->new AlertDialog.Builder(this).setTitle("이 기기의 서버 연결을 해제할까요?").setMessage("이 기기의 전송 권한을 폐기합니다. 폰의 대기 자료는 삭제하지 않습니다.").setNegativeButton("유지",null).setPositiveButton("연결 해제",(d,w)->run(()->{DeviceEnrollment.revoke(this);return "이 기기의 서버 연결을 해제했어요. 대기 자료는 폰에 남아 있어요.";})).show());
        handleLink(getIntent());refresh();
    }
    private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextColor(0xff17333b);t.setTextSize(size);t.setPadding(0,12,0,12);box.addView(t);return t;}
    private void handleLink(Intent intent){android.net.Uri uri=intent.getData();if(uri==null)return;intent.setData(null);try{if(!"jjaemizasset".equals(uri.getScheme())||!"join".equals(uri.getHost())||uri.getQuery()!=null||!CapturePolicy.tokenValid(uri.getFragment()))throw new IllegalArgumentException();DeviceEnrollment.acceptInvite(this,uri.getFragment());status.setText("배우자 기기로 연결할 초대를 받았어요. 수집 범위를 확인하고 동의해 주세요.");}catch(Exception e){status.setText("초대를 적용하지 못했어요. 기존 연결을 확인하거나 새 초대를 받아 주세요.");}}
    private void refresh(){boolean linked=DeviceEnrollment.linked(this),activeInvite=DeviceEnrollment.activeInvite(this);String stage=DeviceEnrollment.stage(this);
        connect.setText(linked?"서버 연결 확인":stage.equals("existing")?"기존 연결로 자동 설정":stage.equals("pending")?"승인 후 연결 확인":stage.equals("invited")?"동의하고 연결":"초대 링크를 열어 주세요");
        for(Button b:new Button[]{connect,invite,check,share,cancel,revoke})b.setEnabled(!busy);
        connect.setEnabled(!busy&&!stage.equals("empty")&&!stage.equals("error")&&!stage.equals("revoked")&&!stage.equals("invalid"));
        for(Button b:new Button[]{invite,check,share,cancel,revoke})b.setVisibility(linked?View.VISIBLE:View.GONE);
        invite.setText(activeInvite?"초대 준비됨":"새 초대 만들기");invite.setEnabled(!busy&&!activeInvite);
        for(Button b:new Button[]{check,share,cancel})b.setEnabled(!busy&&activeInvite);
        permission.setVisibility(DeviceEnrollment.consented(this)?View.VISIBLE:View.GONE);
        if(status.getText().toString().equals("연결 상태 확인 중…"))status.setText(DeviceEnrollment.stageText(this));
    }
    private void run(Action action){if(busy)return;busy=true;refresh();int current=++generation;status.setText("확인 중…");new Thread(()->{String result;try{result=action.run();}catch(Exception e){result=e.getMessage()==null?"연결하지 못했어요. 다시 시도해 주세요.":e.getMessage();}String message=result;main.post(()->{busy=false;if(!isFinishing()&&current==generation){status.setText(message);refresh();}});},"device-enrollment").start();}
    @Override protected void onResume(){super.onResume();visible=true;refresh();}
    @Override protected void onPause(){visible=false;super.onPause();}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleLink(i);refresh();}
}

