package kr.household.hanacollector;

import android.content.Context;
import android.security.keystore.*;
import java.security.*;
import javax.crypto.*;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/** Native-only credentials. A persisted request makes network retries idempotent. */
final class DeviceEnrollment {
    static final class RequestFailure extends IOException {final int status;RequestFailure(int status,String message){super(message);this.status=status;}}
    static final String ENDPOINT="https://xcchskngoactqsiiutsp.supabase.co/functions/v1/collector-enroll";
    static final String[] CARDS={"hana","kb","nh","shinhan"};
    private static EncryptedOutboxStore store(Context c)throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);String alias="household-enrollment";
        if(!ks.containsAlias(alias)){KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}
        return new EncryptedOutboxStore(c.getNoBackupFilesDir().toPath().resolve("enrollment.bin"),(SecretKey)ks.getKey(alias,null));
    }
    static synchronized JSONObject read(Context c)throws Exception{byte[] b=store(c).read();return b==null?new JSONObject():new JSONObject(new String(b,StandardCharsets.UTF_8));}
    private static synchronized void save(Context c,JSONObject s)throws Exception{store(c).commit(s.toString().getBytes(StandardCharsets.UTF_8));}
    static String random(){byte[] b=new byte[32];new SecureRandom().nextBytes(b);StringBuilder s=new StringBuilder();for(byte v:b)s.append(String.format("%02x",v&255));return s.toString();}
    static String cardToken(Context c,int n)throws Exception{switch(n){case 0:return TokenVault.load(c);case 1:return KbTokenVault.load(c);case 2:return NhTokenVault.load(c);default:return ShinhanTokenVault.load(c);}}
    static boolean hasLegacy(Context c){try{for(int n=0;n<4;n++)if(cardToken(c,n)!=null)return true;}catch(Exception ignored){}return false;}
    static boolean linked(Context c){try{return read(c).optBoolean("linked",false);}catch(Exception ignored){return false;}}
    static boolean consented(Context c){try{return hasLegacy(c)||read(c).optBoolean("consented",false);}catch(Exception ignored){return false;}}
    static String stage(Context c){try{JSONObject s=read(c);if(s.optBoolean("revoked",false))return "revoked";if(s.optBoolean("linked",false))return "linked";if(s.optBoolean("invalidInvite",false))return "invalid";if(s.optBoolean("pending",false))return "pending";if(s.has("join"))return "invited";return hasLegacy(c)?"existing":"empty";}catch(Exception e){return "error";}}
    static String stageText(Context c){switch(stage(c)){case "linked":return "기기 등록됨 · 카드별 수집 상태는 아래에서 확인해요.";case "pending":return "기존 기기의 승인을 기다리고 있어요.";case "invited":return "초대를 받았어요. 동의하고 연결해 주세요.";case "existing":return "기존 카드 연결을 그대로 자동 설정할 수 있어요.";case "revoked":return "이 기기의 서버 연결이 해제됐어요.";case "error":return "연결 정보를 읽지 못했어요. 앱 데이터는 유지해 주세요.";default:return "초대가 필요해요. 기존 기기에서 받은 링크를 열어 주세요.";}}
    static synchronized void acceptInvite(Context c,String value)throws Exception{
        if(!CapturePolicy.tokenValid(value)||linked(c)||hasLegacy(c))throw new IllegalStateException("기존 연결이 있는 기기에는 초대를 적용하지 않아요.");
        // Keep the persisted installation and bundle when a replacement invite arrives.
        // A prior server commit may still need recovery after its response was lost.
        JSONObject s=read(c);
        s.put("join",value).put("pending",false).put("invalidInvite",false);save(c,s);
    }
    private static synchronized JSONObject prepare(Context c)throws Exception{
        JSONObject s=read(c);if(!s.has("installation")){
            JSONObject keys=new JSONObject();for(int n=0;n<4;n++){String old=cardToken(c,n);keys.put(CARDS[n],old==null?random():old);}
            s.put("installation",random()).put("keys",keys);save(c,s);
        }return s;
    }
    static JSONObject request(String auth,JSONObject body)throws Exception{
        HttpsURLConnection conn=(HttpsURLConnection)new URL(ENDPOINT).openConnection();
        try{conn.setInstanceFollowRedirects(false);conn.setConnectTimeout(10000);conn.setReadTimeout(10000);conn.setRequestMethod("POST");conn.setRequestProperty("Authorization","Bearer "+auth);conn.setRequestProperty("Content-Type","application/json");conn.setUseCaches(false);conn.setDoOutput(true);byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);conn.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=conn.getOutputStream()){out.write(bytes);}
            int status=conn.getResponseCode();if(status!=200)throw new RequestFailure(status,status==401?"연결 권한이나 초대가 만료됐어요. 초대를 다시 받아 주세요.":status==409?"이미 사용된 초대이거나 다른 연결이 있어요. 새 초대를 받아 주세요.":status==412?"배우자 등록 준비가 필요해요. 기존 연결은 유지돼요.":"연결하지 못했어요. 인터넷을 확인하고 다시 시도해 주세요.");
            try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buffer=new byte[1024];int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>4096)throw new IOException("서버 응답을 확인하지 못했어요.");}return new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));}
        }finally{conn.disconnect();}
    }
    static JSONObject connect(Context c)throws Exception{
        JSONObject s=prepare(c);if(s.optBoolean("revoked",false))throw new IOException("이 기기는 연결이 해제됐어요.");
        if(s.optBoolean("linked",false))return request(s.getString("installation"),new JSONObject().put("op","status"));
        // Recover a committed enrollment after its success response was lost, even if the invite expired.
        if(s.optBoolean("attempted",false))try{JSONObject r=request(s.getString("installation"),new JSONObject().put("op","status").put("keys",s.getJSONObject("keys")));if("linked".equals(r.optString("status"))){complete(c,s);return r;}}catch(IOException unavailable){}
        String auth=s.optString("join",null),op="join";
        if(auth==null){op="bootstrap";for(int n=0;n<4;n++){String old=cardToken(c,n);if(old!=null){auth=old;break;}}if(auth==null)throw new IOException("기존 기기에서 받은 초대 링크를 열어 주세요.");}
        s.put("attempted",true).put("consented",true);save(c,s);
        JSONObject response;
        try{response=request(auth,new JSONObject().put("op",op).put("installation",s.getString("installation")).put("keys",s.getJSONObject("keys")));}
        catch(RequestFailure failure){if(op.equals("join")&&(failure.status==401||failure.status==409)){s.put("invalidInvite",true);save(c,s);}throw failure;}
        if("linked".equals(response.optString("status")))complete(c,s);
        else if("approval_pending".equals(response.optString("status"))){s.put("pending",true);save(c,s);}
        return response;
    }
    private static synchronized void complete(Context c,JSONObject s)throws Exception{
        JSONObject keys=s.getJSONObject("keys");
        // Preflight all slots before any write: never hide the old key's encrypted queue.
        for(int n=0;n<4;n++){String old=cardToken(c,n);if(old!=null&&!old.equals(keys.getString(CARDS[n])))throw new IOException("연결 정보가 바뀌었어요. 기존 자료를 유지하고 확인이 필요해요.");}
        for(int n=0;n<4;n++)if(cardToken(c,n)==null){String value=keys.getString(CARDS[n]);switch(n){case 0:TokenVault.save(c,value);CaptureRuntime.keyChanged(c);break;case 1:KbTokenVault.save(c,value);KbCaptureRuntime.keyChanged(c);break;case 2:NhTokenVault.save(c,value);NhCaptureRuntime.keyChanged(c);break;default:ShinhanTokenVault.save(c,value);ShinhanCaptureRuntime.keyChanged(c);}}
        s.put("linked",true).put("pending",false).put("consented",true);s.remove("join");save(c,s);
    }
    static JSONObject invitation(Context c,String op,String code)throws Exception{
        JSONObject s=read(c);if(!s.optBoolean("linked",false))throw new IOException("먼저 이 기기를 연결해 주세요.");
        if(op.equals("invite")&&s.has("expires")&&!activeInvite(c)){s.remove("invite");s.remove("expires");}
        if(op.equals("invite")&&!s.has("invite")){s.put("invite",random());save(c,s);}
        if(!s.has("invite"))throw new IOException("먼저 초대를 만들어 주세요.");
        JSONObject body=new JSONObject().put("op",op).put("invite",s.getString("invite"));if(code!=null)body.put("code",code);
        JSONObject result=request(s.getString("installation"),body);
        String status=result.optString("status");
        if(op.equals("cancel")||status.equals("expired")||status.equals("cancelled")||status.equals("used")){s.remove("invite");s.remove("expires");save(c,s);}else if(result.has("expiresAt")){s.put("expires",result.getString("expiresAt"));save(c,s);}
        return result;
    }
    static boolean activeInvite(Context c){try{JSONObject s=read(c);return s.has("invite")&&s.has("expires")&&java.time.Instant.parse(s.getString("expires")).toEpochMilli()>System.currentTimeMillis();}catch(Exception e){return false;}}
    static String inviteLink(Context c)throws Exception{return "jjaemizasset://join#"+read(c).getString("invite");}
    static void revoke(Context c)throws Exception{JSONObject s=read(c);request(s.getString("installation"),new JSONObject().put("op","revoke"));s.put("linked",false).put("revoked",true);s.remove("invite");save(c,s);}
    private DeviceEnrollment(){}
}
