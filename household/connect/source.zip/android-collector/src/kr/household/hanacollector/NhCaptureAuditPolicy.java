package kr.household.hanacollector;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Only decides whether a content-free local NH diagnostic is eligible. */
final class NhCaptureAuditPolicy {
    private static final Pattern HEADER=Pattern.compile("(?m)^\\s*NH(?:농협)?카드\\s*\\(?([0-9*]{4})\\)?\\s*(?:승인취소|승인|결제|취소)(?=\\s|[:：]|$)");
    static boolean eligible(String confirmed,String title,String compact,String expanded){
        if(confirmed==null||!confirmed.matches("[0-9*]{4}")||confirmed.equals("****"))return false;
        if(PushNotice.classify(CaptureOutbox.Card.NH_ZGM,title,compact,expanded)!=PushNotice.Kind.TRANSACTION)return false;
        boolean matched=false;
        for(String value:new String[]{title,compact,expanded}){
            if(value==null)continue;
            Matcher header=HEADER.matcher(value);
            while(header.find()){if(!confirmed.equals(header.group(1)))return false;matched=true;}
            if(value.matches("(?s).*?(?:KB국민카드|신한카드|삼성카드).*"))return false;
        }
        return matched;
    }
    static boolean recoverable(boolean confirmed,boolean enabled,long since,long posted,long now){
        return confirmed&&enabled&&since>0&&since<=now&&posted>=since&&posted<=now+300000L
                &&posted>=now-172800000L;
    }
    private NhCaptureAuditPolicy(){}
}
