package kr.household.hanacollector;

import java.time.*;
import java.util.regex.*;

/** Local-only diagnostic parser. Only the observed domestic one-time purchase
 * shape is supported. This class has no storage or networking dependencies. */
public final class HanaPushParser {
    private static final String MONEY="(?:[1-9][0-9]{0,2}(?:,[0-9]{3})+|[1-9][0-9]*|0)";
    private static final Pattern TITLE=Pattern.compile("^\\(결제\\)\\s*("+MONEY+")원$");
    private static final Pattern BODY=Pattern.compile("^(.{1,150}?)\\s*/\\s*신용\\(일시불,\\s*([0-9*]{4})\\)\\s*/\\s*(\\d{2})\\.(\\d{2})\\s+([0-2]\\d):([0-5]\\d)\\s*/\\s*누적이용금액\\s*("+MONEY+")원$");
    public static final class Result {
        public final long amount,occurredAt,cumulative;
        public final String maskedCard;
        Result(long amount,long occurredAt,String maskedCard,long cumulative){this.amount=amount;this.occurredAt=occurredAt;this.maskedCard=maskedCard;this.cumulative=cumulative;}
        public String localDisplay(){return "국내 일시불 결제 형식 확인\n이번 결제: "+amount+"원\n카드 표시: "+maskedCard+"\n거래 시각: "+Instant.ofEpochMilli(occurredAt).atZone(ZoneId.of("Asia/Seoul"))+"\n누적금액은 합산하지 않았습니다.\nMOVING ONLINE 카드인지 본인 확인이 필요합니다.\n카드 확인과 자동 집계 상태는 위에서 확인하세요.";}
    }
    public static Result parse(String title,String body,long postedAt){
        if(title==null||body==null||title.length()>100||body.length()>2000)return null;
        Matcher a=TITLE.matcher(title.trim()),b=BODY.matcher(body.trim().replaceAll("\\s+"," "));
        if(!a.matches()||!b.matches())return null;
        try{
            long amount=Long.parseLong(a.group(1).replace(",",""));
            if(amount<1||amount>1000000000L||b.group(2).equals("****"))return null;
            ZoneId kst=ZoneId.of("Asia/Seoul");int year=Instant.ofEpochMilli(postedAt).atZone(kst).getYear();
            Long candidate=null;
            for(int y=year-1;y<=year+1;y++){
                long when;try{when=LocalDateTime.of(y,Integer.parseInt(b.group(3)),Integer.parseInt(b.group(4)),Integer.parseInt(b.group(5)),Integer.parseInt(b.group(6))).atZone(kst).toInstant().toEpochMilli();}catch(DateTimeException e){continue;}
                // Infer year only for a recent notification, including New Year.
                if(when<=postedAt+5*60*1000&&when>=postedAt-48*60*60*1000L){if(candidate!=null)return null;candidate=when;}
            }
            long cumulative=Long.parseLong(b.group(7).replace(",",""));
            if(cumulative<amount||cumulative>100000000000L)return null;
            return candidate==null?null:new Result(amount,candidate,b.group(2),cumulative);
        }catch(RuntimeException e){return null;}
    }
    private HanaPushParser(){}
}
