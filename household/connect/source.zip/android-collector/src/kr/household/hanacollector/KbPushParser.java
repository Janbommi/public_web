package kr.household.hanacollector;

import java.time.*;
import java.util.regex.*;

/** Observed KB domestic one-time shape. No storage/network or merchant/name output.
 * KB enrollment and transport remain separate from Hana. */
public final class KbPushParser {
    private static final String MONEY="(?:[1-9][0-9]{0,2}(?:,[0-9]{3})+|[1-9][0-9]*|0)";
    private static final Pattern BODY=Pattern.compile("^KB국민카드\\s*([0-9*]{4})\\s*승인\\s+[^\\s]{1,24}님\\s+("+MONEY+")원\\s+일시불\\s+(\\d{2})/(\\d{2})\\s+([0-2]\\d):([0-5]\\d)\\s+(.{1,150}?)\\s+누적\\s*("+MONEY+")원$");
    public static final class Result {
        public final long amount,occurredAt,cumulative;
        public final String cardDisplay;
        Result(long amount,long occurredAt,String card,long cumulative){this.amount=amount;this.occurredAt=occurredAt;cardDisplay=card;this.cumulative=cumulative;}
    }
    public static Result fromExtras(String text,String bigText,long postedAt){
        Result shortBody=parse(text,postedAt),longBody=parse(bigText,postedAt);
        if(shortBody!=null&&longBody!=null&&(shortBody.amount!=longBody.amount||shortBody.cumulative!=longBody.cumulative||shortBody.occurredAt!=longBody.occurredAt||!shortBody.cardDisplay.equals(longBody.cardDisplay)))return null;
        // A present expanded body must be complete; do not fall back past a malformed expanded alert.
        return bigText!=null&&!bigText.trim().isEmpty()?longBody:shortBody;
    }
    /** Expects one complete body; callers must resolve Android extras before calling. */
    public static Result parse(String body,long postedAt){
        if(body==null||body.length()>2000||postedAt<=0)return null;
        String text=body.trim().replaceAll("\\s+"," ");
        Matcher m=BODY.matcher(text);
        if(!m.matches()||m.group(1).equals("****"))return null;
        // Never interpret a multi-message summary, another approval or amount as a merchant.
        String merchant=m.group(7);
        if(merchant.contains("KB국민카드")||merchant.contains("누적")||Pattern.compile("[0-9][0-9,]*원").matcher(merchant).find())return null;
        try {
            long amount=Long.parseLong(m.group(2).replace(",","")),cumulative=Long.parseLong(m.group(8).replace(",",""));
            if(amount<1||amount>1000000000L||cumulative<amount||cumulative>100000000000L)return null;
            ZoneId kst=ZoneId.of("Asia/Seoul");int year=Instant.ofEpochMilli(postedAt).atZone(kst).getYear();Long occurred=null;
            for(int y=year-1;y<=year+1;y++){
                long candidate;
                try{candidate=LocalDateTime.of(y,Integer.parseInt(m.group(3)),Integer.parseInt(m.group(4)),Integer.parseInt(m.group(5)),Integer.parseInt(m.group(6))).atZone(kst).toInstant().toEpochMilli();}catch(DateTimeException e){continue;}
                if(candidate>=postedAt-48*60*60*1000L&&candidate<=postedAt+5*60*1000L){if(occurred!=null)return null;occurred=candidate;}
            }
            return occurred==null?null:new Result(amount,occurred,m.group(1),cumulative);
        }catch(RuntimeException e){return null;}
    }
    private KbPushParser(){}
}
