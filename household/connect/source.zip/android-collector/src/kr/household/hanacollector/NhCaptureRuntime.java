package kr.household.hanacollector;

import android.content.Context;
import android.app.job.*;
import android.content.ComponentName;
import android.security.keystore.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/** Serial local capture; only normalized purchase fields reach the outbox. */
final class NhCaptureRuntime {
    static final String PROFILE="nh-pay-krw-onetime-v1";
    static final int JOB=5109;
    private static final java.util.concurrent.ExecutorService worker=Executors.newSingleThreadExecutor();
    private static String currentNamespace;private static Session cached;
    private static final java.util.Map<String,Session> sessions=new java.util.HashMap<>();
    private static String failure="";
    static volatile boolean jobRunning=false;
    static final class Session {
        final String token,namespace;final EncryptedOutboxStore configStore;final CaptureOutbox queue;
        NhCaptureAudit audit;String auditFailure="",recoveryWarning="";
        JSONObject config;
        Session(String token,String ns,Context c)throws Exception {
            this.token=token;namespace=ns;
            KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);String alias="household-nh-capture-"+ns;
            if(!ks.containsAlias(alias)){
                KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
                g.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();
            }
            javax.crypto.SecretKey key=(javax.crypto.SecretKey)ks.getKey(alias,null);
            Path dir=c.getNoBackupFilesDir().toPath();
            configStore=new EncryptedOutboxStore(dir.resolve("nh-capture-"+ns+"-config.bin"),key);
            byte[] old=configStore.read();config=old==null?new JSONObject():new JSONObject(new String(old,StandardCharsets.UTF_8));
            queue=new CaptureOutbox(new EncryptedOutboxStore(dir.resolve("nh-capture-"+ns+"-outbox.bin"),key));
            // Diagnostic damage must never block an existing monetary outbox.
            try{audit=new NhCaptureAudit(new EncryptedOutboxStore(dir.resolve("nh-capture-"+ns+"-diagnostics.bin"),key),System.currentTimeMillis());}
            catch(Exception e){auditFailure="진단 기록을 읽지 못했어요. 기존 결제 전송은 계속하며, 진단 파일을 초기화하지 않았어요.";}
        }
        void save(JSONObject next)throws Exception {configStore.commit(next.toString().getBytes(StandardCharsets.UTF_8));config=next;}
        JSONObject copy()throws Exception{return new JSONObject(config.toString());}
    }
    private static String hex(byte[] bytes){StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format("%02x",b&255));return s.toString();}
    static synchronized Session session(Context c)throws Exception {
        String token=NhTokenVault.load(c);if(token==null)return null;
        String ns=hex(MessageDigest.getInstance("SHA-256").digest(token.getBytes(StandardCharsets.UTF_8)));
        if(cached==null||!ns.equals(currentNamespace)){cached=sessions.get(ns);if(cached==null){cached=new Session(token,ns,c);sessions.put(ns,cached);}currentNamespace=ns;}return cached;
    }
    private static String digest(Session s,String value)throws Exception {
        Mac mac=Mac.getInstance("HmacSHA256");mac.init(new SecretKeySpec(s.token.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));return hex(mac.doFinal(("nh-capture-local-v1|"+value).getBytes(StandardCharsets.UTF_8)));
    }
    static boolean hasKey(Context c){try{return NhTokenVault.load(c)!=null;}catch(Exception e){return false;}}
    static synchronized void unsupported(){failure="NH 알림을 받았지만 지원 형식이 아니거나 내용이 가려져 있어요. 금액은 전송하지 않았습니다.";}
    static void unsupported(Context c,String title,String text,String expanded,String key,long at,boolean recovered){
        unsupported();recordUnparsed(c,title,text,expanded,key,at,recovered,NhCaptureAudit.Reason.FORMAT);
    }
    private static boolean recoveryAllowed(Session s,long at,long now){
        return NhCaptureAuditPolicy.recoverable(s.config.has("mask"),s.config.optBoolean("enabled",false),s.config.optLong("recoverySince",0),at,now);
    }
    static synchronized boolean prepareRecovery(Context c){try{
        Session s=session(c);if(s==null||!s.config.has("mask")||!s.config.optBoolean("enabled",false))return false;
        // An old config has no trustworthy active-period boundary. Establish it
        // now, preserving the existing key/outbox and never importing older alerts.
        if(!s.config.has("recoverySince")){JSONObject next=s.copy();next.put("recoverySince",System.currentTimeMillis());s.save(next);return false;}
        return true;
    }catch(Exception e){return false;}}
    static synchronized boolean canRecover(Context c,long at){try{Session s=session(c);return s!=null&&recoveryAllowed(s,at,System.currentTimeMillis());}catch(Exception e){return false;}}
    static synchronized void recoveryUnavailable(Context c){try{Session s=session(c);if(s!=null)s.recoveryWarning="알림함의 남은 NH 알림을 확인하지 못했어요. 새 알림 수집과 기존 전송은 계속해요.";}catch(Exception ignored){}}
    static synchronized void recoveryLimited(Context c){try{Session s=session(c);if(s!=null)s.recoveryWarning="알림함에 남은 항목이 많아 최근 128개만 확인했어요.";}catch(Exception ignored){}}
    private static void audit(Session s,String receipt,NhCaptureAudit.Reason reason,CaptureOutbox.Item item,long now){
        if(s.audit==null)return;
        try{s.audit.record(receipt,reason,item==null?null:item.id,now);s.auditFailure="";}
        catch(Exception e){s.auditFailure="이번 알림의 진단 저장을 확인하지 못했어요. 결제 저장·전송 상태는 위에서 확인해 주세요.";}
    }
    private static void recordUnparsed(Context context,String title,String text,String expanded,String key,long at,boolean recovered,NhCaptureAudit.Reason reason){
        final Context c=context.getApplicationContext();final Session observedSession;final String receipt;
        try{
            observedSession=session(c);long now=System.currentTimeMillis();
            if(observedSession==null||!observedSession.config.optBoolean("enabled",false)||key==null||at<=0||at>now+300000L
                ||(recovered&&!recoveryAllowed(observedSession,at,now))
                ||!NhCaptureAuditPolicy.eligible(observedSession.config.optString("mask",null),title,text,expanded))return;
            receipt=digest(observedSession,"receipt|"+key+"|"+at);
        }catch(Exception e){return;}
        // Only normalized metadata reaches the worker closure; no raw extras.
        worker.execute(()->{synchronized(NhCaptureRuntime.class){try{
            Session s=session(c);if(s!=observedSession||!s.config.optBoolean("enabled",false)||(recovered&&!recoveryAllowed(s,at,System.currentTimeMillis())))return;
            audit(s,receipt,reason,null,System.currentTimeMillis());
        }catch(Exception ignored){}}});
    }
    static void referenced(Context context,String title,String text,String expanded,String notificationKey,long postedAt){
        referenced(context,title,text,expanded,notificationKey,postedAt,false);
    }
    static void referenced(Context context,String title,String text,String expanded,String notificationKey,long postedAt,boolean recovered){
        Context c=context.getApplicationContext();
        final Session observedSession;
        final ReferencedPushParser.Result event;
        try {
            observedSession=session(c);
            if(observedSession==null||(recovered&&!recoveryAllowed(observedSession,postedAt,System.currentTimeMillis())))return;
            event=ReferencedPushParser.fromExtras(CaptureOutbox.Card.NH_ZGM,title,text,expanded,postedAt,
                    value->digest(observedSession,value));
        } catch(Exception e){referenceFailure();recordUnparsed(c,title,text,expanded,notificationKey,postedAt,recovered,NhCaptureAudit.Reason.REFERENCE);return;}
        if(event==null){referenceFailure();recordUnparsed(c,title,text,expanded,notificationKey,postedAt,recovered,NhCaptureAudit.Reason.REFERENCE);return;}
        worker.execute(()->{synchronized(NhCaptureRuntime.class){try {
            Session s=session(c);
            if(s!=observedSession||(recovered&&!recoveryAllowed(s,postedAt,System.currentTimeMillis())))return;
            String receipt=digest(s,"receipt|"+notificationKey+"|"+postedAt);
            String evidence=digest(s,"nh|"+event.cardDisplay+"|"+event.amount+"|"+event.occurredAt+"|"+event.cumulative);
            boolean active=s.config.optBoolean("enabled",false)&&s.config.optString("mask").equals(event.cardDisplay);
            if(active)audit(s,receipt,NhCaptureAudit.Reason.PARSED,null,System.currentTimeMillis());
            CaptureOutbox.Item item=ReferencedCapture.record(s.queue,CaptureOutbox.Card.NH_ZGM,s.config,event,receipt,evidence,
                    postedAt,System.currentTimeMillis(),candidate->{
                        JSONObject next=s.copy();next.put("candidate",candidate);s.save(next);
                    });
            if(active&&item!=null)audit(s,receipt,NhCaptureAudit.Reason.PARSED,item,System.currentTimeMillis());
            failure="";schedule(c,s);
        }catch(Exception e){referenceFailure();}}});
    }
    private static synchronized void referenceFailure(){
        failure="알림을 원결제에 연결하지 못했어요. 카드 이용내역에서 해당 월 사용액을 확인해 주세요.";
    }
    static void observed(Context context,AdditionalPushParser.Result parsed,String notificationKey,long postedAt){
        observed(context,parsed,notificationKey,postedAt,false);
    }
    static void observed(Context context,AdditionalPushParser.Result parsed,String notificationKey,long postedAt,boolean recovered){
        final Context c=context.getApplicationContext();
        final String observedToken;try{observedToken=NhTokenVault.load(c);}catch(Exception e){return;}
        worker.execute(()->{synchronized(NhCaptureRuntime.class){try{
            Session s=session(c);if(s==null||parsed==null||parsed.issuer!=AdditionalPushParser.Issuer.NH)return;
            if(!s.token.equals(observedToken))return;
            long now=System.currentTimeMillis();
            if(recovered&&!recoveryAllowed(s,postedAt,now))return;
            if(parsed.occurredAt<now-CaptureOutbox.MAX_AGE||parsed.occurredAt>now+300000L||postedAt>now+300000L||postedAt<parsed.occurredAt-300000L||postedAt>parsed.occurredAt+172800000L)return;
            // Notification key + original posted time identifies a delivery, not a bank approval.
            String receipt=digest(s,"receipt|"+notificationKey+"|"+postedAt);
            String evidence=digest(s,"nh|"+parsed.cardDisplay+"|"+parsed.amount+"|"+parsed.occurredAt+"|"+parsed.cumulative);
            JSONObject candidate=new JSONObject().put("mask",parsed.cardDisplay).put("amount",parsed.amount).put("occurred",parsed.occurredAt).put("receipt",receipt).put("evidence",evidence).put("saved",now).put("cumulative",parsed.cumulative).put("observed",postedAt).put("telecomKind",parsed.telecomKind);
            if(!s.config.has("mask")) {JSONObject next=s.copy();next.put("candidate",candidate);s.save(next);}
            else if(s.config.optString("mask").equals(parsed.cardDisplay)&&s.config.optBoolean("enabled",false)){
                audit(s,receipt,NhCaptureAudit.Reason.PARSED,null,now);
                CaptureOutbox.Item item=s.queue.observeNh(receipt,evidence,parsed.amount,parsed.occurredAt,postedAt,parsed.cumulative,now,parsed.telecomKind);
                audit(s,receipt,NhCaptureAudit.Reason.PARSED,item,now);
            }
            failure="";schedule(c,s);
        }catch(Exception e){failure="결제 저장을 확인하지 못했습니다. 앱에서 상태를 확인해 주세요.";}}});
    }
    static synchronized String confirmText(Context c){try{
        Session s=session(c);if(s==null)return "기존 연결 키가 필요합니다.";
        if(s.config.has("mask"))return "확인한 NH카드 "+s.config.optString("mask")+" · "+(s.config.optBoolean("enabled",false)?"자동 집계 켜짐":"자동 집계 꺼짐");
        JSONObject v=s.config.optJSONObject("candidate");if(v==null||System.currentTimeMillis()-v.optLong("saved")>CaptureOutbox.MAX_AGE)return "새 NH pay 일시불 알림을 기다립니다. 다음 평소 결제 후 이 화면을 열어 주세요.";
        return "NH카드 "+v.optString("mask")+" · "+v.optLong("amount")+"원 · 누적 "+v.optLong("cumulative")+"원\n"+java.time.Instant.ofEpochMilli(v.optLong("occurred")).atZone(java.time.ZoneId.of("Asia/Seoul"))+"\n이 알림이 본인 zgm 할인 결제인지 확인해 주세요.";
    }catch(Exception e){return "카드 확인 정보를 읽지 못했습니다.";}}
    static synchronized String candidateId(Context c)throws Exception {
        Session s=session(c);JSONObject v=s==null?null:s.config.optJSONObject("candidate");if(v==null)throw new IllegalStateException();return v.getString("receipt")+v.getString("evidence")+v.optString("purchaseRef");
    }
    static synchronized void confirm(Context c,String expected)throws Exception {
        Session s=session(c);if(s==null)throw new IllegalStateException();JSONObject v=s.config.optJSONObject("candidate");
        if(v==null||System.currentTimeMillis()-v.optLong("saved")>CaptureOutbox.MAX_AGE)throw new IllegalStateException();
        if(!candidateId(c).equals(expected))throw new IllegalStateException();
        long now=System.currentTimeMillis();JSONObject next=s.copy();next.put("mask",v.getString("mask")).put("enabled",true).put("activationAttempts",0).put("recoverySince",now);
        // Persist the queue first. Repeated confirmation will reuse the same purchase id.
        CaptureOutbox.Item item=v.has("purchaseRef")?ReferencedCapture.enqueuePurchase(s.queue,CaptureOutbox.Card.NH_ZGM,v,now)
            :s.queue.observeNh(v.getString("receipt"),v.getString("evidence"),v.getLong("amount"),v.getLong("occurred"),v.getLong("observed"),v.getLong("cumulative"),now,v.optString("telecomKind",""));
        next.remove("candidate");s.save(next);audit(s,v.getString("receipt"),NhCaptureAudit.Reason.PARSED,item,now);schedule(c,s);
    }
    static synchronized void enabled(Context c,boolean value)throws Exception {
        Session s=session(c);if(s==null||!s.config.has("mask"))throw new IllegalStateException();JSONObject next=s.copy();next.put("enabled",value).put("activationAttempts",0);
        if(value&&(!s.config.optBoolean("enabled",false)||!s.config.has("recoverySince")))next.put("recoverySince",System.currentTimeMillis());s.save(next);
        if(value)schedule(c,s);else c.getSystemService(JobScheduler.class).cancel(JOB);
    }
    static synchronized void request(Context c,boolean retry){try{
        Session s=session(c);if(s==null)return;
        if(retry){s.queue.retryBlocked(System.currentTimeMillis());JSONObject next=s.copy();next.put("activationAttempts",0);s.save(next);}
        schedule(c,s);
    }catch(Exception e){failure="결제 전송 예약을 확인하지 못했습니다.";}}
    static synchronized void keyChanged(Context c){c.getSystemService(JobScheduler.class).cancel(JOB);cached=null;currentNamespace=null;failure="";PushNotice.clear(CaptureOutbox.Card.NH_ZGM);}
    static synchronized boolean valid(Context c,Session s){try{return s!=null&&s==session(c)&&s.config.optBoolean("enabled",false);}catch(Exception e){return false;}}
    private static void schedule(Context c,Session s)throws Exception {
        if(jobRunning||!s.config.optBoolean("enabled",false)||s.config.optInt("activationAttempts",0)>=5)return;
        long now=System.currentTimeMillis(),due=s.queue.nextDue(now);if(due==Long.MAX_VALUE)return;
        long activationDelay=30000L*(1L<<Math.min(s.config.optInt("activationAttempts",0),4));
        JobInfo job=new JobInfo.Builder(JOB,new ComponentName(c,NhCaptureUploadJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(Math.max(activationDelay,due-now)).setEstimatedNetworkBytes(8192,8192).build();
        if(c.getSystemService(JobScheduler.class).schedule(job)!=JobScheduler.RESULT_SUCCESS)throw new IllegalStateException();
    }
    static synchronized void activationAttempt(Session s)throws Exception {JSONObject next=s.copy();next.put("activationAttempts",next.optInt("activationAttempts",0)+1);s.save(next);}
    static synchronized void activated(Session s){s.queue.verify(CaptureOutbox.Card.NH_ZGM);}
    static synchronized void delivered(Session s)throws Exception {JSONObject next=s.copy();next.put("activationAttempts",0);s.save(next);}
    static synchronized boolean confirmed(Context c){try{Session s=session(c);return s!=null&&s.config.has("mask");}catch(Exception e){return false;}}
    static synchronized int[] counts(Context c){try{Session s=session(c);if(s==null)return null;int done=0,pending=0,review=0,blocked=0;
        for(CaptureOutbox.Item v:s.queue.snapshot())if(v.state==CaptureOutbox.State.ACKNOWLEDGED)done++;else if(v.state==CaptureOutbox.State.REVIEW||v.state==CaptureOutbox.State.WAITING_ORIGINAL&&s.queue.parentFor(v)==null)review++;else if(v.state==CaptureOutbox.State.BLOCKED||v.attempts>=5)blocked++;else pending++;return new int[]{done,pending,review,blocked};}catch(Exception e){return null;}}
    static synchronized CardUiState uiState(Context c){try{
        Session s=session(c);if(s==null)return CardUiState.missing();
        JSONObject candidate=s.config.optJSONObject("candidate");
        boolean fresh=candidate!=null&&CardUiState.fresh(candidate.optLong("saved"),System.currentTimeMillis());
        return CardUiState.of(s.config.has("mask"),s.config.optBoolean("enabled",false),fresh,counts(c),s.config.optInt("activationAttempts",0),PushNotice.detail(CaptureOutbox.Card.NH_ZGM,failure));
    }catch(Exception e){return CardUiState.unreadable();}}
    static synchronized String status(Context c){try{
        Session s=session(c);if(s==null)return "연결 키를 먼저 저장해 주세요.";
        int[] values=counts(c);if(values==null)throw new IllegalStateException();int done=values[0],pending=values[1],review=values[2],blocked=values[3];
        return (failure.isEmpty()?"":failure+"\n")+"서버 반영 "+done+"건\n전송 대기 "+pending+"건"+(review>0?"\n확인 필요 "+review+"건":"")+(blocked>0?" · 재시도 필요 "+blocked+"건":"")+(s.config.optInt("activationAttempts",0)>=5?"\n서버 시작 확인이 보류됐습니다. 전송 다시 시도를 눌러 주세요.":"");
    }catch(Exception e){return "암호화된 결제 기록을 읽지 못했습니다. 앱 데이터를 삭제하지 말고 알려주세요.";}}
    static synchronized String diagnosticReport(Context c){try{
        Session s=session(c);if(s==null)return "NH 연결 후 본인 카드를 확인하면 새 알림부터 기록해요.";
        String report=s.audit==null?"알림 진단을 읽지 못했어요.":s.audit.report(s.queue,System.currentTimeMillis());
        return report+(s.auditFailure.isEmpty()?"":"\n"+s.auditFailure)+(s.recoveryWarning.isEmpty()?"":"\n"+s.recoveryWarning)+"\n\n"+NhCaptureAudit.confirmedAmounts(s.queue.snapshot(),System.currentTimeMillis());
    }catch(Exception e){return "진단을 읽지 못했어요. 기존 카드 키와 전송 대기 자료를 삭제하지 마세요.";}}
    static synchronized java.util.Map<Long,long[]> confirmedDays(Context c) throws Exception {
        Session current = session(c);
        if (current == null) throw new IllegalStateException("NH connection unavailable");
        return NhCaptureAudit.confirmedDays(current.queue.snapshot(),System.currentTimeMillis());
    }
    private NhCaptureRuntime(){}
}
