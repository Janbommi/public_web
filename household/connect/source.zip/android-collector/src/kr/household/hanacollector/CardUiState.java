package kr.household.hanacollector;

/** Read-only presentation snapshot. Never contains keys, merchant text or purchase details. */
final class CardUiState {
    final String title,next,detail;final boolean canConfirm;final int done,pending;
    private CardUiState(String title,String next,String detail,boolean confirm,int done,int pending){this.title=title;this.next=next;this.detail=detail;canConfirm=confirm;this.done=done;this.pending=pending;}
    static boolean fresh(long saved,long now){return saved>0&&saved<=now&&now-saved<CaptureOutbox.MAX_AGE;}
    static CardUiState missing(){return new CardUiState("연결 필요","연결 설정에서 카드를 연결해 주세요.","",false,-1,-1);}
    static CardUiState unreadable(){return new CardUiState("상태 확인 필요","기존 연결 정보를 읽지 못했어요. 앱 데이터를 삭제하지 마세요.","",false,-1,-1);}
    static CardUiState of(boolean confirmed,boolean enabled,boolean candidate,int[] counts,int attempts,String failure){
        if(counts==null)return unreadable();
        String title=confirmed?(enabled?"자동 집계 켜짐":"일시중지"):(candidate?"본인 카드 확인 필요":"새 알림 대기");
        String next=confirmed?(enabled?"지원되는 새 결제 알림을 모아요.":"수집 관리에서 자동 집계를 재개할 수 있어요."):(candidate?"아래에서 본인 카드인지 확인해 주세요.":"다음 평소 결제 알림을 기다려요.");
        String detail=counts[1]>0?"전송 대기 "+counts[1]+"건 · "+(confirmed&&!enabled?"집계를 재개하면 대기 중인 기록을 전송해요.":"인터넷·절전 상태에 따라 늦어질 수 있어요."):"";
        if(counts[2]>0)detail+=(detail.isEmpty()?"":"\n")+"확인 필요 "+counts[2]+"건";
        if(counts[3]>0||attempts>=5)detail+=(detail.isEmpty()?"":"\n")+"전송 확인 필요 · 수집 관리에서 다시 시도해 주세요.";
        if(failure!=null&&!failure.isEmpty())detail+=(detail.isEmpty()?"":"\n")+failure;
        return new CardUiState(title,next,detail,!confirmed&&candidate,counts[0],counts[1]);
    }
    String next(boolean listener){return !listener&&(title.equals("새 알림 대기")||title.equals("자동 집계 켜짐"))?"알림 접근 설정에서 연결을 확인해 주세요.":next;}
    String home(boolean listener){return title+"\n"+(canConfirm?"눌러서 본인 카드를 확인하세요.":next(listener))+(detail.isEmpty()?"":"\n"+detail);}
}
