package kr.household.hanacollector;

import android.app.job.*;
import android.content.*;
import javax.net.ssl.HttpsURLConnection;

/** One outstanding OS job. New observations coalesce into a small status snapshot. */
final class DiagnosticSync {
    private static final int JOB=4104;
    private static Run active;
    private static boolean localFailure=false;
    static final class Run {
        final long generation,epoch;volatile boolean stopped;volatile HttpsURLConnection connection;
        Run(long generation,long epoch){this.generation=generation;this.epoch=epoch;}
        void stop(){stopped=true;HttpsURLConnection c=connection;if(c!=null)c.disconnect();}
    }
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences("diagnostic_sync",Context.MODE_PRIVATE);}
    private static DiagnosticSyncState load(Context c){
        SharedPreferences p=prefs(c);DiagnosticSyncState s=new DiagnosticSyncState();
        s.enabled=p.getBoolean("enabled",true);s.blocked=p.getBoolean("blocked",false);
        s.generation=p.getLong("generation",0);s.acknowledged=p.getLong("ack",0);s.keyEpoch=p.getLong("epoch",0);
        s.attempts=p.getInt("attempts",0);s.lastSuccess=p.getLong("success",0);return s;
    }
    private static void save(Context c,DiagnosticSyncState s){
        if(!prefs(c).edit().putBoolean("enabled",s.enabled).putBoolean("blocked",s.blocked)
          .putLong("generation",s.generation).putLong("ack",s.acknowledged).putLong("epoch",s.keyEpoch)
          .putInt("attempts",s.attempts).putLong("success",s.lastSuccess).commit())throw new IllegalStateException("Sync state unavailable");
    }
    private static void schedule(Context c,DiagnosticSyncState s){
        if(active!=null||!s.canRun())return;
        JobInfo job=new JobInfo.Builder(JOB,new ComponentName(c,DiagnosticUploadJob.class))
          .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(s.delayMs())
          .setEstimatedNetworkBytes(1024,1024).build();
        if(c.getSystemService(JobScheduler.class).schedule(job)!=JobScheduler.RESULT_SUCCESS)throw new IllegalStateException("Scheduling unavailable");
    }
    static synchronized void request(Context c,boolean retry){
        try{DiagnosticSyncState s=load(c);s.changed(retry);save(c,s);schedule(c,s);localFailure=false;}
        catch(RuntimeException e){localFailure=true;}
    }
    static synchronized void keyChanged(Context c){
        try{DiagnosticSyncState s=load(c);s.keyChanged();save(c,s);if(active!=null)active.stop();schedule(c,s);localFailure=false;}
        catch(RuntimeException e){localFailure=true;}
    }
    static synchronized boolean enabled(Context c){try{return load(c).enabled;}catch(RuntimeException e){return false;}}
    static synchronized void setEnabled(Context c,boolean enabled){
        DiagnosticSyncState s=load(c);s.enabled=enabled;if(enabled)s.changed(true);save(c,s);
        if(!enabled){if(active!=null)active.stop();c.getSystemService(JobScheduler.class).cancel(JOB);}
        else schedule(c,s);
    }
    static synchronized Run begin(Context c){
        try{
            DiagnosticSyncState s=load(c);if(active!=null||!s.canRun())return null;
            s.attempts++;save(c,s);active=new Run(s.generation,s.keyEpoch);return active;
        }catch(RuntimeException e){localFailure=true;return null;}
    }
    static synchronized void finish(Context c,Run run,int code,Runnable finishOs){
        if(active!=run)return;
        DiagnosticSyncState s=null;
        try{
            s=load(c);s.completed(run.generation,run.epoch,code,System.currentTimeMillis());save(c,s);localFailure=false;
        }catch(RuntimeException e){s=null;localFailure=true;}
        active=null;finishOs.run();
        if(s!=null)try{schedule(c,s);}catch(RuntimeException e){localFailure=true;}
    }
    static synchronized String status(Context c){
        try{
            DiagnosticSyncState s=load(c);
            if(!s.enabled)return "진단 자동 전송 꺼짐 · 이미 서버에 보낸 최근 상태는 유지됩니다.";
            if(localFailure)return "진단 전송 예약을 확인하지 못했습니다. 앱을 다시 열거나 ‘진단 전송 다시 시도’를 눌러 주세요.";
            if(s.blocked)return "진단 전송 보류 · 연결 키 또는 앱 버전·기기 시간을 확인해 주세요.";
            if(s.generation>s.acknowledged)return s.attempts>=5?"진단 전송 재시도 5회 종료 · 다음 수신 또는 앱 재진입 때 다시 시도합니다.":"진단 전송 대기 · 인터넷/절전 상태에 따라 지연될 수 있습니다.";
            return s.lastSuccess>0?"진단 서버 전송 완료 · 결제 집계 상태는 위에서 확인하세요.":"진단 자동 전송 준비됨";
        }catch(RuntimeException e){return "진단 전송 상태를 읽지 못했습니다.";}
    }
    private DiagnosticSync(){}
}
