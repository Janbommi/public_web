package kr.household.hanacollector;

import java.util.EnumMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Content-free local status for issuer notifications that cannot change a monthly total. */
final class PushNotice {
    enum Kind {
        TRANSACTION(""), ADVERTISEMENT(""),
        DECLINED("최근 알림 · 승인되지 않아 사용액을 그대로 두었어요."),
        CANCEL_DECLINED("최근 알림 · 취소가 거절되어 원결제 금액을 그대로 두었어요."),
        CHECK("최근 알림 · 처리 결과를 확인할 수 없어 사용액을 그대로 두었어요.");
        final String message;
        Kind(String message) { this.message = message; }
    }

    private static final EnumMap<CaptureOutbox.Card, Kind> latest = new EnumMap<>(CaptureOutbox.Card.class);
    private static final Pattern AD = Pattern.compile("[（(\\[]광고[）)\\]]|(?m)^\\s*무료\\s*수신\\s*거부");
    private static final String END = "(?!\\s*(?:시(?:에는|에|\\s)|예방|방지|대비|문의|대처))(?=$|[\\s\\]）),.:：/!?]|되|됐|입니다|처리|안내|합|하|했|해|로|으로|이에요|예요|이어서)";
    private static final String VERB = "(?:거절|실패|거부|반려|오류|에러|불가능|불가|정지|차단)" + END;
    private static final String NEGATIVE = "(?:(?:처리\\s*)?(?:되|이루어지|완료되)지\\s*(?:않|못)|안\\s*(?:되|됐)|(?:할|하실|받을)\\s*수(?:가)?\\s*없)";
    private static final String MOD = "(?:이|가|은|는)?\\s*(?:(?:처리|요청)(?:이|가)?\\s*)?";
    private static final Pattern FAILED_CANCEL = Pattern.compile("취\\s*소" + MOD + "(?:승인\\s*)?(?:" + VERB + "|" + NEGATIVE + ")");
    private static final Pattern FAILED = Pattern.compile("(?:(?:승인|결제|거래|카드\\s*이용|카드\\s*사용)" + MOD + "(?:" + VERB + "|" + NEGATIVE
            + ")|(?:이용\\s*)?한도(?:가|를)?\\s*(?:초과|부족)" + END + "|잔액(?:이)?\\s*부족" + END + "|미승인" + END + ")");
    private static final Pattern DECLINE_HEADER = Pattern.compile("(?m)^\\s*(?:[\\[(]?(?:하나(?:카드|Pay)?|KB국민카드|NH(?:농협)?카드|신한카드)\\s*[（(]?[0-9*]{4}[）)]?\\s*|[\\[(])(?:거절|실패)" + END);
    private static final Pattern BARE_FAILURE = Pattern.compile("(?m)^\\s*(?:거절|실패|거부|반려)\\s*$");
    private static final Pattern PENDING = Pattern.compile("(?:취\\s*소|승인|결제|거래)(?:가|이)?\\s*(?:예정|접수|신청|처리\\s*중|대기|보류|철회|해제|미완료)" + END);
    // The hybrid debit-card service may explicitly approve a credit purchase after an insufficient debit balance.
    private static final Pattern CREDIT_APPROVED = Pattern.compile("잔액\\s*부족\\s*(?:으로\\s*)?신용\\s*결제\\s*승인(?=$|[\\s\\]]|완료|되었)");
    private static final Pattern PURCHASE_HEADER = Pattern.compile("(?m)^\\s*(?:\\(결제\\)\\s*[0-9]|(?:KB국민카드|NH카드)\\s*[0-9*]{4}\\s*승인(?!(?:\\s)*(?:거절|실패|거부))\\s+|\\[신한카드\\([0-9*]{4}\\)승인\\])");
    private static final Pattern REFUND_HEADER = Pattern.compile("(?m)^\\s*(?:\\(결제취소\\)\\s*[0-9]|(?:KB국민카드|NH카드)\\s*[0-9*]{4}\\s*승인취소(?!(?:\\s)*(?:거절|실패|예정|접수))\\s+|\\[신한카드\\([0-9*]{4}\\)승인취소\\])");

    private static boolean tooLong(String value, int limit) { return value != null && value.length() > limit; }

    // Remove only the merchant field of a complete issuer-shaped alert. Status on a separate
    // line, in another extra or in another notification heading remains visible to classification.
    static String statusFields(CaptureOutbox.Card card, String input) {
        if (input == null) return "";
        String value = input.replace("\r\n", "\n").trim();
        int ref = value.indexOf("\n승인번호");
        String core = ref < 0 ? value : value.substring(0, ref);
        Pattern pattern;
        int group = 7;
        switch (card) {
            case HANA_MOVING: pattern = HanaPushParser.BODY; group = 1; break;
            case KB_COUPANG: pattern = KbPushParser.BODY; break;
            case NH_ZGM: pattern = AdditionalPushParser.NH; break;
            case SHINHAN_KPASS: pattern = AdditionalPushParser.SHINHAN; break;
            default: return value;
        }
        Matcher m = pattern.matcher(core);
        if (!m.matches() || m.group(group).contains("승인번호") || m.group(group).matches(".*[0-9][0-9,]*원.*")) return value;
        // A second event inside the free-text region is ambiguous; preserve its status words.
        String merchant = m.group(group);
        if (merchant.matches("(?:승인|일시불|매출|결제)?취소|환불")
                || merchant.contains(" / ") || merchant.contains(" - ") || merchant.contains("KB국민카드")
                || merchant.contains("NH카드") || merchant.contains("[신한카드")
                || merchant.matches(".+\\s+(?:승인|결제|거래|취소)\\s*(?:거절|실패|불가)[.!]?")) return value;
        return value.substring(0, m.start(group)) + "상점" + value.substring(m.end(group));
    }

    static Kind classify(CaptureOutbox.Card card, String title, String compact, String expanded) {
        if (tooLong(title, 150) || tooLong(compact, 2000) || tooLong(expanded, 2000)) return Kind.CHECK;
        String heading = title == null ? "" : title.trim();
        // Each extra can describe a different result. Do not complete a sentence in one
        // with text from another (e.g. insufficient balance followed by a credit approval).
        String fields = heading + "\n\0\n" + statusFields(card, compact) + "\n\0\n" + statusFields(card, expanded);
        if (AD.matcher(fields).find()) return Kind.ADVERTISEMENT;
        fields = CREDIT_APPROVED.matcher(fields).replaceAll("신용결제 승인");
        boolean refundDeclined = FAILED_CANCEL.matcher(fields).find();
        boolean declined = FAILED.matcher(fields).find() || DECLINE_HEADER.matcher(fields).find()
                || BARE_FAILURE.matcher(fields).find();
        if (PENDING.matcher(fields).find()) return Kind.CHECK;
        if (!refundDeclined && !declined) return Kind.TRANSACTION;
        if (PURCHASE_HEADER.matcher(fields).find() || REFUND_HEADER.matcher(fields).find()) return Kind.CHECK;
        return refundDeclined ? Kind.CANCEL_DECLINED : Kind.DECLINED;
    }

    static synchronized Kind receive(CaptureOutbox.Card card, String title, String compact, String expanded) {
        Kind kind = classify(card, title, compact, expanded);
        if (kind != Kind.ADVERTISEMENT) latest.put(card, kind);
        return kind;
    }

    static synchronized String detail(CaptureOutbox.Card card, String existing) {
        Kind kind = latest.get(card);
        if (kind == null || kind.message.isEmpty()) return existing;
        return existing.isEmpty() ? kind.message : existing + "\n" + kind.message;
    }

    static synchronized void clear(CaptureOutbox.Card card) { latest.remove(card); }
    private PushNotice() {}
}
