package kr.household.hanacollector;

import java.net.URI;

/** Virtual HTTPS origin; every resource is served by native code, never the network. */
final class WelcomeRoute {
    static final String BASE="https://appassets.androidplatform.net/welcome/";
    static String resource(String value){
        try{
            URI uri=new URI(value);
            if(!"https".equals(uri.getScheme())||!"appassets.androidplatform.net".equals(uri.getHost())
                ||uri.getPort()!=-1||uri.getRawUserInfo()!=null||uri.getRawFragment()!=null)return null;
            String path=uri.getRawPath(),query=uri.getRawQuery();
            if(path==null||!path.startsWith("/welcome/"))return null;
            String name=path.substring(9);
            if("index.html".equals(name)){
                if(query!=null&&!query.matches("reduceMotion=[01]&stay=[01]"))return null;
                return name;
            }
            if(query!=null)return null;
            return "welcome.css".equals(name)||"welcome.js".equals(name)||"family-first.jpg".equals(name)||"family-second.jpg".equals(name)?name:null;
        }catch(Exception invalid){return null;}
    }
    static boolean shouldShow(boolean restored,boolean shownInProcess){return !restored||!shownInProcess;}
    private WelcomeRoute(){}
}
