package kr.household.hanacollector;

import java.time.*;
import java.util.regex.*;

/** NH/Shinhan observed shapes only. Enabled only after an issuer-specific key is saved.
 * Cumulative basis is unverified; never treat it as monthly spending or benefit eligibility. */
public final class AdditionalPushParser {
    public enum Issuer { NH, SHINHAN }
    private static final String MONEY="(?:[1-9][0-9]{0,2}(?:,[0-9]{3})+|[1-9][0-9]*|0)";
    private static final Pattern NH=Pattern.compile("^NH카드\\s*([0-9*]{4})\\s*승인\\s+[^\\s]{1,24}\\s+("+MONEY+")원\\s+일시불\\s+(\\d{2})/(\\d{2})\\s+([0-2]\\d):([0-5]\\d)\\s+(.{1,150}?)\\s+총누적\\s*("+MONEY+")원$");
    private static final Pattern SHINHAN=Pattern.compile("^\\[신한카드\\(([0-9*]{4})\\)승인\\]\\s+[^\\s]{1,24}\\s+-\\s*승인금액:\\s*("+MONEY+")원\\(일시불\\)\\s+-\\s*승인일시:\\s*(\\d{2})/(\\d{2})\\s+([0-2]\\d):([0-5]\\d)\\s+-\\s*가맹점명:\\s*(.{1,150}?)\\s+-\\s*누적금액:\\s*("+MONEY+")원\\s+\\[신한카드\\s+\\d{4}-\\d{4}\\]$");
    public static final class Result {
        public final Issuer issuer;public final String cardDisplay;
        public final long amount,occurredAt,cumulative;
        private Result(Issuer issuer,String card,long amount,long occurred,long cumulative){this.issuer=issuer;cardDisplay=card;this.amount=amount;occurredAt=occurred;this.cumulative=cumulative;}
    }
    public static Result fromExtras(Issuer issuer,String text,String bigText,long postedAt){
        Result a=parse(issuer,text,postedAt),b=parse(issuer,bigText,postedAt);
        if(a!=null&&b!=null&&(a.amount!=b.amount||a.cumulative!=b.cumulative||a.occurredAt!=b.occurredAt||!a.cardDisplay.equals(b.cardDisplay)))return null;
        return bigText!=null&&!bigText.trim().isEmpty()?b:a;
    }
    public static Result parse(Issuer issuer,String body,long postedAt){
        if(issuer==null||body==null||body.length()>2000||postedAt<=0)return null;
        Matcher m=(issuer==Issuer.NH?NH:SHINHAN).matcher(body.trim().replaceAll("\\s+"," "));
        if(!m.matches()||m.group(1).equals("****"))return null;
        String merchant=m.group(7);
        if(merchant.contains("승인")||merchant.contains("취소")||merchant.contains("누적")||merchant.contains("NH카드")||merchant.contains("신한카드")||Pattern.compile("[0-9][0-9,]*원").matcher(merchant).find())return null;
        try{
            long amount=Long.parseLong(m.group(2).replace(",","")),cumulative=Long.parseLong(m.group(8).replace(",",""));
            if(amount<1||amount>1000000000L||cumulative<0||cumulative>100000000000L)return null;
            ZoneId zone=ZoneId.of("Asia/Seoul");int year=Instant.ofEpochMilli(postedAt).atZone(zone).getYear();Long occurred=null;
            for(int y=year-1;y<=year+1;y++){
                long time;try{time=LocalDateTime.of(y,Integer.parseInt(m.group(3)),Integer.parseInt(m.group(4)),Integer.parseInt(m.group(5)),Integer.parseInt(m.group(6))).atZone(zone).toInstant().toEpochMilli();}catch(DateTimeException e){continue;}
                if(time>=postedAt-172800000L&&time<=postedAt+300000L){if(occurred!=null)return null;occurred=time;}
            }
            return occurred==null?null:new Result(issuer,m.group(1),amount,occurred,cumulative);
        }catch(RuntimeException e){return null;}
    }
    private AdditionalPushParser(){}
}
