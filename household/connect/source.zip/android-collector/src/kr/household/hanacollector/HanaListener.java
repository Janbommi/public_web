package kr.household.hanacollector;

import android.app.Notification;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public final class HanaListener extends NotificationListenerService {
    static volatile boolean connected=false;
    private static String latest="이번 실행에서 표시할 새 알림은 없습니다. 이전 수신 진단은 아래에서 확인하세요.";
    static volatile boolean diagnosticWriteFailed=false;
    private static long observed=0;
    static synchronized String view() {
        if(observed!=0&&SystemClock.elapsedRealtime()-observed>=15*60*1000){
            latest="상세 표시의 15분 보관 시간이 지났습니다. 내용 없는 수신 진단은 아래에 남아 있습니다.";observed=0;
        }
        return latest;
    }
    static synchronized void clear(){latest="표시할 알림이 없습니다. 내용 없는 수신 진단은 아래에서 확인하세요.";observed=0;}
    @Override public void onListenerConnected(){connected=true;DiagnosticSync.request(this,false);KbCaptureRuntime.request(this,false);NhCaptureRuntime.request(this,false);ShinhanCaptureRuntime.request(this,false);}
    @Override public void onListenerDisconnected(){connected=false;clear();DiagnosticSync.request(this,false);}
    @Override public void onNotificationPosted(StatusBarNotification sbn){
        if(sbn!=null&&KbTransport.PACKAGE.equals(sbn.getPackageName())){
            // No KB content inspection until a KB key has been explicitly saved on this phone.
            if(!KbCaptureRuntime.hasKey(this))return;
            Notification kb=sbn.getNotification();
            if(kb==null||kb.extras==null||(kb.flags&Notification.FLAG_GROUP_SUMMARY)!=0||sbn.isOngoing())return;
            CharSequence text=kb.extras.getCharSequence(Notification.EXTRA_TEXT),big=kb.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
            KbPushParser.Result parsed=KbPushParser.fromExtras(text==null?null:text.toString(),big==null?null:big.toString(),sbn.getPostTime());
            if(parsed!=null)KbCaptureRuntime.observed(this,parsed,sbn.getKey(),sbn.getPostTime());
            else KbCaptureRuntime.unsupported();
            return;
        }
        if(sbn!=null&&NhTransport.PACKAGE.equals(sbn.getPackageName())){
            // No NH content inspection until a NH key has been explicitly saved on this phone.
            if(!NhCaptureRuntime.hasKey(this))return;
            Notification kb=sbn.getNotification();
            if(kb==null||kb.extras==null||(kb.flags&Notification.FLAG_GROUP_SUMMARY)!=0||sbn.isOngoing())return;
            CharSequence text=kb.extras.getCharSequence(Notification.EXTRA_TEXT),big=kb.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
            AdditionalPushParser.Result parsed=AdditionalPushParser.fromExtras(AdditionalPushParser.Issuer.NH,text==null?null:text.toString(),big==null?null:big.toString(),sbn.getPostTime());
            if(parsed!=null)NhCaptureRuntime.observed(this,parsed,sbn.getKey(),sbn.getPostTime());
            else NhCaptureRuntime.unsupported();
            return;
        }
        if(sbn!=null&&ShinhanTransport.PACKAGE.equals(sbn.getPackageName())){
            // No 신한 content inspection until a 신한 key has been explicitly saved on this phone.
            if(!ShinhanCaptureRuntime.hasKey(this))return;
            Notification kb=sbn.getNotification();
            if(kb==null||kb.extras==null||(kb.flags&Notification.FLAG_GROUP_SUMMARY)!=0||sbn.isOngoing())return;
            CharSequence text=kb.extras.getCharSequence(Notification.EXTRA_TEXT),big=kb.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
            AdditionalPushParser.Result parsed=AdditionalPushParser.fromExtras(AdditionalPushParser.Issuer.SHINHAN,text==null?null:text.toString(),big==null?null:big.toString(),sbn.getPostTime());
            if(parsed!=null)ShinhanCaptureRuntime.observed(this,parsed,sbn.getKey(),sbn.getPostTime());
            else ShinhanCaptureRuntime.unsupported();
            return;
        }
        // Reject other applications BEFORE inspecting their notification extras.
        if(sbn==null||!CapturePolicy.HANA_PACKAGE.equals(sbn.getPackageName()))return;
        Notification n=sbn.getNotification();
        if(n==null||n.extras==null)return;
        if(!CapturePolicy.accepts(sbn.getPackageName(),(n.flags&Notification.FLAG_GROUP_SUMMARY)!=0,sbn.isOngoing()))return;
        CharSequence title=n.extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence body=n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if(body==null||body.length()==0)body=n.extras.getCharSequence(Notification.EXTRA_TEXT);
        String t=title==null?"":title.toString(),b=body==null?"":body.toString();
        if(t.length()+b.length()>20000)return;
        synchronized(HanaListener.class){
            observed=SystemClock.elapsedRealtime();
            HanaPushParser.Result parsed=HanaPushParser.parse(t,b,sbn.getPostTime());
            if(parsed!=null)CaptureRuntime.observed(this,parsed,sbn.getKey(),sbn.getPostTime());
            latest=parsed==null?"지원하지 않거나 내용이 가려진 알림입니다. 원문은 보관하지 않습니다. 취소·할부·다른 형식은 별도 확인이 필요합니다.":parsed.localDisplay();
            try{DiagnosticStore.capture(this,t,b,parsed!=null);diagnosticWriteFailed=false;}
            catch(RuntimeException e){diagnosticWriteFailed=true;}
        }
        if(!diagnosticWriteFailed)DiagnosticSync.request(this,false);
        // Only a deferred content-free snapshot is uploaded. No raw-content storage.
    }
}
