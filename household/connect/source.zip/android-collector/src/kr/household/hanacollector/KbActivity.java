package kr.household.hanacollector;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;

/** KB opt-in settings. No account password, raw notification, or merchant input. */
public final class KbActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private TextView status,confirmation,counts,listener;private EditText key;private Button confirm,probe,save;
    private boolean visible;private int generation;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xfff3f5f7);
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);int pad=dp(20);box.setPadding(pad,pad,pad,pad);scroll.addView(box);setContentView(scroll);
        box.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets bars=i.getInsets(WindowInsets.Type.systemBars());v.setPadding(pad,pad+bars.top,pad,pad+bars.bottom);return i;});
        button(box,"← 홈",v->finish());
        text(box,"KB 쿠팡 와우",27);text(box,"승인액과 누적액을 함께",14);
        LinearLayout hero=card(box);counts=text(hero,"확인 중…",24);listener=text(hero,"",13);confirmation=text(hero,"",14);
        confirm=button(hero,"본인 카드 확인하고 시작",v->{try{
            final String id,message;synchronized(KbCaptureRuntime.class){id=KbCaptureRuntime.candidateId(this);message=KbCaptureRuntime.confirmText(this);}
            new AlertDialog.Builder(this).setTitle("내 KB 쿠팡 와우 결제인가요?").setMessage(message+"\n확인하면 이 건부터 승인액·시각·누적액을 우리 집 서버에 보냅니다.")
                .setNegativeButton("아직 확인 안 함",null).setPositiveButton("맞아요 · 시작",(d,w)->{try{KbCaptureRuntime.confirm(this,id);status.setText("KB 자동 집계를 시작했어요.");}catch(Exception e){status.setText("새 알림으로 바뀌었거나 저장하지 못했어요. 다시 확인해 주세요.");}refresh();}).show();
        }catch(Exception e){status.setText("KB 키를 연결한 뒤 새 KB Pay 일시불 알림을 기다려 주세요.");}});
        button(box,"우리 집 현황판 ↗",v->open("https://janbommi.github.io/public_web/household/budget/"));
        status=text(box,"",14);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        LinearLayout settings=fold(box,"KB 연결 설정",!KbCaptureRuntime.hasKey(this));
        text(settings,"KB 키를 저장하면 KB Pay 알림에서 승인액·누적액·시각·카드 표시를 폰에 암호화 보관합니다. 본인 카드 확인 후 승인액·누적액·시각·재전송 ID를 우리 집 서버에 보내요. 원문·이름·가맹점·카드 표시는 전송하지 않습니다.",14);
        button(settings,"1. 웹에서 KB 연결 키 만들기 ↗",v->open("https://janbommi.github.io/public_web/household/kb/"));
        key=new EditText(this);key.setSingleLine(true);key.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);key.setHint("KB 전용 연결 키 붙여넣기");key.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);key.setSaveEnabled(false);settings.addView(key);
        save=button(settings,"2. 동의하고 KB 키 연결",v->connectKey());
        probe=button(settings,"서버 연결 확인",v->probe());
        button(settings,"알림 접근 설정",v->{try{startActivity(new Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));}catch(Exception e){status.setText("휴대폰 설정에서 알림 접근을 확인해 주세요.");}});
        text(settings,"하나 연결 키와 설정은 그대로 유지됩니다. 알림 접근은 Android에서 넓게 허용하는 권한이며 앱은 하나Pay와 별도 연결한 KB Pay·NH pay·신한 SOL페이만 처리합니다.",13);
        LinearLayout manage=fold(box,"수집 관리",false);
        button(manage,"KB 자동 집계 잠시 끄기",v->{try{KbCaptureRuntime.enabled(this,false);status.setText("KB 새 결제 저장·전송을 멈췄어요.");}catch(Exception e){status.setText("먼저 본인 카드 확인이 필요해요.");}refresh();});
        button(manage,"KB 재개 / 전송 다시 시도",v->{try{KbCaptureRuntime.enabled(this,true);KbCaptureRuntime.request(this,true);status.setText("KB 전송을 다시 예약했어요.");}catch(Exception e){status.setText("먼저 본인 카드 확인이 필요해요.");}refresh();});
        button(manage,"폰의 KB 연결 키 삭제",v->new AlertDialog.Builder(this).setTitle("KB 키를 삭제할까요?").setMessage("이 폰의 KB 전송을 멈춥니다. 서버 권한은 웹의 KB 연결 해제에서 폐기해 주세요. 하나 연결은 유지됩니다.").setNegativeButton("유지",null).setPositiveButton("삭제",(d,w)->{generation++;try{KbTokenVault.clear(this);KbCaptureRuntime.keyChanged(this);status.setText("KB 키를 삭제했어요. 웹에서도 KB 연결을 해제해 주세요.");}catch(Exception e){status.setText("삭제를 확인하지 못했어요. 웹에서 KB 연결을 해제해 주세요.");}refresh();}).show());
        LinearLayout guide=fold(box,"안내사항",false);
        text(guide,"다음 평소 결제 후 이 화면에서 본인 카드를 확인해 주세요. 시작 전 결제·취소·할부·해외는 미포함입니다. 카드사 누적액은 이번 달 지출과 다른 참고값이며 예산에 다시 더하지 않습니다.",14);
        text(guide,"인터넷·절전 상태에 따라 전송이 늦어질 수 있어요. 전송 대기 중에는 앱이나 데이터를 삭제하지 마세요. 동일 알림은 재전송해도 한 번만 반영하며 애매한 중복은 확인 필요로 남깁니다.",14);
        text(guide,"0.7에서 보고된 설치 보안 경고의 해소 여부는 확인되지 않았습니다. 설치가 차단되면 보호 기능을 끄거나 우회하지 마세요.",14);
        text(box,"버전 0.91 · KB 연결",12);
    }
    private void open(String url){startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(LinearLayout parent,String value,int size){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(0xff17333b);v.setPadding(0,dp(8),0,dp(8));parent.addView(v);return v;}
    private android.graphics.drawable.GradientDrawable background(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));return d;}
    private Button button(LinearLayout parent,String label,View.OnClickListener action){Button b=new Button(this);b.setText(label);b.setTextSize(15);b.setAllCaps(false);b.setTextColor(0xffffffff);b.setBackgroundTintList(null);b.setBackground(background(0xff087e80));b.setMinHeight(dp(50));b.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));parent.addView(b,p);b.setOnClickListener(action);return b;}
    private LinearLayout card(LinearLayout parent){LinearLayout b=new LinearLayout(this);b.setOrientation(1);b.setPadding(dp(18),dp(14),dp(18),dp(14));b.setBackground(background(0xffffffff));parent.addView(b,new LinearLayout.LayoutParams(-1,-2));return b;}
    private LinearLayout fold(LinearLayout parent,String label,boolean open){LinearLayout content=new LinearLayout(this);content.setOrientation(1);Button toggle=button(parent,label+(open?" −":" ＋"),v->{});parent.addView(content);content.setVisibility(open?View.VISIBLE:View.GONE);toggle.setOnClickListener(v->{boolean show=content.getVisibility()!=View.VISIBLE;content.setVisibility(show?View.VISIBLE:View.GONE);toggle.setText(label+(show?" −":" ＋"));});return content;}
    private void refresh(){counts.setText(KbCaptureRuntime.status(this));confirmation.setText(KbCaptureRuntime.confirmText(this));listener.setText(HanaListener.connected?"알림 서비스 연결됨":"알림 접근 연결 확인 필요");confirm.setVisibility(KbCaptureRuntime.confirmed(this)?View.GONE:View.VISIBLE);}
    private final Runnable tick=new Runnable(){public void run(){if(!visible)return;refresh();main.postDelayed(this,1500);}};
    private void connectKey(){final String candidate=key.getText().toString().trim();key.setText("");if(!CapturePolicy.tokenValid(candidate)){status.setText("64자리 KB 전용 키를 확인해 주세요.");return;}
        try{String old=KbTokenVault.load(this);if(old!=null&&!old.equals(candidate)){new AlertDialog.Builder(this).setTitle("KB 연결 키를 교체할까요?").setMessage("이전 키의 전송 대기는 새 키로 옮기지 않습니다. 대기 건수가 있다면 취소하고 먼저 전송해 주세요.").setNegativeButton("취소",null).setPositiveButton("교체",(d,w)->check(candidate,true)).show();return;}}catch(Exception e){status.setText("기존 KB 키를 읽지 못했어요. 앱 데이터를 삭제하지 말고 알려주세요.");return;}check(candidate,true);
    }
    private void probe(){try{String token=KbTokenVault.load(this);if(token==null)throw new IllegalStateException();check(token,false);}catch(Exception e){status.setText("KB 연결 키를 먼저 저장해 주세요.");}}
    private void check(String token,boolean store){final int current=++generation;save.setEnabled(false);probe.setEnabled(false);status.setText("KB 서버 확인 중…");new Thread(()->{
        String result;boolean success=false;HttpsURLConnection c=null;
        try{c=(HttpsURLConnection)new URL(KbTransport.ENDPOINT).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Cache-Control","no-store");byte[] payload=CapturePolicy.PROBE_BODY.getBytes(java.nio.charset.StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(payload.length);c.setDoOutput(true);try(java.io.OutputStream out=c.getOutputStream()){out.write(payload);}if(c.getResponseCode()!=200)throw new IllegalStateException();
            java.io.ByteArrayOutputStream body=new java.io.ByteArrayOutputStream();try(java.io.InputStream in=c.getInputStream()){byte[] bytes=new byte[256];int n;while((n=in.read(bytes))!=-1){body.write(bytes,0,n);if(body.size()>2048)throw new IllegalStateException();}}
            org.json.JSONObject reply=new org.json.JSONObject(new String(body.toByteArray(),java.nio.charset.StandardCharsets.UTF_8));if(!"connected".equals(reply.optString("status"))||!"kb".equals(reply.optString("card")))throw new IllegalStateException();success=true;result="KB 서버 연결 성공 · 다음 새 알림을 기다려 주세요.";
        }catch(Exception e){result="연결하지 못했어요. 인터넷과 웹의 KB 전용 키를 확인해 주세요. 기존 키는 유지됩니다.";}finally{if(c!=null)c.disconnect();}
        final boolean accepted=success;final String message=result;main.post(()->{if(current!=generation||!visible)return;save.setEnabled(true);probe.setEnabled(true);try{if(accepted&&store){KbTokenVault.save(this,token);KbCaptureRuntime.keyChanged(this);KbCaptureRuntime.request(this,false);}status.setText(message);}catch(Exception e){status.setText("KB 키를 저장하지 못했어요. 다시 연결해 주세요.");}refresh();});
    },"kb-probe").start();}
    @Override protected void onResume(){super.onResume();visible=true;save.setEnabled(true);probe.setEnabled(true);KbCaptureRuntime.request(this,false);tick.run();}
    @Override protected void onPause(){visible=false;generation++;main.removeCallbacks(tick);key.setText("");counts.setText("");confirmation.setText("");super.onPause();}
}
