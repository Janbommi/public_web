package kr.household.hanacollector;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;

/** 신한 opt-in settings. No account password, raw notification, or merchant input. */
public final class ShinhanActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private TextView status,confirmation,counts,listener;private EditText key;private Button confirm,probe,save;
    private CardUi.Summary summary;
    private boolean visible;private int generation;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xfff7f3eb);
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);int pad=dp(20);box.setPadding(pad,pad,pad,pad);scroll.addView(box);setContentView(scroll);
        box.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets bars=i.getInsets(WindowInsets.Type.systemBars());v.setPadding(pad,pad+bars.top,pad,pad+bars.bottom);return i;});
        button(box,"← 홈",v->finish());
        CardUi.heading(box,"신한 K-패스",24);
        summary=new CardUi.Summary(box);LinearLayout hero=summary.actions;listener=text(hero,"",14);confirmation=text(hero,"",14);
        confirm=button(hero,"본인 카드 확인하고 시작",v->{try{
            final String id,message;synchronized(ShinhanCaptureRuntime.class){id=ShinhanCaptureRuntime.candidateId(this);message=ShinhanCaptureRuntime.confirmText(this);}
            new AlertDialog.Builder(this).setTitle("내 신한 K-패스 결제인가요?").setMessage(message+"\n확인하면 이 건부터 월 사용액 집계를 시작합니다. 집계에 필요한 승인 금액과 시각을 전송하며, 서버에는 월 합계와 중복 방지 정보만 새로 저장합니다.")
                .setNegativeButton("아직 확인 안 함",null).setPositiveButton("맞아요 · 시작",(d,w)->{try{ShinhanCaptureRuntime.confirm(this,id);status.setText("신한 자동 집계를 시작했어요.");}catch(Exception e){status.setText("새 알림으로 바뀌었거나 저장하지 못했어요. 다시 확인해 주세요.");}refresh();}).show();
        }catch(Exception e){status.setText("신한 키를 연결한 뒤 새 신한 SOL페이 일시불 알림을 기다려 주세요.");}});
        CardUi.style(confirm,true,false);
        status=text(box,"",14);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        LinearLayout settings=fold(box,"신한 연결 설정",!ShinhanCaptureRuntime.hasKey(this));
        text(settings,"본인 카드 확인 후 지원 알림의 사용액을 월별로 합산합니다. 서버에 개별 결제 내역을 새로 저장하지 않으며, 원문·이름·가맹점·카드 표시는 보내지 않습니다. 전송 대기 자료는 폰에 암호화 보관합니다.",14);
        button(settings,"기기 연결 · 초대",v->startActivity(new Intent(this,EnrollmentActivity.class)));
        key=new EditText(this);key.setSingleLine(true);key.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);key.setHint("신한 전용 연결 키 붙여넣기");key.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);key.setSaveEnabled(false);key.setContentDescription("신한 전용 연결 키");key.setVisibility(View.GONE);
        save=new Button(this);
        probe=button(settings,"서버 연결 확인",v->probe());
        button(settings,"알림 접근 설정",v->{try{startActivity(new Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));}catch(Exception e){status.setText("휴대폰 설정에서 알림 접근을 확인해 주세요.");}});
        text(settings,"기존 카드 설정은 유지됩니다. Android 알림 접근을 허용하면 지원 카드사의 알림만 처리합니다.",13);
        LinearLayout manage=fold(box,"수집 관리",false);
        button(manage,"신한 자동 집계 잠시 끄기",v->{try{ShinhanCaptureRuntime.enabled(this,false);status.setText("신한 새 결제 저장·전송을 멈췄어요.");}catch(Exception e){status.setText("먼저 본인 카드 확인이 필요해요.");}refresh();});
        button(manage,"신한 재개 / 전송 다시 시도",v->{try{ShinhanCaptureRuntime.enabled(this,true);ShinhanCaptureRuntime.request(this,true);status.setText("신한 전송을 다시 예약했어요.");}catch(Exception e){status.setText("먼저 본인 카드 확인이 필요해요.");}refresh();});
        button(manage,"기기 연결 관리",v->startActivity(new Intent(this,EnrollmentActivity.class)));
        LinearLayout guide=fold(box,"안내사항",false);
        text(guide,"다음 국내 일시불 결제 후 본인 카드를 확인해 주세요. 취소가 수집된 원결제와 연결되면 원결제 월에서 차감해요. 확인 필요로 표시되면 그달 사용액을 확인하세요. 카드사 누적액은 참고용이에요.",14);
        text(guide,"인터넷·절전 상태에 따라 전송이 늦어질 수 있어요. 전송 대기 중에는 앱이나 데이터를 삭제하지 마세요. 동일 알림은 재전송해도 한 번만 반영하며 애매한 중복은 확인 필요로 남깁니다.",14);
        button(box,"해외 결제·취소 보완",v->startActivity(new android.content.Intent(this,CorrectionActivity.class).putExtra("card","shinhan")));
        text(box,"버전 1.03 · 신한 연결",12);
    }
    private void open(String url){startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(LinearLayout parent,String value,int size){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(0xff17333b);v.setPadding(0,dp(8),0,dp(8));parent.addView(v);return v;}
    private android.graphics.drawable.GradientDrawable background(int color){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(16));return d;}
    private Button button(LinearLayout p,String value,View.OnClickListener action){return CardUi.button(p,value,action);}
    private LinearLayout card(LinearLayout p){return CardUi.card(p);}
    private LinearLayout fold(LinearLayout p,String name,boolean open){return CardUi.fold(p,name,open);}
    private void refresh(){CardUiState state=ShinhanCaptureRuntime.uiState(this);summary.show(state);CardUi.changed(confirmation,state.canConfirm?ShinhanCaptureRuntime.confirmText(this):"");confirmation.setVisibility(state.canConfirm?View.VISIBLE:View.GONE);CardUi.changed(listener,HanaListener.connected?"알림 서비스 연결됨":"알림 접근 연결 확인 필요");confirm.setVisibility(state.canConfirm?View.VISIBLE:View.GONE);}
    private final Runnable tick=new Runnable(){public void run(){if(!visible)return;refresh();main.postDelayed(this,1500);}};
    private void connectKey(){final String candidate=key.getText().toString().trim();key.setText("");if(!CapturePolicy.tokenValid(candidate)){status.setText("64자리 신한 전용 키를 확인해 주세요.");return;}
        try{String old=ShinhanTokenVault.load(this);if(old!=null&&!old.equals(candidate)){new AlertDialog.Builder(this).setTitle("신한 연결 키를 교체할까요?").setMessage("이전 키의 전송 대기는 새 키로 옮기지 않습니다. 대기 건수가 있다면 취소하고 먼저 전송해 주세요.").setNegativeButton("취소",null).setPositiveButton("교체",(d,w)->check(candidate,true)).show();return;}}catch(Exception e){status.setText("기존 신한 키를 읽지 못했어요. 앱 데이터를 삭제하지 말고 알려주세요.");return;}check(candidate,true);
    }
    private void probe(){try{String token=ShinhanTokenVault.load(this);if(token==null)throw new IllegalStateException();check(token,false);}catch(Exception e){status.setText("신한 홈에서 기기 연결을 진행해 주세요.");}}
    private void check(String token,boolean store){final int current=++generation;save.setEnabled(false);probe.setEnabled(false);status.setText("신한 서버 확인 중…");new Thread(()->{
        String result;boolean success=false;HttpsURLConnection c=null;
        try{c=(HttpsURLConnection)new URL(ShinhanTransport.ENDPOINT).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Cache-Control","no-store");byte[] payload=CapturePolicy.PROBE_BODY.getBytes(java.nio.charset.StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(payload.length);c.setDoOutput(true);try(java.io.OutputStream out=c.getOutputStream()){out.write(payload);}if(c.getResponseCode()!=200)throw new IllegalStateException();
            java.io.ByteArrayOutputStream body=new java.io.ByteArrayOutputStream();try(java.io.InputStream in=c.getInputStream()){byte[] bytes=new byte[256];int n;while((n=in.read(bytes))!=-1){body.write(bytes,0,n);if(body.size()>2048)throw new IllegalStateException();}}
            org.json.JSONObject reply=new org.json.JSONObject(new String(body.toByteArray(),java.nio.charset.StandardCharsets.UTF_8));if(!"connected".equals(reply.optString("status"))||!"shinhan".equals(reply.optString("card")))throw new IllegalStateException();success=true;result="신한 서버 연결 성공 · 다음 새 알림을 기다려 주세요.";
        }catch(Exception e){result="연결하지 못했어요. 인터넷과 기기 연결 상태를 확인해 주세요. 기존 연결은 유지됩니다.";}finally{if(c!=null)c.disconnect();}
        final boolean accepted=success;final String message=result;main.post(()->{if(current!=generation||!visible)return;save.setEnabled(true);probe.setEnabled(true);try{if(accepted&&store){ShinhanTokenVault.save(this,token);ShinhanCaptureRuntime.keyChanged(this);ShinhanCaptureRuntime.request(this,false);}status.setText(message);}catch(Exception e){status.setText("신한 키를 저장하지 못했어요. 다시 연결해 주세요.");}refresh();});
    },"shinhan-probe").start();}
    @Override protected void onResume(){super.onResume();visible=true;save.setEnabled(true);probe.setEnabled(true);ShinhanCaptureRuntime.request(this,false);tick.run();}
    @Override protected void onPause(){visible=false;generation++;main.removeCallbacks(tick);key.setText("");confirmation.setText("");super.onPause();}
}
