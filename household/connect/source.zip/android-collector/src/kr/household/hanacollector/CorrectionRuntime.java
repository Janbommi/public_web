package kr.household.hanacollector;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import org.json.JSONObject;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.UUID;
import javax.crypto.*;
import javax.net.ssl.HttpsURLConnection;

/** One encrypted pending correction per card. Never invent a new ID after response loss. */
final class CorrectionRuntime {
    private static final Object KEY_LOCK=new Object();
    private static final String ENDPOINT="https://xcchskngoactqsiiutsp.supabase.co/functions/v1/collector-correction";
    static String title(String card){switch(card){case "hana":return "하나 MOVING ONLINE";case "kb":return "KB 쿠팡 와우";case "nh":return "NH zgm 할인";case "shinhan":return "신한 K-패스";default:throw new IllegalArgumentException("지원하지 않는 카드입니다.");}}
    private static String token(Context c,String card)throws Exception{title(card);String t=card.equals("hana")?TokenVault.load(c):card.equals("kb")?KbTokenVault.load(c):card.equals("nh")?NhTokenVault.load(c):ShinhanTokenVault.load(c);if(t==null)throw new IOException("먼저 기기 연결과 본인 카드 확인을 완료해 주세요.");return t;}
    private static SecretKey key()throws Exception{synchronized(KEY_LOCK){
        String alias="household-monthly-correction";KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(!ks.containsAlias(alias)){KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}
        return (SecretKey)ks.getKey(alias,null);
    }}
    private static String digest(String value)throws Exception{StringBuilder b=new StringBuilder();for(byte v:MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)))b.append(String.format("%02x",v&255));return b.toString();}
    private static EncryptedOutboxStore store(Context c,String card,String token)throws Exception{return new EncryptedOutboxStore(new File(c.getNoBackupFilesDir(),"correction-"+card+"-"+digest(token)+".bin").toPath(),key());}
    private static JSONObject read(EncryptedOutboxStore s)throws Exception{byte[] bytes=s.read();return bytes==null?new JSONObject():new JSONObject(new String(bytes,StandardCharsets.UTF_8));}
    private static void save(EncryptedOutboxStore s,JSONObject value)throws Exception{s.commit(value.toString().getBytes(StandardCharsets.UTF_8));}
    static boolean pending(Context c,String card)throws Exception{String t=token(c,card);return read(store(c,card,t)).has("pending");}
    static String pendingText(Context c,String card)throws Exception{
        String t=token(c,card);JSONObject state=read(store(c,card,t)),p=state.optJSONObject("pending");
        if(p!=null)return p.getString("month")+" · "+(p.getString("kind").equals("cancellation")?"취소 -":"해외 +")+p.getLong("amount")+"원\n반영 여부를 확인할 때까지 새 정정을 보낼 수 없어요.";
        return state.optString("message","");
    }
    static synchronized JSONObject snapshot(Context c,String card,String month)throws Exception{
        String t=token(c,card);if(read(store(c,card,t)).has("pending"))throw new IOException("이전 정정의 반영 여부부터 확인해 주세요.");
        return request(t,new JSONObject().put("op","snapshot").put("month",month)).put("credentialBinding",digest(t));
    }
    static synchronized String apply(Context c,String card,String month,String kind,long amount,JSONObject base)throws Exception{
        String t=token(c,card);EncryptedOutboxStore s=store(c,card,t);JSONObject state=read(s);
        if(!digest(t).equals(base.optString("credentialBinding")))throw new IOException("카드 연결이 바뀌었어요. 합계를 다시 확인해 주세요.");
        if(state.has("pending"))throw new IOException("이전 정정의 반영 여부부터 확인해 주세요.");
        if(!month.equals(base.getString("month")))throw new IOException("대상 월을 다시 확인해 주세요.");
        JSONObject p=new JSONObject().put("op","apply").put("id",UUID.randomUUID().toString()).put("month",month).put("kind",kind).put("amount",amount).put("baseRevision",base.getLong("revision")).put("baseAmount",base.getLong("amount")).put("confirmed",true);
        state.put("pending",p);state.remove("message");save(s,state); // Durable before HTTP.
        return sendPending(t,s,state);
    }
    static synchronized String recover(Context c,String card)throws Exception{
        String t=token(c,card);EncryptedOutboxStore s=store(c,card,t);JSONObject state=read(s);
        if(!state.has("pending"))return state.optString("message","확인할 정정이 없어요.");
        return sendPending(t,s,state);
    }
    private static String sendPending(String token,EncryptedOutboxStore s,JSONObject state)throws Exception{
        JSONObject p=state.getJSONObject("pending");
        try{
            JSONObject response=request(token,p);String status=response.optString("status");
            if(!status.equals("accepted")&&!status.equals("duplicate"))throw new IOException("서버 응답을 확인하지 못했어요. 같은 요청으로 다시 확인해 주세요.");
            String message=p.getString("month")+" 합계에 반영했어요.\n현재 합계: "+response.getLong("amount")+"원";
            state.remove("pending");state.put("message",message);save(s,state);return message;
        }catch(ServerError e){
            if(e.code.equals("monthly_changed")||e.code.equals("invalid_correction")){
                state.remove("pending");state.put("message",e.getMessage());save(s,state);
            }
            throw e;
        }
    }
    static final class ServerError extends IOException{final String code;ServerError(String code,String message){super(message);this.code=code;}}
    private static JSONObject request(String token,JSONObject body)throws Exception{
        HttpsURLConnection c=(HttpsURLConnection)new URL(ENDPOINT).openConnection();
        try{
            c.setRequestMethod("POST");c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(false);c.setDoOutput(true);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Content-Type","application/json");
            byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}
            int status=c.getResponseCode();InputStream in=status==200?c.getInputStream():c.getErrorStream();
            if(in==null)throw new IOException("연결 결과를 확인하지 못했어요. 다시 확인해 주세요.");
            ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream input=in){byte[] buffer=new byte[512];int n;while((n=input.read(buffer))!=-1){if(out.size()+n>4096)throw new IOException("서버 응답을 확인하지 못했어요.");out.write(buffer,0,n);}}
            JSONObject r=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
            if(status!=200){String code=r.optString("error");throw new ServerError(code,code.equals("monthly_changed")?"새 결제나 정정으로 합계가 바뀌었어요. 최신 합계를 다시 확인해 주세요.":code.equals("invalid_correction")?"금액·대상 월을 확인해 주세요. 합계보다 큰 취소액은 반영할 수 없어요.":code.equals("card_confirmation_required")?"먼저 본인 카드 확인을 완료해 주세요.":code.equals("device_unavailable")?"기기 연결 상태를 확인해 주세요. 대기 요청은 보존했어요.":code.equals("request_conflict")?"이전 요청과 충돌했어요. 새 정정을 만들지 말고 문의해 주세요.":"연결 결과를 확인하지 못했어요. 같은 요청으로 다시 확인해 주세요.");}
            return r;
        }finally{c.disconnect();}
    }
    private CorrectionRuntime(){}
}
