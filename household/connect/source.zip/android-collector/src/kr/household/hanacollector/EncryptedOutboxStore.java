package kr.household.hanacollector;

import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** One private file per collector. Android integration supplies a Keystore AES key.
 * Never falls back to plaintext or replaces an unreadable queue with an empty one.
 */
public final class EncryptedOutboxStore implements CaptureOutbox.Store {
    private static final byte[] AAD="kr.household.hanacollector.outbox.v1".getBytes(StandardCharsets.UTF_8);
    private final Path file;private final SecretKey key;
    public EncryptedOutboxStore(Path file,SecretKey key){this.file=file;this.key=key;}
    @Override public synchronized byte[] read()throws IOException {
        if(Files.notExists(file))return null;
        if(Files.size(file)>1024*1024+64)throw new IOException("Encrypted capture storage too large");
        byte[] bytes=Files.readAllBytes(file);
        if(bytes.length<29||bytes[0]!=1)throw new IOException("Invalid encrypted capture format");
        try{
            byte[] iv=new byte[12];System.arraycopy(bytes,1,iv,0,12);
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv));c.updateAAD(AAD);
            return c.doFinal(bytes,13,bytes.length-13);
        }catch(GeneralSecurityException e){throw new IOException("Capture storage cannot be authenticated");}
    }
    @Override public synchronized void commit(byte[] value)throws IOException {
        if(value==null||value.length>1024*1024)throw new IOException("Invalid capture storage size");
        byte[] bytes;
        try{
            // Let the provider generate the IV (required for randomized Android Keystore keys).
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key);c.updateAAD(AAD);
            byte[] cipher=c.doFinal(value),iv=c.getIV();if(iv.length!=12)throw new IOException("Unsupported IV");
            bytes=new byte[13+cipher.length];bytes[0]=1;System.arraycopy(iv,0,bytes,1,12);System.arraycopy(cipher,0,bytes,13,cipher.length);
        }catch(GeneralSecurityException e){throw new IOException("Capture encryption unavailable");}
        Path pending=Files.createTempFile(file.toAbsolutePath().getParent(),"capture-",".pending");
        try{
            try(FileChannel channel=FileChannel.open(pending,StandardOpenOption.WRITE)){
                ByteBuffer buffer=ByteBuffer.wrap(bytes);while(buffer.hasRemaining())channel.write(buffer);channel.force(true);
            }
            Files.move(pending,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
        }finally{Files.deleteIfExists(pending);}
    }
}
