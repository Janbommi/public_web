package kr.household.hanacollector;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Fixed photo allowlist. Credentials stay native; encrypted cache is excluded from backup. */
final class WelcomeAssets {
    private static final int LIMIT=2*1024*1024;
    private static final String ALIAS="household-welcome-photos";
    private static final String BASE="https://xcchskngoactqsiiutsp.supabase.co/functions/v1/family-welcome/";
    private static SecretKey key()throws Exception{
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(!store.containsAlias(ALIAS)){
            KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();
        }
        return (SecretKey)store.getKey(ALIAS,null);
    }
    private static String token(Context c,int which)throws Exception{
        switch(which){case 0:return TokenVault.load(c);case 1:return KbTokenVault.load(c);case 2:return NhTokenVault.load(c);default:return ShinhanTokenVault.load(c);}
    }
    private static byte[] read(InputStream in,int limit)throws IOException{
        try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1){if(out.size()+n>limit)throw new IOException();out.write(buffer,0,n);}return out.toByteArray();
        }
    }
    private static boolean jpeg(byte[] b){return b.length>3&&(b[0]&255)==255&&(b[1]&255)==216;}
    static synchronized byte[] load(Context c,String name){
        if(!name.equals("family-first.jpg")&&!name.equals("family-second.jpg"))return null;
        // Only explicitly private test builds can contain bundled photos.
        try{return read(c.getAssets().open("welcome/"+name),LIMIT);}catch(Exception absent){}
        File file=new File(c.getNoBackupFilesDir(),"welcome-"+name+".enc");
        for(int i=0;i<4;i++)try{
            String token=token(c,i);if(!CapturePolicy.tokenValid(token))continue;
            byte[] aad=(name+":"+token).getBytes("UTF-8");
            // Cached access lasts at most 24 hours, then server authorization is required again.
            if(file.isFile()&&System.currentTimeMillis()>=file.lastModified()&&System.currentTimeMillis()-file.lastModified()<86400000L)try{
                byte[] saved=read(new FileInputStream(file),LIMIT+64);
                if(saved.length>28){Cipher decrypt=Cipher.getInstance("AES/GCM/NoPadding");decrypt.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,saved,0,12));decrypt.updateAAD(aad);
                    byte[] plain=decrypt.doFinal(saved,12,saved.length-12);if(jpeg(plain))return plain;}
            }catch(Exception invalidCache){}
            HttpsURLConnection connection=(HttpsURLConnection)new URL(BASE+name).openConnection();
            byte[] bytes;
            try{
                connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(4000);connection.setReadTimeout(4000);
                connection.setUseCaches(false);connection.setRequestProperty("Authorization","Bearer "+token);
                int code=connection.getResponseCode();
                if(code==401){new AtomicFile(file).delete();continue;}
                if(code!=200||connection.getContentLengthLong()>LIMIT||!"image/jpeg".equals(connection.getContentType()))return null;
                bytes=read(connection.getInputStream(),LIMIT);if(!jpeg(bytes))return null;
            }finally{connection.disconnect();}
            Cipher encrypt=Cipher.getInstance("AES/GCM/NoPadding");encrypt.init(Cipher.ENCRYPT_MODE,key());encrypt.updateAAD(aad);
            AtomicFile target=new AtomicFile(file);FileOutputStream out=null;
            try{out=target.startWrite();out.write(encrypt.getIV());out.write(encrypt.doFinal(bytes));target.finishWrite(out);}
            catch(Exception failure){if(out!=null)target.failWrite(out);}
            return bytes;
        }catch(Exception unavailable){}
        return null;
    }
    private WelcomeAssets(){}
}
