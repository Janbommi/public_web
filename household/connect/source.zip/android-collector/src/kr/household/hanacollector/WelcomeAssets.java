package kr.household.hanacollector;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Fixed photo allowlist. Credentials stay native; encrypted cache is excluded from backup. */
final class WelcomeAssets {
    private static final int LIMIT=2*1024*1024;
    private static final String ALIAS="household-welcome-photos";
    private static final String BASE="https://xcchskngoactqsiiutsp.supabase.co/functions/v1/family-welcome/";
    private static synchronized SecretKey key()throws Exception{
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(!store.containsAlias(ALIAS)){
            KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();
        }
        return (SecretKey)store.getKey(ALIAS,null);
    }
    private static String token(Context c,int which)throws Exception{
        switch(which){case 0:return TokenVault.load(c);case 1:return KbTokenVault.load(c);case 2:return NhTokenVault.load(c);default:return ShinhanTokenVault.load(c);}
    }
    private static byte[] read(InputStream in,int limit)throws IOException{
        try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1){if(out.size()+n>limit)throw new IOException();out.write(buffer,0,n);}return out.toByteArray();
        }
    }
    private static boolean jpeg(byte[] b){return b.length>3&&(b[0]&255)==255&&(b[1]&255)==216;}
    private static final Object FIRST=new Object(),SECOND=new Object();
    static byte[] load(Context c,String name){
        if(!name.equals("family-first.jpg")&&!name.equals("family-second.jpg"))return null;
        synchronized(name.equals("family-first.jpg")?FIRST:SECOND){return loadPhoto(c,name);}
    }
    private static byte[] cached(File file,byte[] aad){
        if(!file.isFile()||System.currentTimeMillis()<file.lastModified()||System.currentTimeMillis()-file.lastModified()>=86400000L)return null;
        try{byte[] saved=read(new FileInputStream(file),LIMIT+64);
            if(saved.length>28){Cipher decrypt=Cipher.getInstance("AES/GCM/NoPadding");decrypt.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,saved,0,12));decrypt.updateAAD(aad);
                byte[] plain=decrypt.doFinal(saved,12,saved.length-12);if(jpeg(plain))return plain;}
        }catch(Exception invalidCache){}return null;
    }
    private static byte[] loadPhoto(Context c,String name){
        if(!name.equals("family-first.jpg")&&!name.equals("family-second.jpg"))return null;
        // Only explicitly private test builds can contain bundled photos.
        try{return read(c.getAssets().open("welcome/"+name),LIMIT);}catch(Exception absent){}
        File file=new File(c.getNoBackupFilesDir(),"welcome-"+name+".enc");
        java.util.ArrayList<String> tokens=new java.util.ArrayList<>();
        for(int i=0;i<4;i++)try{String t=token(c,i);if(CapturePolicy.tokenValid(t)&&!tokens.contains(t))tokens.add(t);}catch(Exception unavailable){}
        // Try every local credential before networking; one revoked key cannot delete another key's cache.
        for(String t:tokens){byte[] bytes=cached(file,(name+":"+t).getBytes(java.nio.charset.StandardCharsets.UTF_8));if(bytes!=null)return bytes;}
        long deadline=android.os.SystemClock.elapsedRealtime()+6000;
        for(String token:tokens)try{
            int remaining=(int)(deadline-android.os.SystemClock.elapsedRealtime());if(remaining<=0)return null;
            byte[] aad=(name+":"+token).getBytes("UTF-8");
            HttpsURLConnection connection=(HttpsURLConnection)new URL(BASE+name).openConnection();
            byte[] bytes;
            try{
                connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(Math.min(2000,remaining));connection.setReadTimeout(Math.min(2000,remaining));
                connection.setUseCaches(false);connection.setRequestProperty("Authorization","Bearer "+token);
                int code=connection.getResponseCode();
                if(code==401)continue;
                if(code!=200||connection.getContentLengthLong()>LIMIT||!"image/jpeg".equals(connection.getContentType()))return null;
                try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[8192];int n;
                    while(true){remaining=(int)(deadline-android.os.SystemClock.elapsedRealtime());if(remaining<=0)throw new IOException("Photo timeout");connection.setReadTimeout(Math.min(2000,remaining));n=input.read(buffer);if(n<0)break;if(output.size()+n>LIMIT)throw new IOException();output.write(buffer,0,n);}bytes=output.toByteArray();
                }if(!jpeg(bytes))return null;
            }finally{connection.disconnect();}
            Cipher encrypt=Cipher.getInstance("AES/GCM/NoPadding");encrypt.init(Cipher.ENCRYPT_MODE,key());encrypt.updateAAD(aad);
            AtomicFile target=new AtomicFile(file);FileOutputStream out=null;
            try{out=target.startWrite();out.write(encrypt.getIV());out.write(encrypt.doFinal(bytes));target.finishWrite(out);}
            catch(Exception failure){if(out!=null)target.failWrite(out);}
            return bytes;
        }catch(Exception unavailable){}
        return null;
    }
    private WelcomeAssets(){}
}
