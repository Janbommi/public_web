package kr.household.hanacollector;

import android.app.Activity;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class HanaActivity extends Activity {
    private TextView status,notification,diagnostic,syncStatus,purchaseStatus,cardConfirmation;private EditText token;private Button probe,confirmButton;private TextView listenerStatus,doneCount,pendingCount;
    private CardUi.Summary summary;private Button save;
    private boolean visible=false;private int generation=0;private final Handler main=new Handler(Looper.getMainLooper());
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xfff7f3eb);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);int pad=dp(20);box.setPadding(pad,pad,pad,pad);scroll.addView(box);setContentView(scroll);
        box.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(pad,pad+bars.top,pad,pad+bars.bottom);return insets;});
        button(box,"← 홈",v->finish());
        CardUi.heading(box,"하나 MOVING ONLINE",24);
        summary=new CardUi.Summary(box);LinearLayout connection=summary.actions;
        listenerStatus=label(connection,"",14);cardConfirmation=label(connection,"",14);
        confirmButton=button(connection,"본인 카드 확인하고 자동 집계 시작",v->{try{
            if(!DiagnosticSync.enabled(this)){status.setText("첫 연결 확인을 위해 ‘진단 및 관리’의 ‘내용 없는 진단 자동 전송’을 켜 주세요.");return;}
            final String confirmation,identity;
            synchronized(CaptureRuntime.class){confirmation=CaptureRuntime.confirmText(this);identity=CaptureRuntime.candidateId(this);}
            new android.app.AlertDialog.Builder(this).setTitle("이 결제가 내 하나 MOVING ONLINE인가요?").setMessage(confirmation+"\n확인하면 이 건부터 금액·거래시각을 서버에 보내고 이후 일시불 결제를 자동 집계합니다.")
                .setNegativeButton("아직 확인 안 함",null).setPositiveButton("맞아요 · 시작",(dialog,which)->{try{CaptureRuntime.confirm(this,identity);status.setText("자동 집계를 시작합니다. 인터넷·절전 상태에 따라 반영이 늦어질 수 있습니다.");}catch(Exception e){status.setText("새 알림이 바뀌었거나 저장하지 못했습니다. 카드 표시를 다시 확인해 주세요.");}refreshDiagnostics();}).show();
        }catch(Exception e){status.setText("업데이트 후 새 하나Pay 일시불 알림을 받은 다음 이 버튼을 눌러 주세요. 이미 시작했다면 다시 확인하지 않아도 됩니다.");}});
        CardUi.style(confirmButton,true,false);
        button(box,"우리 집 카드 합계 보기 ↗",v->startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://janbommi.github.io/public_web/household/budget/"))));
        TextView manageHeading=label(box,"설정과 도움말",13);manageHeading.setTextColor(android.graphics.Color.rgb(101,119,128));
        status=label(box,"",13);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        LinearLayout manage=fold(box,"수집 관리",false);
        button(manage,"자동 집계 잠시 끄기",v->{try{CaptureRuntime.enabled(this,false);status.setText("이 폰의 새 결제 저장·전송을 멈췄습니다. 이미 반영된 합계는 유지됩니다.");}catch(Exception e){status.setText("설정을 확인하지 못했습니다.");}refreshDiagnostics();});
        button(manage,"자동 집계 재개 / 전송 다시 시도",v->{try{CaptureRuntime.enabled(this,true);CaptureRuntime.request(this,true);}catch(Exception e){status.setText("먼저 본인 카드 확인을 완료해 주세요.");}refreshDiagnostics();});

        LinearLayout settings=fold(box,"연결 설정",!hasKey());
        button(settings,"1. 알림 접근 설정 열기",v->{try{startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));}catch(Exception e){status.setText("설정에서 ‘알림 접근’을 검색해 주세요.");}});
        label(settings,"2. 가계 웹에서 발급한 연결 키 붙여넣기",17);
        token=new EditText(this);token.setSingleLine(true);token.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);token.setSaveEnabled(false);token.setHint("64자리 연결 키 · 비밀번호가 아닙니다");token.setContentDescription("하나 전용 연결 키");settings.addView(token);
        save=button(settings,"동의하고 하나 키 연결",v->connectKey());
        probe=button(settings,"3. 서버 연결 확인",v->checkServer());
        label(settings,"기존 연결 키는 그대로 사용하세요.",13);
        button(settings,"알림 연결 상태 확인",v->status.setText(HanaListener.connected?"Android 알림 서비스 연결됨 · 실제 하나Pay 수신은 아래에서 확인":"아직 알림 서비스 연결이 확인되지 않았습니다."));

        LinearLayout diagnostics=fold(box,"진단 및 관리",false);
        label(diagnostics,"최근 하나Pay 알림 · 이 폰에서만 표시",18);notification=label(diagnostics,HanaListener.view(),16);
        label(diagnostics,"자동 저장된 수신 진단 · 최근 7일 / 최대 32개",18);
        diagnostic=label(diagnostics,"",14);
        CheckBox auto=new CheckBox(this);auto.setText("내용 없는 진단 자동 전송");auto.setChecked(DiagnosticSync.enabled(this));diagnostics.addView(auto);
        syncStatus=label(diagnostics,"",14);
        auto.setOnCheckedChangeListener((v,checked)->{try{DiagnosticSync.setEnabled(this,checked);}catch(RuntimeException e){status.setText("자동 전송 설정을 저장하지 못했습니다.");}syncStatus.setText(DiagnosticSync.status(this));refreshDiagnostics();});
        label(diagnostics,"인터넷 연결 시 OS가 전송합니다. 절전 상태에서는 지연될 수 있습니다. 실패하면 간격을 늘려 최대 5회 시도합니다. 스위치를 끄면 이후 자동 전송이 중단되며 이미 전달된 최근 상태는 서버에 남습니다.",14);
        button(diagnostics,"진단 전송 다시 시도",v->{DiagnosticSync.request(this,true);syncStatus.setText(DiagnosticSync.status(this));refreshDiagnostics();});
        button(diagnostics,"최근 알림 다시 확인",v->refreshDiagnostics());
        button(diagnostics,"내용 없는 진단 결과 복사",v->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("하나 연결 진단",readDiagnostic()));status.setText("내용 없는 진단 결과를 복사했습니다. 수신·갱신 횟수는 결제 건수가 아닙니다.");});
        button(diagnostics,"알림 표시 지우기",v->{HanaListener.clear();notification.setText(HanaListener.view());});
        button(diagnostics,"저장된 진단 기록 지우기",v->{try{DiagnosticStore.clear(this);DiagnosticSync.request(this,true);HanaListener.diagnosticWriteFailed=false;refreshDiagnostics();status.setText("폰의 진단 기록을 지웠습니다. 자동 전송이 켜져 있으면 다음 전송 때 서버 요약도 갱신됩니다. 연결 키는 유지됩니다.");}catch(RuntimeException e){status.setText("진단 기록 삭제를 확인하지 못했습니다.");}});
        button(diagnostics,"이 폰의 연결 키 삭제",v->new android.app.AlertDialog.Builder(this).setTitle("연결 키를 삭제할까요?").setMessage("이 폰의 전송이 중단됩니다. 서버 권한은 웹의 연결 관리에서 별도로 해제하세요.").setNegativeButton("유지",null).setPositiveButton("삭제",(dialog,which)->{generation++;try{TokenVault.clear(this);CaptureRuntime.keyChanged(this);DiagnosticSync.keyChanged(this);status.setText("폰의 키를 삭제했습니다. 가계 웹의 ‘연결 해제’도 눌러 서버 권한을 폐기해 주세요.");}catch(Exception e){status.setText("삭제를 확인하지 못했습니다. 앱 데이터를 삭제하지 말고 웹에서 연결 상태를 확인해 주세요.");}refreshDiagnostics();}).show());

        LinearLayout guide=fold(box,"안내사항",false);
        label(guide,"수집된 국내 일시불 승인만 반영합니다. 시작 전 거래·취소·할부·해외결제는 미포함이며, 카드사 전체 이용액과 다를 수 있습니다. 위 건수는 이 폰에 보관된 수집 기록 기준이며 누적 이용 건수가 아닙니다.",14);
        label(guide,"앱을 열어 두면 상태가 자동 갱신됩니다. 인터넷·절전 상태에 따라 서버 반영이 늦어질 수 있습니다. 전송 대기 중에는 앱이나 데이터를 삭제하지 마세요.",14);
        label(guide,"첫 새 알림에서 본인 카드·금액·시각을 확인한 뒤 자동 집계를 시작합니다. 서버에는 금액·시각·재전송용 ID만 보내며 원문·가맹점·카드번호는 보내지 않습니다. 폰의 대기 자료는 암호화합니다.",14);
        label(guide,"알림 접근은 넓은 Android 권한입니다. 이 앱은 하나Pay와 별도 연결한 KB Pay·NH pay·신한 SOL페이만 처리합니다. Play Protect나 민감 알림 보호 기능을 끄지 마세요. 설치가 차단되면 표시 문구를 알려주세요.",14);
        label(box,"버전 0.94 · 하나 연결",12);
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private boolean hasKey(){try{return TokenVault.load(this)!=null;}catch(Exception e){return false;}}
    private android.graphics.drawable.GradientDrawable background(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout card(LinearLayout parent){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(22),dp(14),dp(22),dp(18));b.setBackground(background(android.graphics.Color.WHITE,20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(12),0,dp(4));parent.addView(b,p);return b;}
    private TextView metric(LinearLayout row,String name,boolean primary){LinearLayout column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);column.setPadding(0,dp(12),dp(12),dp(4));row.addView(column,new LinearLayout.LayoutParams(0,-2,1));TextView count=label(column,"—",38);count.setTypeface(null,android.graphics.Typeface.BOLD);count.setTextColor(primary?android.graphics.Color.rgb(8,126,128):android.graphics.Color.rgb(23,43,51));TextView caption=label(column,name,12);caption.setTextColor(android.graphics.Color.rgb(101,119,128));return count;}
    private LinearLayout fold(LinearLayout p,String name,boolean open){return CardUi.fold(p,name,open);}
    private TextView label(LinearLayout p,String value,int size){return CardUi.text(p,value,size);}
    private Button button(LinearLayout p,String value,View.OnClickListener action){return CardUi.button(p,value,action);}
    private final Runnable refreshScreen=new Runnable(){public void run(){if(!visible)return;refreshDiagnostics();main.postDelayed(this,1500);}};
    private void setChanged(TextView view,String value){if(!value.contentEquals(view.getText()))view.setText(value);}
    private String readDiagnostic(){try{return (HanaListener.diagnosticWriteFailed?"최근 진단 저장을 확인하지 못했습니다. 아래에는 이전 기록이 표시될 수 있습니다.\n":"")+DiagnosticStore.report(this);}catch(RuntimeException e){return "저장된 진단을 읽지 못했습니다. 수신 실패로 단정할 수 없습니다.";}}
    private void refreshDiagnostics(){setChanged(notification,HanaListener.view());setChanged(diagnostic,readDiagnostic());setChanged(syncStatus,DiagnosticSync.status(this));CardUiState state=CaptureRuntime.uiState(this);summary.show(state);setChanged(cardConfirmation,state.canConfirm?(DiagnosticSync.enabled(this)?CaptureRuntime.confirmText(this):"확인 전에 ‘진단 및 관리’에서 ‘내용 없는 진단 자동 전송’을 켜 주세요."):"");confirmButton.setEnabled(DiagnosticSync.enabled(this));cardConfirmation.setVisibility(state.canConfirm?View.VISIBLE:View.GONE);setChanged(listenerStatus,HanaListener.connected?"알림 서비스 연결됨":"알림 서비스 연결 확인 필요");confirmButton.setVisibility(state.canConfirm?View.VISIBLE:View.GONE);}
    private void connectKey(){
        String candidate=token.getText().toString().trim();token.setText("");
        if(!CapturePolicy.tokenValid(candidate)){status.setText("64자리 하나 전용 키를 확인해 주세요.");return;}
        try{String old=TokenVault.load(this);if(old!=null&&!old.equals(candidate)){
            new android.app.AlertDialog.Builder(this).setTitle("하나 연결 키를 교체할까요?").setMessage("이전 키의 전송 대기는 새 키로 옮기지 않습니다. 대기 건수가 있다면 취소하고 먼저 전송해 주세요.").setNegativeButton("취소",null).setPositiveButton("교체",(d,w)->checkServer(candidate,true)).show();return;
        }}catch(Exception e){status.setText("기존 하나 키를 읽지 못했어요. 앱 데이터를 삭제하지 마세요.");return;}
        checkServer(candidate,true);
    }
    private void checkServer(){try{String credential=TokenVault.load(this);if(credential==null)throw new IllegalStateException();checkServer(credential,false);}catch(Exception e){status.setText("연결 키를 먼저 저장해 주세요.");}}
    private void checkServer(String credential,boolean store){
        final int current=++generation;probe.setEnabled(false);save.setEnabled(false);status.setText("연결 확인 중 · 알림 내용은 전송하지 않습니다.");
        new Thread(()->{String result;boolean success=false;HttpsURLConnection connection=null;
            try{
                connection=(HttpsURLConnection)new URL(CapturePolicy.ENDPOINT).openConnection();
                connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(10000);connection.setReadTimeout(10000);
                connection.setRequestMethod("POST");connection.setRequestProperty("Authorization","Bearer "+credential);
                connection.setRequestProperty("Content-Type","application/json");connection.setRequestProperty("Cache-Control","no-store");
                byte[] payload=CapturePolicy.PROBE_BODY.getBytes(StandardCharsets.UTF_8);connection.setFixedLengthStreamingMode(payload.length);connection.setDoOutput(true);
                try(java.io.OutputStream out=connection.getOutputStream()){out.write(payload);}
                int code=connection.getResponseCode();
                if(code==200){
                    byte[] body;try(java.io.InputStream in=connection.getInputStream();java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream()){
                        byte[] buffer=new byte[512];int n;while((n=in.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>2048)break;}body=bytes.toByteArray();}
                    if(body.length>2048)throw new IllegalStateException();
                    org.json.JSONObject response=new org.json.JSONObject(new String(body,StandardCharsets.UTF_8));
                    if(!"connected".equals(response.optString("status")))throw new IllegalStateException();
                    success=true;result=response.optBoolean("captureEnabled",false)?"서버 연결 성공 · 하나카드 시범 집계 허용됨":"서버 연결 성공 · 첫 새 알림에서 본인 카드를 확인해 주세요.";
                }else result=code==401?"키가 만료되었거나 연결이 해제됐습니다. 웹에서 새로 연결해 주세요.":"연결 결과를 확인하지 못했습니다. 잠시 후 다시 확인해 주세요.";
            }catch(Exception e){result="연결하지 못했습니다. 인터넷 연결과 키를 확인해 주세요.";}
            finally{if(connection!=null)connection.disconnect();}
            final String message=result;final boolean accepted=success;main.post(()->{if(current==generation&&visible){probe.setEnabled(true);save.setEnabled(true);try{if(accepted&&store){String old=TokenVault.load(this);if(!credential.equals(old)){TokenVault.save(this,credential);CaptureRuntime.keyChanged(this);DiagnosticSync.keyChanged(this);}}status.setText(message+(accepted?"":" 기존 키는 유지됩니다."));}catch(Exception e){status.setText("키 저장을 확인하지 못했어요. 앱 데이터를 삭제하지 마세요.");}refreshDiagnostics();}});
        },"hana-probe").start();
    }
    @Override protected void onResume(){super.onResume();visible=true;probe.setEnabled(true);save.setEnabled(true);DiagnosticSync.request(this,false);CaptureRuntime.request(this,false);main.removeCallbacks(refreshScreen);refreshScreen.run();}
    @Override protected void onPause(){visible=false;main.removeCallbacks(refreshScreen);generation++;syncStatus.setText("");token.setText("");notification.setText("");diagnostic.setText("");cardConfirmation.setText("");super.onPause();}
}
