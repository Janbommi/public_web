package kr.household.hanacollector;

import java.time.Instant;
import java.time.ZoneId;
import java.util.*;

/**
 * Local calculation contract for normalized approvals and cancellations.
 * NOT wired to notification parsing, persistence, or server transport yet.
 * Callers must use exact issuer transaction references, scoped to owner/card;
 * amounts, merchant names and timestamps are never substitutes for a reference.
 * No raw notification, name, card number or merchant is accepted here.
 */
public final class SettlementLedger {
    public enum Kind { APPROVAL, CANCELLATION }
    public enum State { READY, WAITING_ORIGINAL, WAITING_KRW, REVIEW, ACKNOWLEDGED }
    public static final long MAX_AMOUNT=1_000_000_000L;
    private static final ZoneId KST=ZoneId.of("Asia/Seoul");

    public static final class Event {
        public final String id,originalId,currency;
        public final Kind kind;
        public final CaptureOutbox.Card card;
        public final long nativeMinor,occurredAt,krw;

        /** krw == 0 means unconfirmed; nativeMinor uses the currency's minor units. */
        public Event(String id,String originalId,Kind kind,CaptureOutbox.Card card,
                     String currency,long nativeMinor,long occurredAt,long krw) {
            digest(id);Objects.requireNonNull(kind);Objects.requireNonNull(card);
            if(card==CaptureOutbox.Card.SAMSUNG_FAMILY)throw new IllegalArgumentException("Unsupported card");
            if(kind==Kind.CANCELLATION){digest(originalId);if(id.equals(originalId))throw new IllegalArgumentException("Self cancellation");}
            else if(originalId!=null)throw new IllegalArgumentException("Approval has no parent");
            // Restrict supported currencies until a parser supplies verified currency metadata.
            if(!Arrays.asList("KRW","USD","EUR","JPY","GBP","CNY","HKD").contains(currency))throw new IllegalArgumentException("Unsupported currency");
            if(nativeMinor<=0||nativeMinor>MAX_AMOUNT||occurredAt<=0||krw<0||krw>MAX_AMOUNT)throw new IllegalArgumentException("Invalid amount or date");
            if(currency.equals("KRW")&&krw!=nativeMinor)throw new IllegalArgumentException("KRW must be exact");
            this.id=id;this.originalId=originalId;this.kind=kind;this.card=card;
            this.currency=currency;this.nativeMinor=nativeMinor;this.occurredAt=occurredAt;this.krw=krw;
        }
        private Event confirmed(long value){return new Event(id,originalId,kind,card,currency,nativeMinor,occurredAt,value);}
        private boolean sameSource(Event other){return id.equals(other.id)&&Objects.equals(originalId,other.originalId)&&kind==other.kind&&card==other.card&&currency.equals(other.currency)&&nativeMinor==other.nativeMinor&&occurredAt==other.occurredAt;}
    }
    public static final class Decision {
        public final Event event;
        public final State state;
        public final String month,reason;
        public final long deltaKrw;
        private Decision(Event event,State state,String month,long delta,String reason){this.event=event;this.state=state;this.month=month;deltaKrw=delta;this.reason=reason;}
    }
    private final LinkedHashMap<String,Event> events=new LinkedHashMap<>();
    private final Set<String> acknowledged=new HashSet<>();
    private final Set<String> conflicts=new HashSet<>();
    public static final int LIMIT=2048;
    private static void digest(String v){if(v==null||!v.matches("[a-f0-9]{64}"))throw new IllegalArgumentException("Opaque reference required");}
    private static String key(CaptureOutbox.Card card,String id){return card.name()+":"+id;}
    private static String month(long at){return Instant.ofEpochMilli(at).atZone(KST).toLocalDate().withDayOfMonth(1).toString();}

    /** Exact retransmission is a no-op; conflicting payload is held, never overwritten. */
    public synchronized void observe(Event e){
        Objects.requireNonNull(e);String k=key(e.card,e.id);Event old=events.get(k);
        if(old!=null){
            // Replaying the original foreign alert after an explicit KRW confirmation
            // must neither erase that confirmation nor become a conflicting payment.
            if(!old.sameSource(e)||(e.krw!=old.krw&&e.krw!=0))conflicts.add(k);
            return;
        }
        if(events.size()>=LIMIT)throw new IllegalStateException("Local reconciliation storage full");
        events.put(k,e);
    }

    /** Explicit card-stated final KRW only, not a spot-rate estimate. One-time confirmation. */
    public synchronized void confirmKrw(CaptureOutbox.Card card,String id,long krw){
        String k=key(card,id);Event e=events.get(k);
        if(e==null||krw<=0||krw>MAX_AMOUNT||conflicts.contains(k))throw new IllegalArgumentException("Unconfirmable amount");
        if(e.krw!=0){if(e.krw!=krw)throw new IllegalStateException("Already confirmed with a different amount");return;}
        events.put(k,e.confirmed(krw));
    }

    /**
     * Pure decisions: approvals precede their cancellations, regardless of arrival order.
     * A cancellation may only leave this ledger after its approval was acknowledged.
     * Foreign cancellations require their own final refunded KRW, never proportional FX.
     */
    public synchronized List<Decision> decisions(){
        List<Decision> result=new ArrayList<>();
        Map<String,Long> usedNative=new HashMap<>(),usedKrw=new HashMap<>();
        Set<String> disputedParents=new HashSet<>();
        for(Event e:events.values())if(e.kind==Kind.CANCELLATION&&conflicts.contains(key(e.card,e.id))&&!acknowledged.contains(key(e.card,e.id)))disputedParents.add(key(e.card,e.originalId));
        for(Event e:events.values())if(e.kind==Kind.APPROVAL){
            String k=key(e.card,e.id);
            State s=acknowledged.contains(k)?State.ACKNOWLEDGED:conflicts.contains(k)?State.REVIEW:e.krw==0?State.WAITING_KRW:State.READY;
            result.add(new Decision(e,s,month(e.occurredAt),s==State.READY?e.krw:0,s==State.REVIEW?"conflicting_source":s==State.WAITING_KRW?"unconfirmed_krw":""));
        }
        // Already sent cancellations reserve their balances before unsent events.
        List<Event> cancellations=new ArrayList<>();
        for(Event e:events.values())if(e.kind==Kind.CANCELLATION)cancellations.add(e);
        cancellations.sort((a,b)->Boolean.compare(!acknowledged.contains(key(a.card,a.id)),!acknowledged.contains(key(b.card,b.id))));
        for(Event e:cancellations){
            String k=key(e.card,e.id),parent=key(e.card,e.originalId);
            Event original=events.get(parent);
            if(original==null||original.kind!=Kind.APPROVAL){result.add(new Decision(e,State.WAITING_ORIGINAL,null,0,"original_not_collected"));continue;}
            String m=month(original.occurredAt);
            if(acknowledged.contains(k)){
                // A later conflicting redelivery cannot free an already refunded balance.
                usedNative.put(parent,usedNative.getOrDefault(parent,0L)+e.nativeMinor);
                usedKrw.put(parent,usedKrw.getOrDefault(parent,0L)+e.krw);
                result.add(new Decision(e,State.ACKNOWLEDGED,m,0,conflicts.contains(k)?"conflicting_source":""));
                continue;
            }
            if(!original.currency.equals(e.currency)||e.occurredAt<original.occurredAt){result.add(new Decision(e,State.REVIEW,m,0,"original_mismatch"));continue;}
            if(conflicts.contains(k)||conflicts.contains(parent)||disputedParents.contains(parent)){result.add(new Decision(e,State.REVIEW,m,0,"conflicting_source"));continue;}
            long nativeUsed=usedNative.getOrDefault(parent,0L),krwUsed=usedKrw.getOrDefault(parent,0L);
            if(e.nativeMinor>original.nativeMinor-nativeUsed){result.add(new Decision(e,State.REVIEW,m,0,"over_cancellation"));continue;}
            // Reserve native balance even for pending KRW: a later cancel cannot spend it twice.
            usedNative.put(parent,nativeUsed+e.nativeMinor);
            if(e.krw==0||original.krw==0){result.add(new Decision(e,State.WAITING_KRW,m,0,"unconfirmed_krw"));continue;}
            if(e.krw>original.krw-krwUsed){result.add(new Decision(e,State.REVIEW,m,0,"refund_exceeds_reflected_krw"));continue;}
            usedKrw.put(parent,krwUsed+e.krw);
            State s=acknowledged.contains(k)?State.ACKNOWLEDGED:acknowledged.contains(parent)?State.READY:State.WAITING_ORIGINAL;
            result.add(new Decision(e,s,m,s==State.READY?-e.krw:0,s==State.WAITING_ORIGINAL?"original_not_acknowledged":""));
        }
        return Collections.unmodifiableList(result);
    }

    /** Mark only after the server acknowledges this exact operation ID/payload. */
    public synchronized void acknowledge(CaptureOutbox.Card card,String id){
        String k=key(card,id);
        if(acknowledged.contains(k))return;
        for(Decision d:decisions())if(d.event.card==card&&d.event.id.equals(id)){
            if(d.state!=State.READY)throw new IllegalStateException("Not ready for acknowledgement");
            acknowledged.add(k);return;
        }
        throw new IllegalArgumentException("Unknown operation");
    }
}
