package kr.household.hanacollector;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.webkit.*;
import android.widget.FrameLayout;
import java.util.concurrent.atomic.AtomicBoolean;

/** Private cached family welcome. No login, token or notification bridge. */
final class WelcomeScreen {
    private static final AtomicBoolean shown=new AtomicBoolean();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private WebView web;
    private FrameLayout cover;
    private boolean finished;
    private final Runnable timeout=()->finish();
    static WelcomeScreen show(Activity activity, boolean recreated){
        if(recreated||shown.get())return null;
        try(java.io.InputStream ignored=activity.getAssets().open("welcome/index.html")){}
        catch(Exception unavailable){return null;}
        if(!shown.compareAndSet(false,true))return null;
        WelcomeScreen screen=new WelcomeScreen();
        try{screen.attach(activity);return screen;}
        catch(RuntimeException unavailable){screen.finish();return null;}
    }
    static WelcomeScreen replay(Activity activity){
        WelcomeScreen screen=new WelcomeScreen();try{screen.attach(activity);return screen;}catch(RuntimeException e){screen.finish();return null;}
    }
    private void attach(Activity activity){
        cover=new FrameLayout(activity);cover.setBackgroundColor(0xfff7f3eb);
        web=new WebView(activity);web.setBackgroundColor(0xfff7f3eb);
        WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setBlockNetworkLoads(true);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
                String url=request.getUrl().toString();
                if(url.equals("file:///android_asset/welcome/family-first.jpg")||url.equals("file:///android_asset/welcome/family-second.jpg")){
                    byte[] bytes=WelcomeAssets.load(activity.getApplicationContext(),request.getUrl().getLastPathSegment());
                    return new WebResourceResponse("image/jpeg",null,bytes==null?404:200,bytes==null?"Unavailable":"OK",java.util.Collections.singletonMap("Cache-Control","no-store"),new java.io.ByteArrayInputStream(bytes==null?new byte[0]:bytes));
                }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                if(request.isForMainFrame()&&"asset-app://continue".equals(request.getUrl().toString()))finish();
                return true;
            }
            @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())finish();}
        });
        cover.addView(web,new FrameLayout.LayoutParams(-1,-1));
        activity.addContentView(cover,new ViewGroup.LayoutParams(-1,-1));
        cover.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets bars=i.getInsets(android.view.WindowInsets.Type.systemBars());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return i;});
        cover.requestApplyInsets();
        AccessibilityManager manager=(AccessibilityManager)activity.getSystemService(Activity.ACCESSIBILITY_SERVICE);
        boolean reading=manager!=null&&manager.isTouchExplorationEnabled();
        web.loadUrl("file:///android_asset/welcome/index.html?reduceMotion="+(ValueAnimator.areAnimatorsEnabled()?"0":"1")+"&stay="+(reading?"1":"0"));
        if(!reading)handler.postDelayed(timeout,15000);
    }
    boolean isShowing(){return !finished;}
    void finish(){
        if(finished)return;finished=true;handler.removeCallbacks(timeout);
        if(cover!=null&&cover.getParent() instanceof ViewGroup)((ViewGroup)cover.getParent()).removeView(cover);
        if(web!=null){web.stopLoading();web.destroy();web=null;}cover=null;
    }
}
