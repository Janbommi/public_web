package kr.household.hanacollector;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Fixed numeric diagnostics only: never stores text, values, IDs or content hashes. */
public final class DiagnosticHistory {
    public static final int LIMIT=32;
    public static final long RETENTION_MS=7L*24*60*60*1000;
    private static final Pattern MONEY=Pattern.compile("[0-9][0-9,]*\\s*원");
    private static final Pattern DATE=Pattern.compile("[0-9]{2}[/.][0-9]{2}");
    private static final class Sample {
        final long savedAt; final int length,flags;
        Sample(long at,int length,int flags){savedAt=at;this.length=length;this.flags=flags;}
    }
    private final List<Sample> samples=new ArrayList<>();
    private void prune(long now){samples.removeIf(s->s.savedAt>now||now-s.savedAt>=RETENTION_MS);}
    public void capture(String title,String body,boolean parsed,long now){
        if(now<=0)throw new IllegalArgumentException("Invalid diagnostic clock");
        String t=title==null?"":title,b=body==null?"":body;
        if(t.length()>20000||b.length()>20000||t.length()+b.length()>20000)throw new IllegalArgumentException("Oversized input");
        String text=t+"\n"+b;
        int flags=(text.contains("결제")?1:0)|(text.contains("승인")?2:0)|(text.contains("취소")?4:0)
          |(MONEY.matcher(text).find()?8:0)|(DATE.matcher(text).find()?16:0)|(!b.isEmpty()?32:0)|(parsed?64:0);
        prune(now);samples.add(new Sample(now,t.length()+b.length(),flags));
        while(samples.size()>LIMIT)samples.remove(0);
    }
    public String encode(){
        StringBuilder out=new StringBuilder("1");
        for(Sample s:samples)out.append(';').append(s.savedAt).append(',').append(s.length).append(',').append(s.flags);
        return out.toString();
    }
    public static DiagnosticHistory decode(String encoded,long now){
        DiagnosticHistory h=new DiagnosticHistory();
        if(encoded==null||encoded.length()>4096||now<=0)return h;
        String[] rows=encoded.split(";",-1);
        if(!rows[0].equals("1")||rows.length>LIMIT+1)return h;
        try{
            for(int i=1;i<rows.length;i++){
                String[] v=rows[i].split(",",-1);if(v.length!=3)return new DiagnosticHistory();
                long at=Long.parseLong(v[0]);int length=Integer.parseInt(v[1]),flags=Integer.parseInt(v[2]);
                if(at<=0||length<0||length>20000||flags<0||flags>127)return new DiagnosticHistory();
                h.samples.add(new Sample(at,length,flags));
            }
        }catch(NumberFormatException e){return new DiagnosticHistory();}
        h.prune(now);return h;
    }
    public int size(){return samples.size();}
    public int parsedCount(){int count=0;for(Sample s:samples)if((s.flags&64)!=0)count++;return count;}
    public String uploadJson(long now,boolean connected){
        prune(now);Sample last=samples.isEmpty()?null:samples.get(samples.size()-1);
        return "{\"type\":\"diagnostic\",\"appVersion\":10,\"snapshotAt\":"+now+",\"listenerConnected\":"+connected
          +",\"observations\":"+size()+",\"parsedCount\":"+parsedCount()+",\"lastObservedAt\":"+(last==null?"null":Long.toString(last.savedAt))
          +",\"textLength\":"+(last==null?"null":Integer.toString(last.length))+",\"flags\":"+(last==null?"null":Integer.toString(last.flags))+"}";
    }
    public String report(){
        if(samples.isEmpty())return "보관된 진단 기록이 없습니다. 0.3 업데이트 후 새로 수신한 알림부터 기록합니다.\n기록이 비어 있다는 것만으로 수신 실패를 확정할 수 없습니다.";
        StringBuilder out=new StringBuilder("진단 버전: 0.91\n최근 7일 내 수신·갱신 기록: ").append(size())
          .append(" (최대 32개, 결제 건수 아님)\n국내 일시불 형식 확인: ").append(parsedCount())
          .append("\n이 진단에는 원문·금액·가맹점·카드번호·거래시각을 포함하지 않음\n최근 기록부터 표시:");
        for(int i=samples.size()-1;i>=0;i--){Sample s=samples.get(i);out.append("\n#").append(samples.size()-i)
          .append(" 길이=").append(s.length).append(" 결제표현=").append((s.flags&1)!=0)
          .append(" 승인표현=").append((s.flags&2)!=0).append(" 취소표현=").append((s.flags&4)!=0)
          .append(" 금액형태=").append((s.flags&8)!=0).append(" 날짜형태=").append((s.flags&16)!=0)
          .append(" 본문있음=").append((s.flags&32)!=0).append(" 일시불형식=").append((s.flags&64)!=0);}
        return out.toString();
    }
}
