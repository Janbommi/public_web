package kr.household.hanacollector;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

/** Shared entry point. Monthly totals remain in the authenticated household dashboard. */
public final class MainActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private TextView listenerStatus;
    private boolean visible;
    private WelcomeScreen welcome;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xfff3f5f7);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        int pad=dp(20);box.setPadding(pad,pad,pad,pad);scroll.addView(box);setContentView(scroll);
        box.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets bars=i.getInsets(WindowInsets.Type.systemBars());v.setPadding(pad,pad+bars.top,pad,pad+bars.bottom);return i;});
        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);box.addView(brand);
        ImageView icon=new ImageView(this);icon.setImageDrawable(getApplicationInfo().loadIcon(getPackageManager()));
        brand.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        TextView title=label(brand,"  째미즈 asset",23);title.setTypeface(null,android.graphics.Typeface.BOLD);
        label(box,"이번 달 소비를 살피고, 여유를 모아요.",14);

        LinearLayout budget=card(box);
        TextView heading=label(budget,"우리 집 월 예산",22);heading.setTypeface(null,android.graphics.Typeface.BOLD);
        label(budget,"지금까지 쓴 금액과 남은 예산을 함께 확인해요.",15);
        button(budget,"월 사용액 · 남은 예산 보기 ↗",true,v->startActivity(new Intent(Intent.ACTION_VIEW,
            android.net.Uri.parse("https://janbommi.github.io/public_web/household/budget/"))));
        label(budget,"로그인한 우리 집 현황판에서 수집된 사용액을 확인합니다.",12);

        TextView cardsTitle=label(box,"내 카드",19);cardsTitle.setTypeface(null,android.graphics.Typeface.BOLD);
        label(box,"카드를 선택해 연결과 수집 상태를 확인하세요.",13);
        cardLink(box,"하나 MOVING ONLINE",HanaActivity.class);
        cardLink(box,"KB 쿠팡 와우",KbActivity.class);
        cardLink(box,"NH zgm 할인",NhActivity.class);
        cardLink(box,"신한 K-패스",ShinhanActivity.class);

        LinearLayout shared=card(box);label(shared,"공통 설정",16);
        button(shared,"시작 화면 다시 보기",false,v->{if(welcome!=null)welcome.finish();welcome=WelcomeScreen.replay(this);});
        listenerStatus=label(shared,"알림 서비스 확인 중…",13);
        button(shared,"알림 접근 설정",false,v->{try{
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        }catch(Exception e){listenerStatus.setText("휴대폰 설정에서 ‘알림 접근’을 검색해 주세요.");}});
        label(box,"거래 목록 없이 월 합계를 봅니다. 중복 집계를 막기 위한 승인액·시각·식별값은 내부에 보관합니다.",12);
        label(box,"현재 수집된 국내 일시불 기준입니다. 해외·할부·취소·수집되지 않은 결제는 합계에 포함되지 않습니다.",12);
        label(box,"버전 0.93 · 합계만, 우리 집에",12);
        welcome=WelcomeScreen.show(this,state!=null);
    }
    private void cardLink(LinearLayout box,String name,Class<?> target){
        button(box,name+"\n연결 · 수집 상태  →",false,v->startActivity(new Intent(this,target)));
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private android.graphics.drawable.GradientDrawable background(int color){
        android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();
        d.setColor(color);d.setCornerRadius(dp(16));return d;
    }
    private TextView label(LinearLayout parent,String value,int size){
        TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(0xff17333b);
        v.setPadding(0,dp(7),0,dp(7));v.setLineSpacing(dp(2),1);parent.addView(v);return v;
    }
    private LinearLayout card(LinearLayout parent){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(12),dp(18),dp(14));box.setBackground(background(Color.WHITE));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(12),0,dp(8));parent.addView(box,p);return box;
    }
    private Button button(LinearLayout parent,String value,boolean primary,View.OnClickListener action){
        Button v=new Button(this);v.setText(value);v.setAllCaps(false);v.setTextSize(16);
        v.setTextColor(primary?Color.WHITE:0xff17333b);v.setBackgroundTintList(null);
        v.setBackground(background(primary?0xff087e80:Color.WHITE));v.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        v.setMinHeight(dp(60));v.setPadding(dp(18),dp(12),dp(18),dp(12));v.setOnClickListener(action);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));parent.addView(v,p);return v;
    }
    private final Runnable refresh=new Runnable(){public void run(){
        if(!visible)return;
        listenerStatus.setText(HanaListener.connected?"알림 서비스 연결됨 · 카드별 수집 상태는 각 카드에서 확인":"알림 접근 연결 확인 필요");
        main.postDelayed(this,1500);
    }};
    @Override protected void onResume(){super.onResume();visible=true;
        DiagnosticSync.request(this,false);CaptureRuntime.request(this,false);KbCaptureRuntime.request(this,false);
        NhCaptureRuntime.request(this,false);ShinhanCaptureRuntime.request(this,false);
        main.removeCallbacks(refresh);refresh.run();
    }
    @Override protected void onPause(){visible=false;main.removeCallbacks(refresh);super.onPause();}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);
        if(Intent.ACTION_MAIN.equals(intent.getAction())&&intent.hasCategory(Intent.CATEGORY_LAUNCHER)){
            if(welcome!=null)welcome.finish();welcome=WelcomeScreen.replay(this);
        }
    }
    @Override public void onBackPressed(){if(welcome!=null&&welcome.isShowing()){welcome.finish();welcome=null;}else super.onBackPressed();}
    @Override protected void onDestroy(){if(welcome!=null)welcome.finish();super.onDestroy();}
}
