package kr.household.hanacollector;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

/** Shared collection entry point; no monthly spending or transaction-detail screen. */
public final class MainActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private TextView listenerStatus,enrollmentStatus;private Button permissionAction,sharedPermission;
    private final Button[] cardButtons=new Button[4];
    private final String[] cardNames={"하나 MOVING ONLINE","KB 쿠팡 와우","NH zgm 할인","신한 K-패스"};
    private int cardIndex;
    private boolean visible;
    private WelcomeScreen welcome;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xfff7f3eb);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        int pad=dp(20);box.setPadding(pad,pad,pad,pad);scroll.addView(box);setContentView(scroll);
        box.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets bars=i.getInsets(WindowInsets.Type.systemBars());v.setPadding(pad,pad+bars.top,pad,pad+bars.bottom);return i;});
        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);box.addView(brand);
        ImageView icon=new ImageView(this);icon.setImageDrawable(getApplicationInfo().loadIcon(getPackageManager()));
        brand.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        TextView title=label(brand,"  째미즈 asset",23);title.setTypeface(null,android.graphics.Typeface.BOLD);title.setAccessibilityHeading(true);


        LinearLayout budget=card(box);
        TextView heading=label(budget,"기기 연결",22);heading.setTypeface(null,android.graphics.Typeface.BOLD);
        enrollmentStatus=label(budget,DeviceEnrollment.stageText(this),15);
        button(budget,"기기 연결 · 초대",true,v->startActivity(new Intent(this,EnrollmentActivity.class)));

        permissionAction=button(box,"알림 접근 설정 확인",false,v->CardUi.openNotificationSettings(this));
        TextView cardsTitle=label(box,"내 카드",19);cardsTitle.setTypeface(null,android.graphics.Typeface.BOLD);cardsTitle.setAccessibilityHeading(true);
        label(box,"카드를 선택해 연결과 수집 상태를 확인하세요.",13);
        cardLink(box,"하나 MOVING ONLINE",HanaActivity.class);
        cardLink(box,"KB 쿠팡 와우",KbActivity.class);
        cardLink(box,"NH zgm 할인",NhActivity.class);
        cardLink(box,"신한 K-패스",ShinhanActivity.class);

        LinearLayout shared=CardUi.fold(box,"공통 설정",false);
        button(shared,"시작 화면 다시 보기",false,v->{if(welcome!=null)welcome.finish();welcome=WelcomeScreen.replay(this);});
        listenerStatus=label(shared,"알림 서비스 확인 중…",13);
        sharedPermission=button(shared,"알림 접근 설정",false,v->{try{
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        }catch(Exception e){listenerStatus.setText("휴대폰 설정에서 ‘알림 접근’을 검색해 주세요.");}});
        LinearLayout guide=CardUi.fold(box,"수집 범위 안내",false);
        label(guide,"서버에는 월 합계와 중복 방지 정보만 새로 저장합니다. 개별 결제 내역 화면은 제공하지 않습니다.",14);
        label(guide,"자동 수집은 국내 일시불 기준입니다. 해외 결제·취소는 각 카드의 보완 화면에서 확인해 반영하세요. 자동 반영은 운영 검증 전입니다.",12);
        label(box,"버전 1.0",12);
        welcome=WelcomeScreen.show(this,state!=null);
    }
    private void cardLink(LinearLayout box,String name,Class<?> target){
        cardButtons[cardIndex++]=button(box,name+"\n상태 확인 중…",false,v->startActivity(new Intent(this,target)));
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private android.graphics.drawable.GradientDrawable background(int color){
        android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();
        d.setColor(color);d.setCornerRadius(dp(16));return d;
    }
    private TextView label(LinearLayout parent,String value,int size){
        TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(0xff17333b);
        v.setPadding(0,dp(7),0,dp(7));v.setLineSpacing(dp(2),1);parent.addView(v);return v;
    }
    private LinearLayout card(LinearLayout parent){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(12),dp(18),dp(14));box.setBackground(background(Color.WHITE));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(12),0,dp(8));parent.addView(box,p);return box;
    }
    private Button button(LinearLayout parent,String value,boolean primary,View.OnClickListener action){
        Button v=CardUi.button(parent,value,action);CardUi.style(v,primary,false);return v;
    }
    private final Runnable refresh=new Runnable(){public void run(){
        if(!visible)return;
        CardUi.changed(listenerStatus,HanaListener.connected?"알림 서비스 연결됨 · 카드별 수집 상태는 각 카드에서 확인":"알림 접근 연결 확인 필요");
        CardUi.changed(enrollmentStatus,DeviceEnrollment.stageText(MainActivity.this));
        boolean consent=DeviceEnrollment.consented(MainActivity.this);
        permissionAction.setVisibility(!consent||HanaListener.connected?View.GONE:View.VISIBLE);
        sharedPermission.setVisibility(consent?View.VISIBLE:View.GONE);
        CardUiState[] states={CaptureRuntime.uiState(MainActivity.this),KbCaptureRuntime.uiState(MainActivity.this),NhCaptureRuntime.uiState(MainActivity.this),ShinhanCaptureRuntime.uiState(MainActivity.this)};
        for(int i=0;i<states.length;i++)CardUi.changed(cardButtons[i],cardNames[i]+"\n"+states[i].home(HanaListener.connected)+(i==2?"\nNH pay PUSH 대상 · SMS 미지원":""));
        main.postDelayed(this,1500);
    }};
    @Override protected void onResume(){super.onResume();visible=true;
        DiagnosticSync.request(this,false);CaptureRuntime.request(this,false);KbCaptureRuntime.request(this,false);
        NhCaptureRuntime.request(this,false);ShinhanCaptureRuntime.request(this,false);
        main.removeCallbacks(refresh);refresh.run();
    }
    @Override protected void onPause(){visible=false;main.removeCallbacks(refresh);super.onPause();}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);
        if(Intent.ACTION_MAIN.equals(intent.getAction())&&intent.hasCategory(Intent.CATEGORY_LAUNCHER)){
            if(welcome!=null)welcome.finish();welcome=WelcomeScreen.replay(this);
        }
    }
    @Override public void onBackPressed(){if(welcome!=null&&welcome.isShowing()){welcome.finish();welcome=null;}else super.onBackPressed();}
    @Override protected void onDestroy(){if(welcome!=null)welcome.finish();super.onDestroy();}
}
