package kr.household.hanacollector;

/** Minimal immutable wire format. Never includes local card/evidence/name fields. */
public final class KbTransport {
    public static final String PACKAGE="com.kbcard.cxh.appcard";
    public static final String ENDPOINT="https://xcchskngoactqsiiutsp.supabase.co/functions/v1/kb-capture";
    public static final String PROFILE="kb-pay-krw-onetime-v1";
    public static final String ACTIVATE="{\"type\":\"activate\",\"profile\":\""+PROFILE+"\",\"cardConfirmed\":true,\"appVersion\":8}";
    public static String purchase(CaptureOutbox.Item v){
        if(v.card!=CaptureOutbox.Card.KB_COUPANG||v.observedAt<=0||v.cumulative<0)throw new IllegalArgumentException("KB observation required");
        return "{\"id\":\""+v.id+"\",\"type\":\"purchase\",\"amount\":"+v.amount+",\"occurredAt\":\""+java.time.Instant.ofEpochMilli(v.occurredAt)+"\",\"observedAt\":\""+java.time.Instant.ofEpochMilli(v.observedAt)+"\",\"cumulative\":"+v.cumulative+",\"profile\":\""+PROFILE+"\"}";
    }
    private KbTransport(){}
}
