package kr.household.hanacollector;

import android.app.Activity;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import java.time.LocalDate;
import java.util.Map;

/** Screenshot-friendly summary. Only confirmed daily aggregates enter this window. */
public final class NhDailyAmountsActivity extends Activity {
    private LinearLayout rows;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 33) setRecentsScreenshotEnabled(false);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll = new ScrollView(this);
        scroll.setId(5202);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xfff7f3eb);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        int padding = CardUi.dp(this, 20);
        page.setOnApplyWindowInsetsListener((view, insets) -> {
            Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            view.setPadding(padding + bars.left, padding + bars.top, padding + bars.right, padding + bars.bottom);
            return insets;
        });
        scroll.addView(page);
        setContentView(scroll);
        CardUi.button(page, "← 농협", v -> finish());
        CardUi.heading(page, "농협 일별 합계", 24);
        CardUi.text(page, "이 폰에서 전송이 확인된 최근 31일 · 한국시간", 15);
        CardUi.text(page, "원승인일 기준이에요. 연결된 취소를 빼고, 할부와 직접 입력한 금액은 제외해요.", 14);
        rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        page.addView(rows);
    }

    @Override protected void onResume() {
        super.onResume();
        rows.removeAllViews();
        Map<Long,long[]> days;
        try {
            days = NhCaptureRuntime.confirmedDays(this);
        } catch (Exception unavailable) {
            CardUi.text(rows, "반영액을 읽을 수 없어요. 농협 화면에서 연결 상태를 확인해 주세요.", 16);
            return;
        }
        if (days.isEmpty()) {
            CardUi.text(rows, "이 기간에 전송이 확인된 기록이 없어요. 사용액 0원을 뜻하지 않아요.", 16);
        }
        for (Map.Entry<Long,long[]> entry : days.entrySet()) {
            long approved = entry.getValue()[0], refunded = entry.getValue()[1];
            LinearLayout day = CardUi.card(rows);
            CardUi.heading(day, LocalDate.ofEpochDay(entry.getKey()).toString(), 16);
            CardUi.text(day, "순반영액 " + NhCaptureAudit.money(approved - refunded), 20);
            CardUi.text(day, "승인 " + NhCaptureAudit.money(approved) + " · 취소 " + NhCaptureAudit.money(refunded), 14);
        }
    }
}
