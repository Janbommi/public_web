package kr.household.hanacollector;

import android.content.Context;
import android.app.job.*;
import android.content.ComponentName;
import android.security.keystore.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/** Serial local capture; only normalized purchase fields reach the outbox. */
final class ShinhanCaptureRuntime {
    static final String PROFILE="shinhan-pay-krw-onetime-v1";
    static final int JOB=5110;
    private static final java.util.concurrent.ExecutorService worker=Executors.newSingleThreadExecutor();
    private static String currentNamespace;private static Session cached;
    private static final java.util.Map<String,Session> sessions=new java.util.HashMap<>();
    private static String failure="";
    static volatile boolean jobRunning=false;
    static final class Session {
        final String token,namespace;final EncryptedOutboxStore configStore;final CaptureOutbox queue;
        JSONObject config;
        Session(String token,String ns,Context c)throws Exception {
            this.token=token;namespace=ns;
            KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);String alias="household-shinhan-capture-"+ns;
            if(!ks.containsAlias(alias)){
                KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
                g.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();
            }
            javax.crypto.SecretKey key=(javax.crypto.SecretKey)ks.getKey(alias,null);
            Path dir=c.getNoBackupFilesDir().toPath();
            configStore=new EncryptedOutboxStore(dir.resolve("shinhan-capture-"+ns+"-config.bin"),key);
            byte[] old=configStore.read();config=old==null?new JSONObject():new JSONObject(new String(old,StandardCharsets.UTF_8));
            queue=new CaptureOutbox(new EncryptedOutboxStore(dir.resolve("shinhan-capture-"+ns+"-outbox.bin"),key));
        }
        void save(JSONObject next)throws Exception {configStore.commit(next.toString().getBytes(StandardCharsets.UTF_8));config=next;}
        JSONObject copy()throws Exception{return new JSONObject(config.toString());}
    }
    private static String hex(byte[] bytes){StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format("%02x",b&255));return s.toString();}
    static synchronized Session session(Context c)throws Exception {
        String token=ShinhanTokenVault.load(c);if(token==null)return null;
        String ns=hex(MessageDigest.getInstance("SHA-256").digest(token.getBytes(StandardCharsets.UTF_8)));
        if(cached==null||!ns.equals(currentNamespace)){cached=sessions.get(ns);if(cached==null){cached=new Session(token,ns,c);sessions.put(ns,cached);}currentNamespace=ns;}return cached;
    }
    private static String digest(Session s,String value)throws Exception {
        Mac mac=Mac.getInstance("HmacSHA256");mac.init(new SecretKeySpec(s.token.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));return hex(mac.doFinal(("shinhan-capture-local-v1|"+value).getBytes(StandardCharsets.UTF_8)));
    }
    static boolean hasKey(Context c){try{return ShinhanTokenVault.load(c)!=null;}catch(Exception e){return false;}}
    static synchronized void unsupported(){failure="신한 알림을 받았지만 지원 형식이 아니거나 내용이 가려져 있어요. 금액은 전송하지 않았습니다.";}
    static void observed(Context context,AdditionalPushParser.Result parsed,String notificationKey,long postedAt){
        final Context c=context.getApplicationContext();
        final String observedToken;try{observedToken=ShinhanTokenVault.load(c);}catch(Exception e){return;}
        worker.execute(()->{synchronized(ShinhanCaptureRuntime.class){try{
            Session s=session(c);if(s==null||parsed==null||parsed.issuer!=AdditionalPushParser.Issuer.SHINHAN)return;
            if(!s.token.equals(observedToken))return;
            long now=System.currentTimeMillis();
            if(parsed.occurredAt<now-CaptureOutbox.MAX_AGE||parsed.occurredAt>now+300000L||postedAt>now+300000L||postedAt<parsed.occurredAt-300000L||postedAt>parsed.occurredAt+172800000L)return;
            // Notification key + original posted time identifies a delivery, not a bank approval.
            String receipt=digest(s,"receipt|"+notificationKey+"|"+postedAt);
            String evidence=digest(s,"shinhan|"+parsed.cardDisplay+"|"+parsed.amount+"|"+parsed.occurredAt+"|"+parsed.cumulative);
            JSONObject candidate=new JSONObject().put("mask",parsed.cardDisplay).put("amount",parsed.amount).put("occurred",parsed.occurredAt).put("receipt",receipt).put("evidence",evidence).put("saved",now).put("cumulative",parsed.cumulative).put("observed",postedAt);
            if(!s.config.has("mask")) {JSONObject next=s.copy();next.put("candidate",candidate);s.save(next);}
            else if(s.config.optString("mask").equals(parsed.cardDisplay)&&s.config.optBoolean("enabled",false)){
                s.queue.observeShinhan(receipt,evidence,parsed.amount,parsed.occurredAt,postedAt,parsed.cumulative,now);
            }
            failure="";schedule(c,s);
        }catch(Exception e){failure="결제 저장을 확인하지 못했습니다. 앱에서 상태를 확인해 주세요.";}}});
    }
    static synchronized String confirmText(Context c){try{
        Session s=session(c);if(s==null)return "기존 연결 키가 필요합니다.";
        if(s.config.has("mask"))return "확인한 신한카드 "+s.config.optString("mask")+" · "+(s.config.optBoolean("enabled",false)?"자동 집계 켜짐":"자동 집계 꺼짐");
        JSONObject v=s.config.optJSONObject("candidate");if(v==null||System.currentTimeMillis()-v.optLong("saved")>CaptureOutbox.MAX_AGE)return "새 신한 SOL페이 일시불 알림을 기다립니다. 다음 평소 결제 후 이 화면을 열어 주세요.";
        return "신한카드 "+v.optString("mask")+" · "+v.optLong("amount")+"원 · 누적 "+v.optLong("cumulative")+"원\n"+java.time.Instant.ofEpochMilli(v.optLong("occurred")).atZone(java.time.ZoneId.of("Asia/Seoul"))+"\n이 알림이 본인 K-패스 결제인지 확인해 주세요.";
    }catch(Exception e){return "카드 확인 정보를 읽지 못했습니다.";}}
    static synchronized String candidateId(Context c)throws Exception {
        Session s=session(c);JSONObject v=s==null?null:s.config.optJSONObject("candidate");if(v==null)throw new IllegalStateException();return v.getString("receipt")+v.getString("evidence");
    }
    static synchronized void confirm(Context c,String expected)throws Exception {
        Session s=session(c);if(s==null)throw new IllegalStateException();JSONObject v=s.config.optJSONObject("candidate");
        if(v==null||System.currentTimeMillis()-v.optLong("saved")>CaptureOutbox.MAX_AGE)throw new IllegalStateException();
        if(!candidateId(c).equals(expected))throw new IllegalStateException();
        JSONObject next=s.copy();next.put("mask",v.getString("mask")).put("enabled",true).put("activationAttempts",0);
        // Persist the queue first. Repeated confirmation will reuse the same purchase id.
        s.queue.observeShinhan(v.getString("receipt"),v.getString("evidence"),v.getLong("amount"),v.getLong("occurred"),v.getLong("observed"),v.getLong("cumulative"),System.currentTimeMillis());
        next.remove("candidate");s.save(next);schedule(c,s);
    }
    static synchronized void enabled(Context c,boolean value)throws Exception {
        Session s=session(c);if(s==null||!s.config.has("mask"))throw new IllegalStateException();JSONObject next=s.copy();next.put("enabled",value).put("activationAttempts",0);s.save(next);
        if(value)schedule(c,s);else c.getSystemService(JobScheduler.class).cancel(JOB);
    }
    static synchronized void request(Context c,boolean retry){try{
        Session s=session(c);if(s==null)return;
        if(retry){s.queue.retryBlocked(System.currentTimeMillis());JSONObject next=s.copy();next.put("activationAttempts",0);s.save(next);}
        schedule(c,s);
    }catch(Exception e){failure="결제 전송 예약을 확인하지 못했습니다.";}}
    static synchronized void keyChanged(Context c){c.getSystemService(JobScheduler.class).cancel(JOB);cached=null;currentNamespace=null;failure="";}
    static synchronized boolean valid(Context c,Session s){try{return s!=null&&s==session(c)&&s.config.optBoolean("enabled",false);}catch(Exception e){return false;}}
    private static void schedule(Context c,Session s)throws Exception {
        if(jobRunning||!s.config.optBoolean("enabled",false)||s.config.optInt("activationAttempts",0)>=5)return;
        long now=System.currentTimeMillis(),due=s.queue.nextDue(now);if(due==Long.MAX_VALUE)return;
        long activationDelay=30000L*(1L<<Math.min(s.config.optInt("activationAttempts",0),4));
        JobInfo job=new JobInfo.Builder(JOB,new ComponentName(c,ShinhanCaptureUploadJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(Math.max(activationDelay,due-now)).setEstimatedNetworkBytes(8192,8192).build();
        if(c.getSystemService(JobScheduler.class).schedule(job)!=JobScheduler.RESULT_SUCCESS)throw new IllegalStateException();
    }
    static synchronized void activationAttempt(Session s)throws Exception {JSONObject next=s.copy();next.put("activationAttempts",next.optInt("activationAttempts",0)+1);s.save(next);}
    static synchronized void activated(Session s){s.queue.verify(CaptureOutbox.Card.SHINHAN_KPASS);}
    static synchronized void delivered(Session s)throws Exception {JSONObject next=s.copy();next.put("activationAttempts",0);s.save(next);}
    static synchronized boolean confirmed(Context c){try{Session s=session(c);return s!=null&&s.config.has("mask");}catch(Exception e){return false;}}
    static synchronized int[] counts(Context c){try{Session s=session(c);if(s==null)return null;int done=0,pending=0,review=0,blocked=0;
        for(CaptureOutbox.Item v:s.queue.snapshot())if(v.state==CaptureOutbox.State.ACKNOWLEDGED)done++;else if(v.state==CaptureOutbox.State.REVIEW)review++;else if(v.state==CaptureOutbox.State.BLOCKED||v.attempts>=5)blocked++;else pending++;return new int[]{done,pending,review,blocked};}catch(Exception e){return null;}}
    static synchronized String status(Context c){try{
        Session s=session(c);if(s==null)return "연결 키를 먼저 저장해 주세요.";
        int[] values=counts(c);if(values==null)throw new IllegalStateException();int done=values[0],pending=values[1],review=values[2],blocked=values[3];
        return (failure.isEmpty()?"":failure+"\n")+"서버 반영 "+done+"건\n전송 대기 "+pending+"건"+(review>0?"\n확인 필요 "+review+"건":"")+(blocked>0?" · 재시도 필요 "+blocked+"건":"")+(s.config.optInt("activationAttempts",0)>=5?"\n서버 시작 확인이 보류됐습니다. 전송 다시 시도를 눌러 주세요.":"");
    }catch(Exception e){return "암호화된 결제 기록을 읽지 못했습니다. 앱 데이터를 삭제하지 말고 알려주세요.";}}
    private ShinhanCaptureRuntime(){}
}
