package kr.household.hanacollector;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import org.json.JSONObject;

/** Local pairing candidates contain only opaque references and normalized facts. */
final class ReferencedCapture {
    private static final DateTimeFormatter KST =
            DateTimeFormatter.ofPattern("uuuu-MM-dd'T'HH:mm:ssXXX", java.util.Locale.ROOT).withZone(ZoneId.of("Asia/Seoul"));

    interface SaveCandidate { void save(JSONObject candidate) throws Exception; }

    static CaptureOutbox.Item record(CaptureOutbox queue, CaptureOutbox.Card card, JSONObject config,
                       ReferencedPushParser.Result event, String receipt, String evidence,
                       long postedAt, long now, SaveCandidate saveCandidate) throws Exception {
        if(event.occurredAt<now-CaptureOutbox.MAX_AGE||event.occurredAt>now+300000L||postedAt>now+300000L)return null;
        boolean confirmed=config.has("mask");
        if(confirmed&&(!config.optBoolean("enabled",false)||!config.optString("mask").equals(event.cardDisplay)))return null;
        if(event.refund){
            if(!confirmed)throw new IllegalStateException("Card confirmation required");
            return queue.observeRefund(card,receipt,evidence,event.id,event.originalId,event.amount,event.occurredAt,now);
        } else {
            JSONObject candidate=purchaseCandidate(event,receipt,evidence,postedAt,now);
            if(confirmed)return enqueuePurchase(queue,card,candidate,now);
            else saveCandidate.save(candidate);
        }
        return null;
    }

    static JSONObject purchaseCandidate(ReferencedPushParser.Result event, String receipt, String evidence,
                                        long postedAt, long now) throws Exception {
        JSONObject candidate=new JSONObject().put("mask",event.cardDisplay).put("amount",event.amount)
                .put("occurred",event.occurredAt).put("receipt",receipt).put("evidence",evidence)
                .put("saved",now).put("cumulative",event.cumulative).put("observed",postedAt)
                .put("purchaseRef",event.id);
        if(!event.telecomKind.isEmpty())candidate.put("telecomKind",event.telecomKind);
        return candidate;
    }

    static CaptureOutbox.Item enqueuePurchase(CaptureOutbox queue, CaptureOutbox.Card card, JSONObject candidate, long now) throws Exception {
        return queue.observeReferenced(card, candidate.getString("receipt"), candidate.getString("evidence"),
                candidate.getString("purchaseRef"), candidate.getLong("amount"), candidate.getLong("occurred"),
                candidate.getLong("observed"), candidate.getLong("cumulative"), now,candidate.optString("telecomKind",""));
    }

    static String refundBody(CaptureOutbox queue, CaptureOutbox.Item refund, String profile) throws Exception {
        CaptureOutbox.Item parent = queue.parentFor(refund);
        if (parent == null) throw new IllegalStateException("Original is unavailable");
        return new JSONObject().put("id",refund.id).put("type","refund").put("profile",profile)
                .put("amount",refund.amount).put("occurredAt",KST.format(Instant.ofEpochMilli(refund.occurredAt)))
                .put("originalId",parent.id).put("originalAmount",parent.amount)
                .put("originalOccurredAt",KST.format(Instant.ofEpochMilli(parent.occurredAt))).toString();
    }

    private ReferencedCapture() {}
}
