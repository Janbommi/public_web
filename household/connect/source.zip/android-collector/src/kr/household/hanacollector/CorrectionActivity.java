package kr.household.hanacollector;

import android.app.*;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.time.*;
import java.util.*;

/** User-confirmed monthly correction; never a claim of automatic transaction matching. */
public final class CorrectionActivity extends Activity {
    private String card;private LinearLayout box;private Spinner month,kind;private EditText amount;private CheckBox confirmed;private Button preview,recover;
    private TextView status;private boolean busy,visible;private final Handler main=new Handler(Looper.getMainLooper());
    interface Action{String run()throws Exception;}
    @Override public void onCreate(Bundle saved){super.onCreate(saved);
        card=getIntent().getStringExtra("card");try{CorrectionRuntime.title(card);}catch(Exception e){finish();return;}
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(0xfff7f3eb);box=new LinearLayout(this);box.setOrientation(1);int pad=(int)(20*getResources().getDisplayMetrics().density);box.setPadding(pad,pad,pad,pad);scroll.addView(box);setContentView(scroll);
        box.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets b=i.getInsets(WindowInsets.Type.systemBars());v.setPadding(pad,pad+b.top,pad,pad+b.bottom);return i;});
        CardUi.button(box,"← 카드로",v->finish());text(CorrectionRuntime.title(card),16);text("해외 결제·취소 보완",24).setAccessibilityHeading(true);
        text("취소·해외 결제 자동 반영은 실제 알림 검증 전입니다. 카드사에서 확인한 금액으로 월 합계를 직접 정정합니다. 거래내역은 서버에 새로 저장하지 않아요.",14);
        text("보완할 내용",14);kind=spinner(new String[]{"해외 결제 추가","취소 금액 차감"});kind.setId(4101);
        text("반영할 월 · 취소는 원결제 월",14);List<String> months=new ArrayList<>();YearMonth current=YearMonth.now(ZoneId.of("Asia/Seoul"));for(int i=0;i<12;i++)months.add(current.minusMonths(i).toString());month=spinner(months.toArray(new String[0]));month.setId(4102);
        text("카드사에서 확인한 원화 금액",14);amount=new EditText(this);amount.setId(4103);amount.setSingleLine(true);amount.setInputType(InputType.TYPE_CLASS_NUMBER);amount.setHint("예: 12000");amount.setTextSize(18);box.addView(amount);
        text("외화만 표시되면 원화 확정 후 입력해 주세요. 환율을 추정해서 입력하지 마세요. 시작 전 거래나 다른 카드의 금액을 취소로 빼면 안 됩니다.",13);
        confirmed=new CheckBox(this);confirmed.setTextColor(0xff17333b);confirmed.setTextSize(14);box.addView(confirmed);
        kind.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){confirmed.setChecked(false);confirmed.setText(pos==0?"원화 확정액이며, 아직 이 월 합계에 포함되지 않은 금액입니다.":"원결제가 이 월 합계에 포함되어 있고, 이 취소액은 아직 차감하지 않았습니다.");}});
        text("원결제·중복 여부가 확실하지 않으면 반영하지 마세요. 같은 취소를 새 요청으로 다시 입력하면 중복 차감될 수 있어요.",13);
        preview=CardUi.button(box,"변경할 합계 확인",v->preview());CardUi.style(preview,true,false);
        status=text("",14);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        recover=CardUi.button(box,"이전 정정 반영 확인",v->run(()->CorrectionRuntime.recover(this,card)));
    }
    private TextView text(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(0xff17333b);v.setPadding(0,12,0,12);box.addView(v);return v;}
    private Spinner spinner(String[] values){Spinner s=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,values);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(adapter);box.addView(s);return s;}
    private void preview(){
        if(busy)return;if(!confirmed.isChecked()){status.setText("합계 포함 여부와 원화 금액을 먼저 확인해 주세요.");return;}
        final long value;try{String input=amount.getText().toString().trim();if(!input.matches("[1-9][0-9]{0,9}"))throw new Exception();value=Long.parseLong(input);if(value>1000000000L)throw new Exception();}catch(Exception e){status.setText("1원부터 10억 원까지 숫자로 입력해 주세요.");return;}
        final String selectedMonth=month.getSelectedItem().toString(),selectedKind=kind.getSelectedItemPosition()==0?"foreign":"cancellation";
        busy=true;refresh();status.setText("현재 합계 확인 중…");
        new Thread(()->{try{JSONObject base=CorrectionRuntime.snapshot(this,card,selectedMonth);long before=base.getLong("amount"),after=before+(selectedKind.equals("foreign")?value:-value);if(after<0)throw new Exception("취소액이 현재 월 합계보다 커요. 원결제 월과 금액을 확인해 주세요.");
            main.post(()->{busy=false;if(!visible||isFinishing())return;refresh();new AlertDialog.Builder(this).setTitle("월 합계를 정정할까요?").setMessage(selectedMonth+" · "+CorrectionRuntime.title(card)+"\n\n현재 "+before+"원\n"+(selectedKind.equals("foreign")?"추가 +":"취소 -")+value+"원\n변경 후 "+after+"원\n\n사용자가 확인한 월 합계 정정입니다.").setNegativeButton("돌아가기",null).setPositiveButton("확인하고 반영",(d,w)->run(()->CorrectionRuntime.apply(this,card,selectedMonth,selectedKind,value,base))).show();});
        }catch(Exception e){main.post(()->{busy=false;if(visible&&!isFinishing()){status.setText(message(e));refresh();}});}},"correction-preview").start();
    }
    private static String message(Exception e){return e.getMessage()==null?"확인하지 못했어요. 입력을 유지했으니 다시 확인해 주세요.":e instanceof java.net.SocketTimeoutException?"응답을 확인하지 못했어요. 이전 정정 반영 확인을 눌러 주세요.":e.getMessage();}
    private void run(Action action){if(busy)return;busy=true;refresh();status.setText("반영 여부 확인 중…");new Thread(()->{String result;try{result=action.run();}catch(Exception e){result=message(e);}String output=result;main.post(()->{busy=false;if(visible&&!isFinishing()){status.setText(output);confirmed.setChecked(false);refresh();}});},"correction-send").start();}
    private void refresh(){boolean pending=true;try{pending=CorrectionRuntime.pending(this,card);}catch(Exception e){status.setText(message(e));}
        preview.setEnabled(!busy&&!pending);recover.setEnabled(!busy&&pending);recover.setVisibility(pending?View.VISIBLE:View.GONE);for(View v:new View[]{kind,month,amount,confirmed})v.setEnabled(!busy&&!pending);
    }
    @Override protected void onResume(){super.onResume();visible=true;if(card==null||status==null)return;try{String s=CorrectionRuntime.pendingText(this,card);if(!s.isEmpty())status.setText(s);}catch(Exception e){status.setText(message(e));}refresh();}
    @Override protected void onPause(){visible=false;super.onPause();}
}
