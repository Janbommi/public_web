package kr.household.hanacollector;

/** Pure retry policy; no credentials, finance data or Android dependencies. */
public final class DiagnosticSyncState {
    public boolean enabled=true,blocked=false;
    public long generation=0,acknowledged=0,keyEpoch=0,lastSuccess=0;
    public int attempts=0;
    public void changed(boolean retry){generation++;attempts=0;if(retry)blocked=false;}
    public void keyChanged(){keyEpoch++;changed(true);}
    public boolean canRun(){return enabled&&!blocked&&generation>acknowledged&&attempts<5;}
    public long delayMs(){return 30000L*(1L<<Math.min(attempts,4));}
    public void completed(long sentGeneration,long sentEpoch,int code,long now){
        if(sentEpoch!=keyEpoch)return;
        if(code==200){acknowledged=Math.max(acknowledged,sentGeneration);lastSuccess=now;}
        else if(code>=400&&code<500&&code!=408&&code!=429)blocked=true;
    }
}
