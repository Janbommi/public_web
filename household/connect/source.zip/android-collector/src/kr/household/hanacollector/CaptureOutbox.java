package kr.household.hanacollector;

import java.io.*;
import java.util.*;

/** Durable purchase outbox.
 * Store implementations MUST encrypt at rest and atomically commit before returning.
 * Receipt/evidence keys are local keyed digests; neither is a financial transaction ID.
 */
public final class CaptureOutbox {
    public interface Store { byte[] read() throws IOException; void commit(byte[] value) throws IOException; }
    public enum Card { HANA_MOVING, NH_ZGM, KB_COUPANG, SHINHAN_KPASS, SAMSUNG_FAMILY }
    public enum State { WAITING_VERIFICATION, READY, SENDING, RETRY, ACKNOWLEDGED, REVIEW, BLOCKED, WAITING_ORIGINAL }
    public enum Outcome { ACCEPTED, DUPLICATE, RETRYABLE, UNAUTHORIZED, CONFLICT, INVALID }
    public static final int LIMIT=2048,MAX_ATTEMPTS=5;
    public static final long MAX_AGE=7L*24*60*60*1000;
    public static final class Item {
        public final String id,receiptKey,evidenceKey,possibleDuplicateOf;
        public final Card card;
        public final String purchaseReference,telecomKind;
        public final boolean refund;
        public final long amount,occurredAt,observedAt,cumulative;
        public final State state;
        public final int attempts;
        public final long nextAttempt;
        private Item(String id,String receipt,String evidence,Card card,long amount,long occurred,State state,int attempts,long next,String duplicate,long observed,long cumulative,String reference,boolean refund,String telecom){
            this.purchaseReference=reference;this.refund=refund;this.telecomKind=telecom;
            this.id=id;receiptKey=receipt;evidenceKey=evidence;this.card=card;this.amount=amount;occurredAt=occurred;
            observedAt=observed;this.cumulative=cumulative;
            this.state=state;this.attempts=attempts;nextAttempt=next;possibleDuplicateOf=duplicate;
        }
        private Item move(State state,int attempts,long next){return new Item(id,receiptKey,evidenceKey,card,amount,occurredAt,state,attempts,next,possibleDuplicateOf,observedAt,cumulative,purchaseReference,refund,telecomKind);}
    }
    private final Store store;
    private List<Item> items;
    private final EnumSet<Card> verified=EnumSet.noneOf(Card.class);
    public CaptureOutbox(Store store) throws IOException {
        this.store=Objects.requireNonNull(store);byte[] bytes=store.read();items=decode(bytes);
        // A request may have reached the server before a process exit. Retry the SAME id.
        List<Item> next=new ArrayList<>(items);boolean changed=false;
        for(int i=0;i<next.size();i++){Item v=next.get(i);if(v.state==State.SENDING){next.set(i,v.move(State.RETRY,v.attempts,v.nextAttempt));changed=true;}}
        if(changed)save(next);
        // Verification is deliberately session-local; persisted queues never grant permission.
    }
    public synchronized void verify(Card card){verified.add(Objects.requireNonNull(card));}
    public synchronized void unverify(Card card){verified.remove(card);}
    public synchronized long nextDue(long now){
        long due=Long.MAX_VALUE;
        for(Item v:items)if(v.attempts<MAX_ATTEMPTS&&(!v.refund||parentFor(v)!=null)&&(v.state==State.READY||v.state==State.RETRY||v.state==State.WAITING_VERIFICATION||v.state==State.WAITING_ORIGINAL))due=Math.min(due,Math.max(now,v.nextAttempt));
        return due;
    }
    public synchronized void retryBlocked(long now)throws IOException {
        List<Item> next=new ArrayList<>(items);
        for(int i=0;i<next.size();i++){Item v=next.get(i);if(v.state==State.BLOCKED||v.state==State.RETRY)next.set(i,v.move(State.RETRY,0,now));}
        save(next);
    }
    public synchronized List<Item> snapshot(){return Collections.unmodifiableList(new ArrayList<>(items));}
    private static void key(String value){if(value==null||!value.matches("[a-f0-9]{64}"))throw new IllegalArgumentException("Invalid local evidence key");}
    public synchronized Item observe(Card card,String receipt,String evidence,long amount,long occurred,long now)throws IOException {
        return observe(card,receipt,evidence,amount,occurred,0,-1,now,"");
    }
    public synchronized Item observeKb(String receipt,String evidence,long amount,long occurred,long observed,long cumulative,long now)throws IOException {
        if(cumulative<0||cumulative>100000000000L||observed<=0||observed>now+300000L||observed<occurred-300000L||observed>occurred+172800000L)throw new IllegalArgumentException("Invalid cumulative observation");
        return observe(Card.KB_COUPANG,receipt,evidence,amount,occurred,observed,cumulative,now,"");
    }
    public synchronized Item observeNh(String receipt,String evidence,long amount,long occurred,long observed,long cumulative,long now)throws IOException {
        return observeNh(receipt,evidence,amount,occurred,observed,cumulative,now,"");
    }
    public synchronized Item observeNh(String receipt,String evidence,long amount,long occurred,long observed,long cumulative,long now,String telecom)throws IOException {
        if(cumulative<0||cumulative>100000000000L||observed<=0||observed>now+300000L||observed<occurred-300000L||observed>occurred+172800000L)throw new IllegalArgumentException("Invalid cumulative observation");
        return observe(Card.NH_ZGM,receipt,evidence,amount,occurred,observed,cumulative,now,"",telecom);
    }
    public synchronized Item observeShinhan(String receipt,String evidence,long amount,long occurred,long observed,long cumulative,long now)throws IOException {
        if(cumulative<0||cumulative>100000000000L||observed<=0||observed>now+300000L||observed<occurred-300000L||observed>occurred+172800000L)throw new IllegalArgumentException("Invalid cumulative observation");
        return observe(Card.SHINHAN_KPASS,receipt,evidence,amount,occurred,observed,cumulative,now,"");
    }
    private Item observe(Card card,String receipt,String evidence,long amount,long occurred,long observed,long cumulative,long now,String reference)throws IOException {
        return observe(card,receipt,evidence,amount,occurred,observed,cumulative,now,reference,"");
    }
    private Item observe(Card card,String receipt,String evidence,long amount,long occurred,long observed,long cumulative,long now,String reference,String telecom)throws IOException {
        Objects.requireNonNull(card);key(receipt);key(evidence);
        telecom(card,false,telecom);
        if(now<=0||amount<1||amount>1000000000L||occurred<=0||occurred>now+300000L||occurred<now-MAX_AGE)throw new IllegalArgumentException("Unsupported purchase");
        Item collision=null;
        for(Item old:items){
            if(old.card!=card||old.refund)continue;
            boolean sameValue=old.amount==amount&&old.occurredAt==occurred;
            boolean sameReference=!reference.isEmpty()&&reference.equals(old.purchaseReference);
            if(sameReference&&sameValue&&old.cumulative==cumulative&&old.evidenceKey.equals(evidence))return old;
            if(old.receiptKey.equals(receipt)&&old.evidenceKey.equals(evidence)&&sameValue
                    &&old.observedAt==observed&&old.cumulative==cumulative&&old.purchaseReference.equals(reference))return old;
            // Different deliveries with identical evidence are AMBIGUOUS, never silently merged.
            // Reused delivery identity with changed content is likewise held, never overwritten.
            boolean distinctReferences=!reference.isEmpty()&&!old.purchaseReference.isEmpty()&&!sameReference;
            if(sameReference||old.receiptKey.equals(receipt)||old.evidenceKey.equals(evidence)
                    ||(sameValue&&!distinctReferences))collision=old;
        }
        if(items.size()>=LIMIT)throw new IOException("Capture storage full; no records discarded");
        State state=collision!=null?State.REVIEW:verified.contains(card)?State.READY:State.WAITING_VERIFICATION;
        Item item=new Item(UUID.randomUUID().toString(),receipt,evidence,card,amount,occurred,state,0,now,collision==null?"":collision.id,observed,cumulative,reference,false,telecom);
        List<Item> next=new ArrayList<>(items);next.add(item);save(next);return item;
    }
    private static void uuid(String value) {
        if(value==null||!UUID.fromString(value).toString().equals(value))throw new IllegalArgumentException("Invalid reference");
    }
    public synchronized Item observeReferenced(Card card,String receipt,String evidence,String reference,long amount,
                                                long occurred,long observed,long cumulative,long now)throws IOException {
        return observeReferenced(card,receipt,evidence,reference,amount,occurred,observed,cumulative,now,"");
    }
    public synchronized Item observeReferenced(Card card,String receipt,String evidence,String reference,long amount,
                                                long occurred,long observed,long cumulative,long now,String telecom)throws IOException {
        uuid(reference);
        if(card==Card.HANA_MOVING)return observe(card,receipt,evidence,amount,occurred,0,-1,now,reference,telecom);
        if(card==Card.SAMSUNG_FAMILY||cumulative<0||cumulative>100000000000L||observed<=0||observed>now+300000L
                ||observed<occurred-300000L||observed>occurred+172800000L)throw new IllegalArgumentException("Invalid observation");
        return observe(card,receipt,evidence,amount,occurred,observed,cumulative,now,reference,telecom);
    }
    public synchronized Item observeRefund(Card card,String receipt,String evidence,String refundId,String parentRef,
                                            long amount,long occurred,long now)throws IOException {
        Objects.requireNonNull(card);key(receipt);key(evidence);uuid(refundId);uuid(parentRef);
        if(card==Card.SAMSUNG_FAMILY||refundId.equals(parentRef)||now<=0||amount<1||amount>1000000000L
                ||occurred<=0||occurred>now+300000L||occurred<now-MAX_AGE)throw new IllegalArgumentException("Invalid refund");
        for(int i=0;i<items.size();i++){
            Item old=items.get(i);
            if(!old.id.equals(refundId))continue;
            if(old.refund&&old.card==card&&old.amount==amount&&old.occurredAt==occurred&&old.purchaseReference.equals(parentRef))return old;
            if(old.state!=State.ACKNOWLEDGED){
                List<Item> next=new ArrayList<>(items);next.set(i,old.move(State.REVIEW,old.attempts,now));save(next);
            }
            throw new IllegalArgumentException("Conflicting cancellation reference");
        }
        if(items.size()>=LIMIT)throw new IOException("Capture storage full; no records discarded");
        Item item=new Item(refundId,receipt,evidence,card,amount,occurred,State.WAITING_ORIGINAL,0,now,"",0,-1,parentRef,true,"");
        List<Item> next=new ArrayList<>(items);next.add(item);save(next);return item;
    }
    public synchronized Item parentFor(Item refund){
        if(!refund.refund)return null;
        Item parent=null;
        for(Item v:items){
            if(v.refund||v.card!=refund.card||!v.purchaseReference.equals(refund.purchaseReference))continue;
            if(parent!=null||v.state!=State.ACKNOWLEDGED||v.amount<refund.amount||v.occurredAt>refund.occurredAt)return null;
            parent=v;
        }
        if(parent!=null)for(Item v:items)if(!v.refund&&v.possibleDuplicateOf.equals(parent.id))return null;
        return parent;
    }
    public synchronized Item begin(long now)throws IOException {
        if(now<=0)throw new IllegalArgumentException("Invalid clock");
        for(Item item:items)if(item.state==State.SENDING)return null;
        for(int i=0;i<items.size();i++){
            Item item=items.get(i);
            if(!verified.contains(item.card)||item.attempts>=MAX_ATTEMPTS||item.nextAttempt>now)continue;
            if(item.state!=State.READY&&item.state!=State.RETRY&&item.state!=State.WAITING_VERIFICATION&&item.state!=State.WAITING_ORIGINAL)continue;
            if(item.refund&&parentFor(item)==null)continue;
            Item sending=item.move(State.SENDING,item.attempts+1,now+delay(item.attempts+1));
            List<Item> next=new ArrayList<>(items);next.set(i,sending);save(next);return sending;
        }
        return null;
    }
    public synchronized void complete(String id,int attempt,Outcome outcome,long now)throws IOException {
        Objects.requireNonNull(outcome);if(now<=0)throw new IllegalArgumentException("Invalid clock");
        for(int i=0;i<items.size();i++){
            Item item=items.get(i);if(!item.id.equals(id)||item.attempts!=attempt||item.state!=State.SENDING)continue;
            State target=outcome==Outcome.ACCEPTED||outcome==Outcome.DUPLICATE?State.ACKNOWLEDGED:
                outcome==Outcome.RETRYABLE?State.RETRY:outcome==Outcome.UNAUTHORIZED?State.BLOCKED:State.REVIEW;
            Item result=item.move(target,item.attempts,now+delay(item.attempts));
            List<Item> next=new ArrayList<>(items);next.set(i,result);save(next);
            if(outcome==Outcome.UNAUTHORIZED)verified.remove(item.card);
            return;
        }
    }
    private static long delay(int attempt){return 30000L*(1L<<Math.min(attempt,4));}
    private void save(List<Item> next)throws IOException {store.commit(encode(next));items=next;}
    private static byte[] encode(List<Item> items)throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(4);out.writeInt(items.size());
        for(Item v:items){out.writeUTF(v.id);out.writeUTF(v.receiptKey);out.writeUTF(v.evidenceKey);out.writeUTF(v.card.name());
            out.writeLong(v.amount);out.writeLong(v.occurredAt);out.writeUTF(v.state.name());out.writeInt(v.attempts);out.writeLong(v.nextAttempt);out.writeUTF(v.possibleDuplicateOf);out.writeLong(v.observedAt);out.writeLong(v.cumulative);out.writeUTF(v.purchaseReference);out.writeBoolean(v.refund);out.writeUTF(v.telecomKind);}
        out.close();return bytes.toByteArray();
    }
    private static List<Item> decode(byte[] bytes)throws IOException {
        List<Item> result=new ArrayList<>();if(bytes==null)return result;
        if(bytes.length>1024*1024)throw new IOException("Capture storage too large");
        try(DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes))){
            int version=in.readInt();if(version<1||version>4)throw new IOException("Unsupported capture format");int count=in.readInt();
            if(count<0||count>LIMIT)throw new IOException("Invalid capture count");Set<String> ids=new HashSet<>();
            for(int i=0;i<count;i++){
                String id=in.readUTF(),receipt=in.readUTF(),evidence=in.readUTF();Card card=Card.valueOf(in.readUTF());
                long amount=in.readLong(),occurred=in.readLong();State state=State.valueOf(in.readUTF());int attempts=in.readInt();long next=in.readLong();String duplicate=in.readUTF();
                long observed=version>=2?in.readLong():0,cumulative=version>=2?in.readLong():-1;
                String reference=version>=3?in.readUTF():"";boolean refund=version>=3&&in.readBoolean();
                String telecom=version>=4?in.readUTF():"";telecom(card,refund,telecom);
                if(!reference.isEmpty())uuid(reference);
                if((refund&&(reference.isEmpty()||card==Card.SAMSUNG_FAMILY||observed!=0||cumulative!=-1))
                        ||(!refund&&state==State.WAITING_ORIGINAL))throw new IOException("Invalid refund record");
                boolean supportsCumulative=card==Card.KB_COUPANG||card==Card.NH_ZGM||card==Card.SHINHAN_KPASS;
                if(!((observed==0&&cumulative==-1)||(supportsCumulative&&observed>0&&observed>=occurred-300000L&&observed<=occurred+172800000L&&cumulative>=0&&cumulative<=100000000000L)))throw new IOException("Invalid stored observation");
                if(!UUID.fromString(id).toString().equals(id)||!ids.add(id)||amount<1||amount>1000000000L||occurred<=0||attempts<0||attempts>MAX_ATTEMPTS||next<=0)throw new IOException("Invalid capture record");
                key(receipt);key(evidence);if(!duplicate.isEmpty()&&!UUID.fromString(duplicate).toString().equals(duplicate))throw new IOException("Invalid reference");
                result.add(new Item(id,receipt,evidence,card,amount,occurred,state,attempts,next,duplicate,observed,cumulative,reference,refund,telecom));
            }
            if(in.available()!=0)throw new IOException("Unexpected capture data");return result;
        }catch(IllegalArgumentException e){throw new IOException("Invalid capture storage");}
    }
    private static void telecom(Card card,boolean refund,String value){
        if(value==null||(!value.isEmpty()&&(card!=Card.NH_ZGM||refund||!value.matches("mobile|internet|other|unknown"))))throw new IllegalArgumentException("Invalid telecom classification");
    }
}
