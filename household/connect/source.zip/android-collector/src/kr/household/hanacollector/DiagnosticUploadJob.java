package kr.household.hanacollector;

import android.app.job.*;
import android.os.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.HttpsURLConnection;

public final class DiagnosticUploadJob extends JobService {
    private final Handler main=new Handler(Looper.getMainLooper());
    private DiagnosticSync.Run running;
    private JobParameters runningParams;
    @Override public boolean onStartJob(JobParameters params){
        final DiagnosticSync.Run run=DiagnosticSync.begin(this);if(run==null)return false;running=run;runningParams=params;
        new Thread(()->{final int code=upload(params,run);main.post(()->DiagnosticSync.finish(this,run,code,()->jobFinished(params,false)));},"hana-diagnostic-upload").start();
        return true;
    }
    private int upload(JobParameters params,DiagnosticSync.Run run){
        HttpsURLConnection c=null;
        try{
            if(run.stopped||!DiagnosticSync.enabled(this))return 503;
            String token=TokenVault.load(this);if(token==null)return 401;
            byte[] data=DiagnosticStore.uploadJson(this).getBytes(StandardCharsets.UTF_8);
            if(data.length>1024)return 422;
            if(params.getNetwork()==null)return 503;
            c=(HttpsURLConnection)params.getNetwork().openConnection(new URL(CapturePolicy.ENDPOINT));run.connection=c;
            c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(10000);
            c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+token);
            c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Cache-Control","no-store");
            c.setFixedLengthStreamingMode(data.length);c.setDoOutput(true);
            if(run.stopped||!DiagnosticSync.enabled(this))return 503;
            try(java.io.OutputStream out=c.getOutputStream()){out.write(data);}
            int code=c.getResponseCode();if(code!=200)return code;
            byte[] response;
            try(java.io.InputStream in=c.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){
                byte[] b=new byte[256];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>1024)return 503;}response=out.toByteArray();
            }
            return !run.stopped&&"diagnostic_received".equals(new org.json.JSONObject(new String(response,StandardCharsets.UTF_8)).optString("status"))?200:503;
        }catch(Exception e){return 503;}
        finally{run.connection=null;if(c!=null)c.disconnect();}
    }
    @Override public boolean onStopJob(JobParameters params){
        DiagnosticSync.Run run=running;if(run!=null&&runningParams==params){run.stop();DiagnosticSync.finish(this,run,503,()->{});}return false;
    }
}
