package kr.household.hanacollector;

import android.app.job.*;
import android.os.*;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public final class ShinhanCaptureUploadJob extends JobService {
    private static Run active;
    private Run owned;
    private final Handler main=new Handler(Looper.getMainLooper());
    private static final class Run {
        final JobParameters params;volatile boolean stopped;volatile HttpsURLConnection connection;
        volatile ShinhanCaptureRuntime.Session session;volatile CaptureOutbox.Item item;
        Run(JobParameters p){params=p;}
        void stop(){stopped=true;HttpsURLConnection c=connection;if(c!=null)c.disconnect();}
    }
    private static final class Reply {final int code;final String status;Reply(int code,String status){this.code=code;this.status=status;}}
    @Override public boolean onStartJob(JobParameters p){
        final Run run;
        synchronized(ShinhanCaptureUploadJob.class){if(active!=null)return false;run=new Run(p);active=run;owned=run;ShinhanCaptureRuntime.jobRunning=true;}
        new Thread(()->{try{drain(run);}finally{main.post(()->finish(run,true));}},"shinhan-purchase-upload").start();return true;
    }
    private Reply send(Run run,String token,String body){
        HttpsURLConnection c=null;
        try{
            if(run.stopped||run.params.getNetwork()==null||!ShinhanCaptureRuntime.valid(this,run.session))return new Reply(503,"");
            byte[] bytes=body.getBytes(StandardCharsets.UTF_8);if(bytes.length>2048)return new Reply(422,"");
            c=(HttpsURLConnection)run.params.getNetwork().openConnection(new URL(ShinhanTransport.ENDPOINT));run.connection=c;
            c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setRequestMethod("POST");
            c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Cache-Control","no-store");c.setFixedLengthStreamingMode(bytes.length);c.setDoOutput(true);
            if(run.stopped||!ShinhanCaptureRuntime.valid(this,run.session))return new Reply(503,"");
            try(java.io.OutputStream out=c.getOutputStream()){out.write(bytes);}
            int code=c.getResponseCode();if(code!=200)return new Reply(code,"");
            try(java.io.InputStream in=c.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){
                byte[] buffer=new byte[256];int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>2048)return new Reply(503,"");}
                return new Reply(200,new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8)).optString("status"));
            }
        }catch(Exception e){return new Reply(503,"");}finally{run.connection=null;if(c!=null)c.disconnect();}
    }
    private void drain(Run run){
        try{
            ShinhanCaptureRuntime.Session s=ShinhanCaptureRuntime.session(this);run.session=s;
            if(run.stopped||!ShinhanCaptureRuntime.valid(this,s))return;
            ShinhanCaptureRuntime.activationAttempt(s);
            Reply activation=send(run,s.token,ShinhanTransport.ACTIVATE);
            if(activation.code!=200||!"capture_enabled".equals(activation.status))return;
            ShinhanCaptureRuntime.activated(s);
            for(int count=0;count<8&&!run.stopped&&ShinhanCaptureRuntime.valid(this,s);count++){
                CaptureOutbox.Item item=s.queue.begin(System.currentTimeMillis());run.item=item;if(item==null)return;
                Reply result;
                if(run.stopped)result=new Reply(503,"");
                else result=send(run,s.token,ShinhanTransport.purchase(item));
                CaptureOutbox.Outcome outcome=result.code==200&&"accepted".equals(result.status)?CaptureOutbox.Outcome.ACCEPTED:
                    result.code==200&&"duplicate".equals(result.status)?CaptureOutbox.Outcome.DUPLICATE:
                    result.code==401?CaptureOutbox.Outcome.UNAUTHORIZED:result.code==409?CaptureOutbox.Outcome.CONFLICT:
                    result.code>=400&&result.code<500&&result.code!=408&&result.code!=429?CaptureOutbox.Outcome.INVALID:CaptureOutbox.Outcome.RETRYABLE;
                s.queue.complete(item.id,item.attempts,outcome,System.currentTimeMillis());run.item=null;
                if(outcome!=CaptureOutbox.Outcome.ACCEPTED&&outcome!=CaptureOutbox.Outcome.DUPLICATE)return;
                ShinhanCaptureRuntime.delivered(s);
            }
        }catch(Exception e){/* No credentials, payment fields or raw errors are logged. */}
        finally{
            try{if(run.session!=null&&run.item!=null)run.session.queue.complete(run.item.id,run.item.attempts,CaptureOutbox.Outcome.RETRYABLE,System.currentTimeMillis());}catch(Exception ignored){}
        }
    }
    private void finish(Run run,boolean notifyOs){
        synchronized(ShinhanCaptureUploadJob.class){if(active!=run)return;active=null;ShinhanCaptureRuntime.jobRunning=false;}
        if(notifyOs)jobFinished(run.params,false);ShinhanCaptureRuntime.request(this,false);
    }
    @Override public boolean onStopJob(JobParameters p){Run run=owned;if(run!=null&&run.params==p){run.stop();
        try{if(run.session!=null&&run.item!=null)run.session.queue.complete(run.item.id,run.item.attempts,CaptureOutbox.Outcome.RETRYABLE,System.currentTimeMillis());}catch(Exception ignored){}
        finish(run,false);
    }return false;}
}
