package kr.household.hanacollector;

/** Minimal immutable wire format. Never includes local card/evidence/name fields. */
public final class ShinhanTransport {
    public static final String PACKAGE="com.shcard.smartpay";
    public static final String ENDPOINT="https://xcchskngoactqsiiutsp.supabase.co/functions/v1/collector-capture";
    public static final String PROFILE="shinhan-pay-krw-onetime-v1";
    public static final String ACTIVATE="{\"type\":\"activate\",\"profile\":\""+PROFILE+"\",\"cardConfirmed\":true,\"appVersion\":15}";
    public static String purchase(CaptureOutbox.Item v){
        if(v.card!=CaptureOutbox.Card.SHINHAN_KPASS||v.observedAt<=0||v.cumulative<0)throw new IllegalArgumentException("신한 observation required");
        return "{\"id\":\""+v.id+"\",\"type\":\"purchase\",\"amount\":"+v.amount+",\"occurredAt\":\""+java.time.Instant.ofEpochMilli(v.occurredAt)+"\",\"profile\":\""+PROFILE+"\"}";
    }
    private ShinhanTransport(){}
}
