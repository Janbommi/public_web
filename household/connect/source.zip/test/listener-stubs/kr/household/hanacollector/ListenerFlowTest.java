package kr.household.hanacollector;

import android.app.Notification;
import android.os.Bundle;
import android.os.SystemClock;
import android.content.Context;
import android.service.notification.StatusBarNotification;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

/** Runs real listener/parser/store code against narrow Android API test doubles. */
public final class ListenerFlowTest {
    private static final long POSTED=java.time.Instant.parse("2026-10-18T03:35:00Z").toEpochMilli();
    private static final String BODY="가상 상점 / 신용(일시불,1*2*) / 10.18 12:34 / 누적이용금액 987,654원";
    private static void check(boolean condition,String why){if(!condition)throw new AssertionError(why);}
    private static StatusBarNotification notification(String pkg,boolean summary,boolean ongoing,boolean big){
        Notification n=new Notification();n.flags=summary?Notification.FLAG_GROUP_SUMMARY:0;
        n.extras.putCharSequence(Notification.EXTRA_TITLE,"(결제) 12,345원");
        n.extras.putCharSequence(big?Notification.EXTRA_BIG_TEXT:Notification.EXTRA_TEXT,BODY);
        return new StatusBarNotification(pkg,n,ongoing,POSTED);
    }
    private static int count(Context c){return DiagnosticHistory.decode(c.getSharedPreferences("hana_diagnostics",0).getString("history_v1",null),System.currentTimeMillis()).size();}
    public static void main(String[] args)throws Exception {
        HanaListener service=new HanaListener();
        if(args[0].equals("restore")){
            check(!HanaListener.connected,"new JVM starts without a live service connection");
            check(count(service)==3,"diagnostics restore after process restart");
            String report=DiagnosticStore.report(service);
            check(report.contains("국내 일시불 형식 확인: 3"),"parsed outcomes persist");
            DiagnosticStore.clear(service);
            check(count(service)==0,"explicit diagnostic clear");
            check("synthetic-vault-sentinel".equals(service.getSharedPreferences("vault",0).getString("token",null)),"diagnostic clear must preserve independent key storage");
            System.out.println("PASS: restart restores diagnostics; clearing leaves key storage intact (host test doubles).");return;
        }
        check(count(service)==0,"isolated initial store");
        service.onListenerConnected();check(HanaListener.connected,"service connected");
        // Any content read on disallowed packages or grouped/ongoing alerts must fail the test.
        Bundle forbidden=new Bundle(){@Override public CharSequence getCharSequence(String k){throw new AssertionError("Forbidden content inspected");}};
        for(String pkg:new String[]{"com.kakao.talk","com.hanaskcard.paycla.fake","com.example.other"}){
            Notification n=new Notification();n.extras=forbidden;service.onNotificationPosted(new StatusBarNotification(pkg,n,false,POSTED));
        }
        Notification group=new Notification();group.flags=Notification.FLAG_GROUP_SUMMARY;group.extras=forbidden;
        service.onNotificationPosted(new StatusBarNotification(CapturePolicy.HANA_PACKAGE,group,false,POSTED));
        Notification ongoing=new Notification();ongoing.extras=forbidden;
        service.onNotificationPosted(new StatusBarNotification(CapturePolicy.HANA_PACKAGE,ongoing,true,POSTED));
        service.onNotificationPosted(null);
        service.onNotificationPosted(new StatusBarNotification(CapturePolicy.HANA_PACKAGE,null,false,POSTED));
        check(count(service)==0,"excluded inputs never create records");
        StatusBarNotification first=notification(CapturePolicy.HANA_PACKAGE,false,false,true);
        service.onNotificationPosted(first);check(count(service)==1,"first callback persisted automatically");
        check(HanaListener.view().contains("12345원"),"supported values shown locally");
        service.onNotificationRemoved(first);check(count(service)==1,"OS dismissal does not delete journal");
        SystemClock.advance(16*60*1000);check(!HanaListener.view().contains("12345원"),"local detail expires");
        check(count(service)==1,"detail expiry does not delete journal");
        // Identical callback may be an update; this must not be claimed as a new purchase.
        service.onNotificationPosted(first);check(count(service)==2,"callback update is a diagnostic observation");
        check(DiagnosticStore.report(service).contains("결제 건수 아님"),"counts are explicitly not purchases");
        service.onNotificationPosted(notification(CapturePolicy.HANA_PACKAGE,false,false,false));
        check(count(service)==3,"normal text fallback captured");
        Context.failPreferences=true;service.onNotificationPosted(first);Context.failPreferences=false;
        check(HanaListener.diagnosticWriteFailed,"storage failure surfaced without crash");
        check(count(service)==3,"failed store did not invent a record");
        service.onListenerDisconnected();check(!HanaListener.connected&&count(service)==3,"disconnect preserves journal");
        HanaListener.clear();check(count(service)==3,"clear detail does not clear journal");
        String persisted=new String(Files.readAllBytes(Paths.get(System.getProperty("test.preferences"),"hana_diagnostics.properties")),StandardCharsets.UTF_8);
        for(String secret:new String[]{"12,345","987,654","1*2*","10.18 12:34","가상 상점",BODY}){
            check(!persisted.contains(secret),"raw financial fields not persisted");
            check(!DiagnosticStore.report(service).contains(secret),"raw financial fields not copied");
        }
        service.getSharedPreferences("vault",0).edit().putString("token","synthetic-vault-sentinel").apply();
        System.out.println("PASS: package/privacy filter, summary/ongoing exclusion, automatic storage, dismissal, expiry, updates, storage failure and disconnect (host test doubles).");
    }
}
