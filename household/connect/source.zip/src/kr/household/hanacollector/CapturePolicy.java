package kr.household.hanacollector;

/** Pure policy. No raw notification contents leave this process. */
public final class CapturePolicy {
    public static final String HANA_PACKAGE="com.hanaskcard.paycla";
    public static final String ENDPOINT="https://xcchskngoactqsiiutsp.supabase.co/functions/v1/hana-capture";
    public static final String PROBE_BODY="{\"type\":\"probe\"}";
    public static boolean accepts(String pkg,boolean groupSummary,boolean ongoing) {
        return HANA_PACKAGE.equals(pkg)&&!groupSummary&&!ongoing;
    }
    public static boolean tokenValid(String token) {return token!=null&&token.matches("[a-f0-9]{64}");}
    public static String safeReport(String title,String body) {
        // Only structural booleans/counts. Never names, amounts, account/card digits,
        // text fragments, notification IDs, or hashes of the original content.
        String text=(title==null?"":title)+"\n"+(body==null?"":body);
        return "하나Pay 알림 형식 확인\n본문 길이: "+Math.min(text.length(),20000)
          +"\n승인 표현: "+text.contains("승인")+"\n취소 표현: "+text.contains("취소")
          +"\n원화 금액 형태: "+java.util.regex.Pattern.compile("[0-9][0-9,]*\\s*원").matcher(text).find()
          +"\n날짜 형태: "+java.util.regex.Pattern.compile("[0-9]{2}[/.][0-9]{2}").matcher(text).find()
          +"\n진단 버전: 0.6 (이 진단에 원문·금액 없음)";
    }
    private CapturePolicy() {}
}
